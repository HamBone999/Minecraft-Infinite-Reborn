# Third party notices

Minecraft Infinite bundles the components below. Their licences require these notices. They
were missing from builds I shipped before this one.

## Starlight

- Copyright © Spottedleaf and contributors
- <https://github.com/PaperMC/Starlight>
- **LGPL-3.0.** Full text in `licenses/LGPL-3.0.txt`, and the GPL-3.0 it extends in
  `licenses/GPL-3.0.txt`.

> [!CAUTION]
> LGPL-3.0 says you have to be able to swap this component out for your own build of it. Right
> now Starlight is compiled into the same jar as everything else, so the jar on its own does
> not satisfy that. Fixing it means shipping Starlight as a separate jar on the classpath, or
> providing the object files needed to relink. If it has been changed from upstream, that has
> to be stated and the changed source made available. This is on my list.

## JOrbis / JOgg

- Copyright © JCraft, Inc.
- <http://www.jcraft.com/jorbis/>
- **LGPL.** Same relinking obligation as Starlight.

## fastutil

- Copyright © Sebastiano Vigna
- <https://fastutil.di.unimi.it/>
- **Apache-2.0.** Full text in `licenses/Apache-2.0.txt`.

## Brigadier

- Copyright © Microsoft Corporation
- <https://github.com/Mojang/brigadier>
- **MIT.** Full text in `licenses/MIT-brigadier.txt`.

## PaulsCode SoundSystem

- Copyright © Paul Lamb
- <http://www.paulscode.com/>
- Its own licence, which requires attribution and keeping the licence text. Copy in
  `licenses/PaulsCode.txt`.

## LWJGL

- Copyright © LWJGL contributors
- **BSD 3-Clause.** Supplied by your launcher, not bundled here.

## Minecraft

Minecraft is a trademark of Mojang AB / Microsoft. This project is not affiliated with,
endorsed by, or associated with either of them.

No Mojang code or Mojang art is in this repo or in anything it builds. The build runs against
a copy of the official Alpha 1.0.4 client that each person supplies themselves. See
[DISTRIBUTION.md](DISTRIBUTION.md).
