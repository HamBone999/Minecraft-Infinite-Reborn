# Licence texts

Drop the full text of each licence here. NOTICE references these paths, and several of the
licences require the text itself to travel with the distribution — a reference is not enough.

Still needed:

- `LGPL-3.0.txt`      — https://www.gnu.org/licenses/lgpl-3.0.txt
- `GPL-3.0.txt`       — https://www.gnu.org/licenses/gpl-3.0.txt  (LGPL-3.0 extends it)
- `Apache-2.0.txt`    — https://www.apache.org/licenses/LICENSE-2.0.txt
- `MIT-brigadier.txt` — from the Brigadier repository
- `PaulsCode.txt`     — from the SoundSystem distribution

These were not fetched automatically on purpose: they should come from the canonical source
at the version you actually ship, not from a copy someone pasted in.
