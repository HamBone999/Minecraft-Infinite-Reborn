#!/bin/sh
# Build InfiniteLoader.jar and InfiniteInstaller.jar.
# Java 8 bytecode. The loader itself has no dependencies at runtime; Mixin and LaunchWrapper
# are only needed on the compile classpath and are resolved at runtime from libs/.
set -e
cd "$(dirname "$0")"
rm -rf out && mkdir out
# -proc:none: Mixin's annotation processor assumes an obfuscated game and fails with
# "Unable to locate obfuscation mapping". Infinite is not obfuscated, so it is not wanted.
javac -proc:none --release 8 -cp "libs/*" -d out $(find src -name '*.java')
cp src/infinite/mixins/*/*.json out/
cp res/mojang-assets.txt out/
jar cfm InfiniteLoader.jar    manifest.txt           -C out .
jar cfm InfiniteInstaller.jar manifest-installer.txt -C out .
echo "built InfiniteLoader.jar and InfiniteInstaller.jar"
