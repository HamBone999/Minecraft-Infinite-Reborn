package infinite.api.event;

/** Base class for everything the bus carries. */
public abstract class Event {

   @Override
   public String toString() {
      return getClass().getSimpleName();
   }
}
