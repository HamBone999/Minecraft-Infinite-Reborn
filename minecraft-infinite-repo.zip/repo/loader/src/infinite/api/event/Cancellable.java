package infinite.api.event;

/**
 * An event whose outcome a listener can veto.
 *
 * <p>Once cancelled, later listeners are skipped unless they are annotated
 * {@link ReceiveCancelled}. Whether cancelling actually prevents anything depends on the
 * event; each one documents what it does.
 */
public interface Cancellable {

   boolean isCancelled();

   void setCancelled(boolean cancelled);
}
