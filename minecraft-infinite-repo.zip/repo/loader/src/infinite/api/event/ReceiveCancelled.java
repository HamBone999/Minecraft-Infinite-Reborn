package infinite.api.event;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Put this on a listener's event type to keep receiving events after something cancelled
 * them. Useful for logging and for mods that need to know a thing was vetoed.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ReceiveCancelled {
}
