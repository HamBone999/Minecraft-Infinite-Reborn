package infinite.api.event;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The event bus.
 *
 * <p>Listeners are registered against an event class and receive that event and every subclass
 * of it, so a listener on {@link Event} sees everything and a listener on
 * {@link BlockBreakEvent} sees only that.
 *
 * <p>Dispatch order is by {@link Priority}, highest first, and within a priority by
 * registration order. A listener that throws is reported and removed rather than allowed to
 * break every later listener: one broken mod should not take the others down with it.
 *
 * <p>The bus is posted to from the game thread and from the loader's own mixins, and mods may
 * register from any thread during setup, so the collections are concurrent.
 */
public final class EventBus {

   public enum Priority {
      HIGHEST, HIGH, NORMAL, LOW, LOWEST
   }

   public interface Listener<T extends Event> {
      void on(T event);
   }

   private static final class Registration {
      final Class<?> type;
      final Listener<Event> listener;
      final Priority priority;
      final String owner;
      final int sequence;

      Registration(Class<?> type, Listener<Event> listener, Priority priority, String owner,
                   int sequence) {
         this.type = type;
         this.listener = listener;
         this.priority = priority;
         this.owner = owner;
         this.sequence = sequence;
      }
   }

   private static final EventBus INSTANCE = new EventBus();

   private final List<Registration> registrations = new CopyOnWriteArrayList<Registration>();
   private final Map<Class<?>, List<Registration>> cache =
      new ConcurrentHashMap<Class<?>, List<Registration>>();
   private int sequence;

   private EventBus() {
   }

   public static EventBus get() {
      return INSTANCE;
   }

   public <T extends Event> void subscribe(Class<T> type, Listener<T> listener) {
      subscribe(type, Priority.NORMAL, "unknown", listener);
   }

   public <T extends Event> void subscribe(Class<T> type, Priority priority, String owner,
                                           Listener<T> listener) {
      if (type == null || listener == null) {
         throw new IllegalArgumentException("event type and listener are both required");
      }
      @SuppressWarnings("unchecked")
      Listener<Event> erased = (Listener<Event>) listener;
      synchronized (this) {
         registrations.add(new Registration(type, erased,
            priority == null ? Priority.NORMAL : priority,
            owner == null ? "unknown" : owner, sequence++));
      }
      cache.clear();
   }

   /** Remove every listener belonging to one mod. */
   public void unsubscribeAll(String owner) {
      List<Registration> doomed = new ArrayList<Registration>();
      for (Registration r : registrations) {
         if (r.owner.equals(owner)) {
            doomed.add(r);
         }
      }
      registrations.removeAll(doomed);
      cache.clear();
   }

   /**
    * Deliver an event to everything listening for it.
    *
    * @return the same event, so callers can post and inspect in one expression
    */
   public <T extends Event> T post(T event) {
      if (event == null) {
         return null;
      }
      for (Registration r : listenersFor(event.getClass())) {
         if (event instanceof Cancellable && ((Cancellable) event).isCancelled()
            && !r.type.isAnnotationPresent(ReceiveCancelled.class)) {
            continue;
         }
         try {
            r.listener.on(event);
         } catch (Throwable t) {
            System.err.println("[infinite] listener from '" + r.owner + "' threw on "
               + event.getClass().getSimpleName() + ", removing it");
            t.printStackTrace();
            registrations.remove(r);
            cache.clear();
         }
      }
      return event;
   }

   private List<Registration> listenersFor(Class<?> eventType) {
      List<Registration> hit = cache.get(eventType);
      if (hit != null) {
         return hit;
      }
      List<Registration> matched = new ArrayList<Registration>();
      for (Registration r : registrations) {
         if (r.type.isAssignableFrom(eventType)) {
            matched.add(r);
         }
      }
      matched.sort(new Comparator<Registration>() {
         public int compare(Registration a, Registration b) {
            int byPriority = a.priority.ordinal() - b.priority.ordinal();
            return byPriority != 0 ? byPriority : a.sequence - b.sequence;
         }
      });
      cache.put(eventType, matched);
      return matched;
   }

   /** Listener count, for diagnostics. */
   public int listenerCount() {
      return registrations.size();
   }
}
