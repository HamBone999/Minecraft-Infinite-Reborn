package infinite.api.event;

/**
 * A block is being removed from the world.
 *
 * <p>Fired from {@code Block.onBlockRemoval}. Cancelling does not put the block back, because
 * by this point the removal has already been decided; use it to react, not to veto. To
 * actually prevent a break, cancel {@link BlockPlaceEvent}'s sibling on the server side or
 * mixin the dig handler directly.
 */
public final class BlockBreakEvent extends CancellableEvent {

   public final Object world;
   public final int x;
   public final int y;
   public final int z;

   public BlockBreakEvent(Object world, int x, int y, int z) {
      this.world = world;
      this.x = x;
      this.y = y;
      this.z = z;
   }

   @Override
   public String toString() {
      return "BlockBreakEvent[" + x + "," + y + "," + z + "]";
   }
}
