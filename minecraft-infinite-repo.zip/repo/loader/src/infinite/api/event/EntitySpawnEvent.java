package infinite.api.event;

/**
 * An entity is about to enter the world.
 *
 * <p>Fired at the head of {@code World.spawnEntity}. **Cancelling really does prevent the
 * spawn**, because that method returns a boolean and the mixin returns false when the event is
 * cancelled. This is the one event here with real veto power, so use it carefully: cancelling
 * a spawn the game expects to succeed can confuse whatever asked for it.
 */
public final class EntitySpawnEvent extends CancellableEvent {

   public final Object world;
   public final Object entity;

   public EntitySpawnEvent(Object world, Object entity) {
      this.world = world;
      this.entity = entity;
   }

   @Override
   public String toString() {
      return "EntitySpawnEvent[" + entity + "]";
   }
}
