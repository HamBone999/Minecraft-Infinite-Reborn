package infinite.api.event;

/**
 * A block has just been added to the world.
 *
 * <p>Fired from {@code Block.onBlockAdded}, which runs after placement, so this reports rather
 * than gates.
 */
public final class BlockPlaceEvent extends Event {

   public final Object world;
   public final int x;
   public final int y;
   public final int z;

   public BlockPlaceEvent(Object world, int x, int y, int z) {
      this.world = world;
      this.x = x;
      this.y = y;
      this.z = z;
   }

   @Override
   public String toString() {
      return "BlockPlaceEvent[" + x + "," + y + "," + z + "]";
   }
}
