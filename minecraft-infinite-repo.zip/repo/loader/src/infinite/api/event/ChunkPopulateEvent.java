package infinite.api.event;

/**
 * A chunk has been generated and populated with its own features.
 *
 * <p>Fired at the tail of {@code OverworldGenerator.populate}, which is the correct moment to
 * add worldgen: terrain and vanilla features exist, and the chunk is not yet in play.
 *
 * <p>Most mods should register a feature with {@code WorldgenRegistry} rather than listen for
 * this directly. The registry uses this event underneath.
 */
public final class ChunkPopulateEvent extends Event {

   public final Object world;
   public final Object generator;
   public final int chunkX;
   public final int chunkZ;

   public ChunkPopulateEvent(Object world, Object generator, int chunkX, int chunkZ) {
      this.world = world;
      this.generator = generator;
      this.chunkX = chunkX;
      this.chunkZ = chunkZ;
   }

   /** Block coordinate of this chunk's corner. */
   public int blockX() {
      return chunkX << 4;
   }

   public int blockZ() {
      return chunkZ << 4;
   }

   @Override
   public String toString() {
      return "ChunkPopulateEvent[" + chunkX + "," + chunkZ + "]";
   }
}
