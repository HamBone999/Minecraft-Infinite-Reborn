package infinite.api.event;

/** Convenience base for events that can be vetoed. */
public abstract class CancellableEvent extends Event implements Cancellable {

   private boolean cancelled;

   @Override
   public boolean isCancelled() {
      return cancelled;
   }

   @Override
   public void setCancelled(boolean cancelled) {
      this.cancelled = cancelled;
   }
}
