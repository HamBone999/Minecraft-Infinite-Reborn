package infinite.api;

import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Binds a renderer to a modded entity. Client side only.
 *
 * <p>{@code EntityRenderManager} keeps a private class-to-renderer map. Registering is putting
 * an entry in it, so this opens it reflectively rather than requiring a change inside Infinite.
 *
 * <pre>
 * EntityRendererRegistry.register(Wraith.class, new WraithRenderer());
 * </pre>
 *
 * <h2>You may not need this</h2>
 *
 * <p>{@code getRenderer} walks up the superclass chain and caches what it finds, so an entity
 * extending {@code Mob} already draws with {@code MobRenderer} and one extending an existing
 * mob draws as that mob. Register only when you want a different look.
 *
 * <p>That caching is also why registration has to happen during client setup: once the manager
 * has resolved a class it stores the answer, and a renderer registered afterwards is ignored
 * for every entity already drawn.
 */
public final class EntityRendererRegistry {

   private static final String MANAGER = "net.minecraft.client.render.entity.EntityRenderManager";

   private static final Map<String, String> registered = new LinkedHashMap<String, String>();

   private EntityRendererRegistry() {
   }

   /**
    * @param entityType   the entity class, must extend net.minecraft.game.entity.Entity
    * @param renderer     an EntityRenderer instance
    */
   @SuppressWarnings("unchecked")
   public static void register(Class<?> entityType, Object renderer) {
      if (entityType == null || renderer == null) {
         throw new IllegalArgumentException("entity class and renderer are both required");
      }
      try {
         Class<?> managerClass = Class.forName(MANAGER, true, loader());
         Class<?> rendererClass =
            Class.forName("net.minecraft.client.render.entity.EntityRenderer", true, loader());

         if (!rendererClass.isInstance(renderer)) {
            throw new IllegalArgumentException(renderer.getClass().getName()
               + " does not extend net.minecraft.client.render.entity.EntityRenderer");
         }

         Field instanceField = managerClass.getDeclaredField("instance");
         instanceField.setAccessible(true);
         Object manager = instanceField.get(null);
         if (manager == null) {
            throw new IllegalStateException("EntityRenderManager does not exist yet."
               + " Register renderers from onClientSetup, not onSetup.");
         }

         Field renderersField = managerClass.getDeclaredField("renderers");
         renderersField.setAccessible(true);
         Map<Object, Object> renderers = (Map<Object, Object>) renderersField.get(manager);
         renderers.put(entityType, renderer);
         registered.put(entityType.getName(), renderer.getClass().getName());

         // The manager caches superclass lookups, so a class resolved before this call still
         // points at the inherited renderer. Drop those so they resolve again.
         evictInheritedCacheFor(renderers, entityType);

      } catch (RuntimeException direct) {
         throw direct;
      } catch (Exception e) {
         Throwable cause = e.getCause() == null ? e : e.getCause();
         throw new IllegalStateException("could not register a renderer for "
            + entityType.getName() + ": " + cause, cause);
      }
   }

   /**
    * Remove cached entries for subclasses of {@code type}, which were resolved by walking up
    * to a superclass renderer and would otherwise keep the old answer.
    */
   private static void evictInheritedCacheFor(Map<Object, Object> renderers, Class<?> type) {
      java.util.List<Object> stale = new java.util.ArrayList<Object>();
      for (Map.Entry<Object, Object> e : renderers.entrySet()) {
         if (!(e.getKey() instanceof Class)) {
            continue;
         }
         Class<?> key = (Class<?>) e.getKey();
         if (key != type && type.isAssignableFrom(key)
            && !registered.containsKey(key.getName())) {
            stale.add(key);
         }
      }
      for (Object key : stale) {
         renderers.remove(key);
      }
   }

   /** What has been bound, entity class name to renderer class name. */
   public static Map<String, String> registered() {
      return new LinkedHashMap<String, String>(registered);
   }

   private static ClassLoader loader() {
      ClassLoader context = Thread.currentThread().getContextClassLoader();
      return context != null ? context : EntityRendererRegistry.class.getClassLoader();
   }
}
