package infinite.api;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * What a mod is handed when it is constructed.
 *
 * <p>Construction happens early, before the game's own classes are touched, so a mod should
 * register callbacks here rather than doing work in its constructor. The loader fires them at
 * the right moment.
 */
public final class ModContext {

   private final String modId;
   private final String version;
   private final File source;
   private final List<Runnable> setup = new ArrayList<Runnable>();
   private final List<Runnable> clientSetup = new ArrayList<Runnable>();

   public ModContext(String modId, String version, File source) {
      this.modId = modId;
      this.version = version;
      this.source = source;
   }

   public String modId() {
      return modId;
   }

   public String version() {
      return version;
   }

   /** The jar this mod was loaded from, or null if it was supplied directly. */
   public File source() {
      return source;
   }

   /**
    * Runs on both client and server, once the game's registries exist. Register blocks,
    * items and recipes here.
    */
   public void onSetup(Runnable action) {
      setup.add(action);
   }

   /** Runs on the client only, after the common setup. Renderers and textures belong here. */
   public void onClientSetup(Runnable action) {
      clientSetup.add(action);
   }

   public List<Runnable> setupTasks() {
      return setup;
   }

   public List<Runnable> clientSetupTasks() {
      return clientSetup;
   }
}
