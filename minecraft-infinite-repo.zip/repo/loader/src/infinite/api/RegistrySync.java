package infinite.api;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Makes a client and a server agree on modded entity ids.
 *
 * <h2>The problem</h2>
 *
 * <p>Entity ids go over the wire, but they are allocated locally. Two machines with different
 * mods installed, or the same mods loaded in a different order, end up with different numbers
 * for the same entity. The symptom is a mob that spawns as the wrong creature, or not at all,
 * and nothing in the logs explains it.
 *
 * <h2>The fix</h2>
 *
 * <p>Names are stable, ids are not. So at login the server sends its whole name-to-id table on
 * a {@code CustomPayloadPacket}, and the client rewrites its own ids to match. After that both
 * sides read the same number as the same entity.
 *
 * <p>Only the client moves. The server is the authority, which is what makes this work with
 * several clients at once.
 *
 * <p>Wire format, deliberately boring:
 *
 * <pre>
 *   magic   "INFREG"   UTF
 *   version 1          int
 *   count              int
 *   count x { name UTF, id int }
 * </pre>
 */
public final class RegistrySync {

   public static final String CHANNEL = "infinite|registry";
   private static final String MAGIC = "INFREG";
   private static final int VERSION = 1;

   private static final String MANAGER = "net.minecraft.game.entity.EntityManager";

   /** What the last sync changed, for logging and for tests. */
   public static final class Result {
      public final Map<String, Integer> remapped = new LinkedHashMap<String, Integer>();
      public final List<String> missingOnClient = new ArrayList<String>();
      public final List<String> extraOnClient = new ArrayList<String>();

      public boolean clean() {
         return missingOnClient.isEmpty();
      }

      @Override
      public String toString() {
         return "remapped " + remapped.size() + ", missing " + missingOnClient.size()
            + ", extra " + extraOnClient.size();
      }
   }

   private RegistrySync() {
   }

   // =====================================================================================
   // Server side
   // =====================================================================================

   /** Snapshot this side's entity table as the payload to send. */
   public static byte[] encode() {
      Map<String, Integer> table = snapshot();
      ByteArrayOutputStream bytes = new ByteArrayOutputStream();
      DataOutputStream out = new DataOutputStream(bytes);
      try {
         out.writeUTF(MAGIC);
         out.writeInt(VERSION);
         out.writeInt(table.size());
         for (Map.Entry<String, Integer> e : table.entrySet()) {
            out.writeUTF(e.getKey());
            out.writeInt(e.getValue());
         }
         out.flush();
      } catch (IOException impossible) {
         throw new IllegalStateException("could not encode the registry", impossible);
      }
      return bytes.toByteArray();
   }

   // =====================================================================================
   // Client side
   // =====================================================================================

   public static Map<String, Integer> decode(byte[] payload) throws IOException {
      DataInputStream in = new DataInputStream(new ByteArrayInputStream(payload));
      String magic = in.readUTF();
      if (!MAGIC.equals(magic)) {
         throw new IOException("not a registry payload");
      }
      int version = in.readInt();
      if (version != VERSION) {
         throw new IOException("registry payload is version " + version
            + ", this build speaks " + VERSION);
      }
      int count = in.readInt();
      if (count < 0 || count > 4096) {
         throw new IOException("registry payload claims " + count + " entries");
      }
      Map<String, Integer> table = new LinkedHashMap<String, Integer>();
      for (int i = 0; i < count; i++) {
         String name = in.readUTF();
         table.put(name, in.readInt());
      }
      return table;
   }

   /**
    * Rewrite this side's entity ids to match {@code serverTable}.
    *
    * <p>Applied as a whole rather than entry by entry: the new tables are built first and only
    * swapped in once every entry resolves. A half-applied remap is worse than none, because
    * some ids would be the server's and some this machine's.
    */
   @SuppressWarnings("unchecked")
   public static Result apply(Map<String, Integer> serverTable) {
      Result result = new Result();
      try {
         Class<?> manager = Class.forName(MANAGER, true, loader());

         Map<Object, Object> stringToClass = mapField(manager, "stringToClass", null);
         Map<Object, Object> idToClass = mapField(manager, "IdToClass", null);
         Map<Object, Object> classToId = mapField(manager, "classToId", null);

         Map<String, Integer> mine = snapshot();

         Map<Object, Object> newIdToClass = new LinkedHashMap<Object, Object>();
         Map<Object, Object> newClassToId = new LinkedHashMap<Object, Object>();

         for (Map.Entry<String, Integer> e : serverTable.entrySet()) {
            String name = e.getKey();
            int serverId = e.getValue();
            Object type = stringToClass.get(name);
            if (type == null) {
               result.missingOnClient.add(name);
               continue;
            }
            newIdToClass.put(serverId, type);
            newClassToId.put(type, serverId);
            Integer had = mine.get(name);
            if (had == null || had != serverId) {
               result.remapped.put(name, serverId);
            }
         }

         for (String name : mine.keySet()) {
            if (!serverTable.containsKey(name)) {
               result.extraOnClient.add(name);
            }
         }

         if (!result.missingOnClient.isEmpty()) {
            // Nothing is changed. Connecting with a partial table would produce wrong
            // entities rather than an honest failure.
            return result;
         }

         idToClass.clear();
         idToClass.putAll(newIdToClass);
         classToId.clear();
         classToId.putAll(newClassToId);
         return result;

      } catch (Exception e) {
         throw new IllegalStateException("could not apply the server's registry", e);
      }
   }

   /** A human readable summary of what a failed sync means. */
   public static String describeFailure(Result result) {
      StringBuilder b = new StringBuilder();
      b.append("This server has entities your client does not:\n\n");
      int shown = 0;
      for (String name : result.missingOnClient) {
         if (shown++ == 12) {
            b.append("  ... and ").append(result.missingOnClient.size() - 12).append(" more\n");
            break;
         }
         b.append("  ").append(name).append('\n');
      }
      b.append("\nInstall the same addons as the server, then reconnect.");
      return b.toString();
   }

   // =====================================================================================

   /** This side's entity table, name to id. */
   public static Map<String, Integer> snapshot() {
      Map<String, Integer> out = new LinkedHashMap<String, Integer>();
      try {
         Class<?> manager = Class.forName(MANAGER, true, loader());
         Map<Object, Object> stringToClass = mapField(manager, "stringToClass", null);
         Map<Object, Object> classToId = mapField(manager, "classToId", null);
         for (Map.Entry<Object, Object> e : stringToClass.entrySet()) {
            Object id = classToId.get(e.getValue());
            if (id != null) {
               out.put(String.valueOf(e.getKey()), ((Number) id).intValue());
            }
         }
      } catch (Exception e) {
         throw new IllegalStateException("could not read the entity registry", e);
      }
      return out;
   }

   @SuppressWarnings("unchecked")
   private static Map<Object, Object> mapField(Class<?> owner, String name, Object instance)
         throws Exception {
      Field f = owner.getDeclaredField(name);
      f.setAccessible(true);
      return (Map<Object, Object>) f.get(instance);
   }

   private static ClassLoader loader() {
      ClassLoader context = Thread.currentThread().getContextClassLoader();
      return context != null ? context : RegistrySync.class.getClassLoader();
   }
}
