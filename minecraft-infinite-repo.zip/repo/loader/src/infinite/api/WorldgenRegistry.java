package infinite.api;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import infinite.api.event.ChunkPopulateEvent;
import infinite.api.event.EventBus;

/**
 * Registers worldgen features.
 *
 * <p>Infinite's own features extend {@code Feature} and expose
 * {@code place(World, Random, int, int, int)}. A mod registers one here with how often to try
 * it and in what height band, and the registry runs it as each chunk finishes generating.
 *
 * <p>Placement happens on {@link ChunkPopulateEvent}, fired at the tail of
 * {@code OverworldGenerator.populate}. That is the same moment Infinite places its own
 * features: the terrain exists, and the chunk is not yet in play.
 *
 * <pre>
 * WorldgenRegistry.add(new MyOreFeature(), 12, 4, 48);   // 12 tries per chunk, y 4 to 48
 * </pre>
 *
 * <h2>The offset that everyone gets wrong</h2>
 *
 * <p>Coordinates are offset by 8 blocks, not 0. Population runs for a chunk but writes into
 * the 16x16 area straddling its corner, so a feature anchored at the chunk origin can place
 * into a neighbour that has not generated yet and get cut off. Infinite's own features use
 * the same +8, and this registry applies it for you.
 */
public final class WorldgenRegistry {

   /** One registered feature and how to place it. */
   public static final class Entry {
      public final Object feature;
      public final String owner;
      public final int attemptsPerChunk;
      public final int minY;
      public final int maxY;

      Entry(Object feature, String owner, int attemptsPerChunk, int minY, int maxY) {
         this.feature = feature;
         this.owner = owner;
         this.attemptsPerChunk = attemptsPerChunk;
         this.minY = minY;
         this.maxY = maxY;
      }

      @Override
      public String toString() {
         return feature.getClass().getSimpleName() + " x" + attemptsPerChunk
            + " y" + minY + ".." + maxY + " (" + owner + ")";
      }
   }

   private static final List<Entry> entries = new ArrayList<Entry>();
   private static boolean listening;

   private WorldgenRegistry() {
   }

   /**
    * Place a feature during chunk population.
    *
    * @param feature          an instance of a Feature subclass
    * @param attemptsPerChunk how many times per chunk to try, each at a random spot
    * @param minY             lowest y to try, inclusive
    * @param maxY             highest y to try, exclusive
    */
   public static void add(Object feature, int attemptsPerChunk, int minY, int maxY) {
      add(feature, "unknown", attemptsPerChunk, minY, maxY);
   }

   public static void add(Object feature, String owner, int attemptsPerChunk,
                          int minY, int maxY) {
      if (feature == null) {
         throw new IllegalArgumentException("feature is required");
      }
      if (attemptsPerChunk < 1) {
         throw new IllegalArgumentException("attemptsPerChunk must be at least 1");
      }
      if (maxY <= minY) {
         throw new IllegalArgumentException("maxY must be above minY");
      }
      if (findPlace(feature.getClass()) == null) {
         throw new IllegalArgumentException(feature.getClass().getName()
            + " has no place(World, Random, int, int, int) method, so it is not a Feature");
      }
      synchronized (entries) {
         entries.add(new Entry(feature, owner, attemptsPerChunk, minY, maxY));
         listen();
      }
   }

   public static List<Entry> registered() {
      synchronized (entries) {
         return new ArrayList<Entry>(entries);
      }
   }

   // =====================================================================================

   private static void listen() {
      if (listening) {
         return;
      }
      listening = true;
      EventBus.get().subscribe(ChunkPopulateEvent.class, EventBus.Priority.NORMAL, "infinite",
         new EventBus.Listener<ChunkPopulateEvent>() {
            public void on(ChunkPopulateEvent event) {
               place(event);
            }
         });
   }

   private static void place(ChunkPopulateEvent event) {
      List<Entry> snapshot;
      synchronized (entries) {
         snapshot = new ArrayList<Entry>(entries);
      }
      if (snapshot.isEmpty()) {
         return;
      }

      // Seeded from the chunk so a world regenerates identically. Deriving it from the
      // coordinates rather than a shared Random also keeps mods from perturbing each other.
      Random random = new Random(((long) event.chunkX << 32) ^ (event.chunkZ * 0x9E3779B9L));

      int baseX = event.blockX() + 8;
      int baseZ = event.blockZ() + 8;

      for (Entry entry : snapshot) {
         Method place = findPlace(entry.feature.getClass());
         if (place == null) {
            continue;
         }
         for (int attempt = 0; attempt < entry.attemptsPerChunk; attempt++) {
            int x = baseX + random.nextInt(16);
            int y = entry.minY + random.nextInt(entry.maxY - entry.minY);
            int z = baseZ + random.nextInt(16);
            try {
               place.invoke(entry.feature, event.world, random, x, y, z);
            } catch (Throwable t) {
               Throwable cause = t.getCause() == null ? t : t.getCause();
               System.err.println("[infinite] worldgen feature from '" + entry.owner
                  + "' threw at " + x + "," + y + "," + z + ": " + cause);
               cause.printStackTrace();
               synchronized (entries) {
                  entries.remove(entry);
               }
               break;
            }
         }
      }
   }

   private static Method findPlace(Class<?> type) {
      for (Method m : type.getMethods()) {
         if (!m.getName().equals("place") || m.getParameterTypes().length != 5) {
            continue;
         }
         Class<?>[] p = m.getParameterTypes();
         if (p[1] == Random.class && p[2] == int.class && p[3] == int.class
            && p[4] == int.class) {
            m.setAccessible(true);
            return m;
         }
      }
      return null;
   }
}
