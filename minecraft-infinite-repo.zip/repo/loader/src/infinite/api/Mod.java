package infinite.api;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a class as a mod's entry point.
 *
 * <p>The id must match a modId declared in the jar's {@code infinite.mods.toml}. The class
 * needs either a no-argument constructor or one taking a {@link ModContext}.
 *
 * <pre>
 * &#64;Mod("examplemod")
 * public class ExampleMod {
 *    public ExampleMod(ModContext ctx) {
 *       ctx.onSetup(() -&gt; new ExampleBlock(500));
 *    }
 * }
 * </pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Mod {
   String value();
}
