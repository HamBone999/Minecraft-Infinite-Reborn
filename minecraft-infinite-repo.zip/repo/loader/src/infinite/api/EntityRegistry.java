package infinite.api;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Registers modded entities.
 *
 * <p>Infinite already keeps a real entity registry in {@code EntityManager}: name to class,
 * class to name, id to class and class to id, plus a cached constructor. The only thing
 * missing is a way in, because {@code addMapping} is private. This opens it reflectively
 * rather than requiring a change inside Infinite.
 *
 * <p>Numeric ids are what go over the wire, so client and server must agree on them. Passing
 * an explicit id is therefore strongly preferred: an auto-allocated id depends on what else
 * is installed, which means two machines with different mod sets disagree. Auto-allocation
 * exists for single player and for testing.
 *
 * <pre>
 * EntityRegistry.register(Wraith.class, "wraith", 210);
 * </pre>
 */
public final class EntityRegistry {

   private static final String MANAGER = "net.minecraft.game.entity.EntityManager";
   /** Ids are written as a byte on the wire, so this is the ceiling. */
   private static final int MAX_ID = 255;

   private static final Map<String, Integer> registered = new LinkedHashMap<String, Integer>();

   private EntityRegistry() {
   }

   /**
    * Register an entity under an explicit id.
    *
    * @param type  the entity class, must extend net.minecraft.game.entity.Entity
    * @param name  the save name, which ends up in world data, so never change it later
    * @param id    the network id, 1 to 255, must match on client and server
    */
   public static void register(Class<?> type, String name, int id) {
      if (type == null || name == null || name.isEmpty()) {
         throw new IllegalArgumentException("entity class and name are both required");
      }
      if (id < 1 || id > MAX_ID) {
         throw new IllegalArgumentException("entity id " + id + " is outside 1.." + MAX_ID);
      }
      try {
         Class<?> manager = Class.forName(MANAGER, true, loader());

         if (usedIds(manager).contains(id)) {
            throw new IllegalStateException("entity id " + id + " is already taken by "
               + nameOfId(manager, id) + ". Pick another, or use registerAuto for testing.");
         }
         if (names(manager).contains(name)) {
            throw new IllegalStateException("an entity called '" + name + "' already exists");
         }

         // EntityManager caches a constructor and throws a bare java.lang.Error if there
         // isn't one. Checking here turns that into something a mod author can act on.
         Class<?> world = Class.forName("net.minecraft.game.world.World", true, loader());
         Class<?> entity = Class.forName("net.minecraft.game.entity.Entity", true, loader());
         if (!entity.isAssignableFrom(type)) {
            throw new IllegalArgumentException(type.getName()
               + " does not extend net.minecraft.game.entity.Entity");
         }
         try {
            type.getConstructor(world);
         } catch (NoSuchMethodException e) {
            throw new IllegalArgumentException(type.getName() + " needs a public constructor"
               + " taking a single World argument. The game builds entities reflectively when"
               + " loading a world and from spawn packets, so it has no other way in.");
         }

         Method add = manager.getDeclaredMethod("addMapping", Class.class, String.class, int.class);
         add.setAccessible(true);
         add.invoke(null, type, name, id);
         registered.put(name, id);

      } catch (RuntimeException direct) {
         throw direct;
      } catch (Exception e) {
         Throwable cause = e.getCause() == null ? e : e.getCause();
         throw new IllegalStateException("could not register entity '" + name + "': " + cause,
            cause);
      }
   }

   /**
    * Register with the lowest free id.
    *
    * <p>Fine for single player and tests. For multiplayer, use {@link #register} with a fixed
    * id, because an allocated id depends on which other mods are present and two machines
    * will not agree.
    *
    * @return the id that was chosen
    */
   public static int registerAuto(Class<?> type, String name) {
      try {
         Class<?> manager = Class.forName(MANAGER, true, loader());
         List<Integer> used = usedIds(manager);
         for (int id = 1; id <= MAX_ID; id++) {
            if (!used.contains(id)) {
               register(type, name, id);
               return id;
            }
         }
         throw new IllegalStateException("no free entity ids left below " + MAX_ID);
      } catch (RuntimeException direct) {
         throw direct;
      } catch (Exception e) {
         throw new IllegalStateException("could not register entity '" + name + "'", e);
      }
   }

   /** What this registry has added, name to id, in registration order. */
   public static Map<String, Integer> registered() {
      return new LinkedHashMap<String, Integer>(registered);
   }

   /** Every id currently in use, modded and built in. */
   public static List<Integer> usedIds() {
      try {
         return usedIds(Class.forName(MANAGER, true, loader()));
      } catch (Exception e) {
         return new ArrayList<Integer>();
      }
   }

   // =====================================================================================

   @SuppressWarnings("unchecked")
   private static List<Integer> usedIds(Class<?> manager) throws Exception {
      Field f = manager.getDeclaredField("IdToClass");
      f.setAccessible(true);
      Map<Object, Object> map = (Map<Object, Object>) f.get(null);
      List<Integer> out = new ArrayList<Integer>();
      for (Object key : map.keySet()) {
         out.add(((Number) key).intValue());
      }
      return out;
   }

   @SuppressWarnings("unchecked")
   private static List<String> names(Class<?> manager) throws Exception {
      Field f = manager.getDeclaredField("stringToClass");
      f.setAccessible(true);
      Map<Object, Object> map = (Map<Object, Object>) f.get(null);
      List<String> out = new ArrayList<String>();
      for (Object key : map.keySet()) {
         out.add(String.valueOf(key));
      }
      return out;
   }

   @SuppressWarnings("unchecked")
   private static String nameOfId(Class<?> manager, int id) throws Exception {
      Field idToClass = manager.getDeclaredField("IdToClass");
      idToClass.setAccessible(true);
      Map<Object, Object> map = (Map<Object, Object>) idToClass.get(null);
      for (Map.Entry<Object, Object> e : map.entrySet()) {
         if (((Number) e.getKey()).intValue() == id) {
            return String.valueOf(e.getValue());
         }
      }
      return "something";
   }

   /**
    * The transforming loader, so this resolves the same EntityManager the game uses rather
    * than a second copy from the app loader.
    */
   private static ClassLoader loader() {
      ClassLoader context = Thread.currentThread().getContextClassLoader();
      return context != null ? context : EntityRegistry.class.getClassLoader();
   }
}
