package infinite.mixins.core;

import infinite.api.event.ChunkPopulateEvent;
import infinite.api.event.EventBus;
import net.minecraft.game.world.chunk.ChunkLoader;
import net.minecraft.game.world.generation.OverworldGenerator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fires chunk population, which is what WorldgenRegistry runs on.
 *
 * <p>TAIL rather than HEAD on purpose: modded features should see finished terrain and the
 * generator's own features, not an empty chunk.
 */
@Mixin(OverworldGenerator.class)
public class WorldgenEvents {

   @Shadow
   protected net.minecraft.game.world.World world;

   @Inject(method = "populate", at = @At("TAIL"))
   private void infinite$firePopulate(ChunkLoader loader, int chunkX, int chunkZ,
                                      CallbackInfo ci) {
      EventBus.get().post(new ChunkPopulateEvent(this.world, this, chunkX, chunkZ));
   }
}
