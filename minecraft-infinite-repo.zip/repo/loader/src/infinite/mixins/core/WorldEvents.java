package infinite.mixins.core;

import infinite.api.event.EntitySpawnEvent;
import infinite.api.event.EventBus;
import net.minecraft.game.entity.Entity;
import net.minecraft.game.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fires the entity spawn event.
 *
 * <p>spawnEntity returns a boolean, so cancelling here genuinely stops the spawn rather than
 * merely reporting it. This is the only veto in the core event set.
 */
@Mixin(World.class)
public class WorldEvents {

   @Inject(method = "spawnEntity", at = @At("HEAD"), cancellable = true)
   private void infinite$fireSpawn(Entity entity, CallbackInfoReturnable<Boolean> cir) {
      EntitySpawnEvent event = EventBus.get().post(new EntitySpawnEvent(this, entity));
      if (event.isCancelled()) {
         cir.setReturnValue(Boolean.FALSE);
      }
   }
}
