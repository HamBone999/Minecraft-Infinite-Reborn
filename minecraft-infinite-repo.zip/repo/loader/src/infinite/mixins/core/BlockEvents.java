package infinite.mixins.core;

import infinite.api.event.BlockBreakEvent;
import infinite.api.event.BlockPlaceEvent;
import infinite.api.event.EventBus;
import net.minecraft.game.block.Block;
import net.minecraft.game.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Fires the block events. Both of these run after the fact, so neither can veto. */
@Mixin(Block.class)
public class BlockEvents {

   @Inject(method = "onBlockRemoval", at = @At("HEAD"))
   private void infinite$fireBreak(World world, int x, int y, int z, CallbackInfo ci) {
      EventBus.get().post(new BlockBreakEvent(world, x, y, z));
   }

   @Inject(method = "onBlockAdded", at = @At("HEAD"))
   private void infinite$firePlace(World world, int x, int y, int z, CallbackInfo ci) {
      EventBus.get().post(new BlockPlaceEvent(world, x, y, z));
   }
}
