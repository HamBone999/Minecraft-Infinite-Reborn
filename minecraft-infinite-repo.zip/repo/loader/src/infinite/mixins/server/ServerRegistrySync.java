package infinite.mixins.server;

import infinite.api.RegistrySync;
import net.minecraft.network.packet.container.CustomPayloadPacket;
import net.minecraft.server.network.NetServerHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sends this server's entity table to a player as they join.
 *
 * <p>At the tail of the handler's constructor, which is the first moment there is something to
 * send a packet down and still before any entity has been spawned for that player. A vanilla
 * client ignores an unknown channel, so this does not break them.
 */
@Mixin(NetServerHandler.class)
public class ServerRegistrySync {

   @Inject(method = "<init>", at = @At("TAIL"))
   private void infinite$sendRegistry(CallbackInfo ci) {
      try {
         NetServerHandler self = (NetServerHandler) (Object) this;
         self.sendPacket(new CustomPayloadPacket(RegistrySync.CHANNEL, RegistrySync.encode()));
      } catch (Throwable t) {
         // A failed sync must not stop someone joining; it degrades to the old behaviour.
         System.err.println("[infinite] could not send the registry to a joining player: " + t);
      }
   }
}
