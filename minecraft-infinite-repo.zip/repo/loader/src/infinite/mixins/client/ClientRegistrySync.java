package infinite.mixins.client;

import java.util.Map;

import infinite.api.RegistrySync;
import net.minecraft.client.network.ClientHandler;
import net.minecraft.network.packet.container.CustomPayloadPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Receives the server's entity table and remaps to match it.
 *
 * <p>Injected at HEAD and cancelled for our channel, so the packet never reaches the game's
 * own handler. Any other channel passes straight through untouched.
 */
@Mixin(ClientHandler.class)
public class ClientRegistrySync {

   @Inject(method = "handleCustomPayload", at = @At("HEAD"), cancellable = true)
   private void infinite$receiveRegistry(CustomPayloadPacket packet, CallbackInfo ci) {
      if (!RegistrySync.CHANNEL.equals(packet.channel)) {
         return;
      }
      ci.cancel();
      try {
         Map<String, Integer> table = RegistrySync.decode(packet.data);
         RegistrySync.Result result = RegistrySync.apply(table);

         if (!result.clean()) {
            System.err.println("[infinite] registry sync FAILED");
            System.err.println(RegistrySync.describeFailure(result));
            return;
         }
         System.out.println("[infinite] registry sync: " + result);
         if (!result.extraOnClient.isEmpty()) {
            System.out.println("[infinite] entities this server does not have: "
               + result.extraOnClient);
         }
      } catch (Exception e) {
         System.err.println("[infinite] could not read the server's registry: " + e);
      }
   }
}
