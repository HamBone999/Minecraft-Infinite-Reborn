package infinite.loader.mods;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * LaunchWrapper and Mixin, driven reflectively.
 *
 * <p>Reflective because the loader must build and run without either on its own classpath.
 * Someone with no mods installed should not need Mixin on disk at all.
 *
 * <h2>Why LaunchWrapper</h2>
 *
 * <p>It is the transforming classloader Forge and Sponge used from 1.7 through 1.12, and Mixin
 * ships first class support for it. It carries one hard constraint: {@code Launch}'s
 * constructor casts the system class loader to {@link URLClassLoader}, which stopped being
 * true in Java 9. Constructing {@code LaunchClassLoader} directly sidesteps that cast, but
 * Mixin's LaunchWrapper service then refuses to finish initialising outside the tweaker
 * handshake, so the whole stack is Java 8 only. That is a deliberate, tested choice rather
 * than an oversight. See docs/MODLOADER.md.
 */
final class Transformers {

   static final String LAUNCH = "net.minecraft.launchwrapper.Launch";
   static final String LAUNCH_CLASSLOADER = "net.minecraft.launchwrapper.LaunchClassLoader";
   static final String MIXIN_BOOTSTRAP = "org.spongepowered.asm.launch.MixinBootstrap";
   static final String MIXIN_PROXY = "org.spongepowered.asm.mixin.transformer.Proxy";
   static final String MIXINS = "org.spongepowered.asm.mixin.Mixins";

   private Transformers() {
   }

   /**
    * A transforming class loader over {@code urls}, or a plain one when LaunchWrapper is
    * absent. Without it mods still load, they just cannot transform anything.
    */
   static ClassLoader newClassLoader(List<URL> urls) throws Exception {
      URL[] array = urls.toArray(new URL[0]);
      try {
         Class<?> lcl = Class.forName(LAUNCH_CLASSLOADER);
         ClassLoader loader =
            (ClassLoader) lcl.getConstructor(URL[].class).newInstance((Object) array);

         // Launch.classLoader is static state Mixin reads. It is normally set by Launch.main,
         // which is not used here.
         Class<?> launch = Class.forName(LAUNCH);
         set(launch, "classLoader", loader);
         Field blackboard = launch.getDeclaredField("blackboard");
         blackboard.setAccessible(true);
         if (blackboard.get(null) == null) {
            blackboard.set(null, new HashMap<String, Object>());
         }
         return loader;
      } catch (ClassNotFoundException noLaunchWrapper) {
         return new URLClassLoader(array, ClassLoader.getSystemClassLoader().getParent());
      }
   }

   /**
    * Start Mixin and register each config.
    *
    * <p>Must run before any class a mixin targets is loaded. A class already defined cannot be
    * transformed, and the failure mode is silence rather than an error.
    */
   static void bootstrapMixin(ClassLoader loader, List<String> configs, ModEngine.Log log) {
      if (configs.isEmpty()) {
         return;
      }
      try {
         Class<?> bootstrap = Class.forName(MIXIN_BOOTSTRAP);

         // MixinBootstrap.init() is a convenience for callers running inside a tweaker, and
         // logs "doInit() called during a tweak constructor!" and half-initialises otherwise.
         // The underlying three-step sequence is what MixinTweaker actually performs.
         Method start = bootstrap.getDeclaredMethod("start");
         start.setAccessible(true);
         start.invoke(null);

         Method doInit = bootstrap.getDeclaredMethod("doInit", List.class);
         doInit.setAccessible(true);
         doInit.invoke(null, new ArrayList<String>());

         Class<?> mixins = Class.forName(MIXINS);
         Method add = mixins.getMethod("addConfiguration", String.class);
         for (String config : configs) {
            add.invoke(null, config);
            log.say("mixins    : registered " + config);
         }

         // MixinTweaker normally does this. Without it the transformer never sees a class.
         loader.getClass()
            .getMethod("registerTransformer", String.class)
            .invoke(loader, MIXIN_PROXY);

         Method inject = bootstrap.getDeclaredMethod("inject");
         inject.setAccessible(true);
         inject.invoke(null);

      } catch (ClassNotFoundException missing) {
         log.say("mixins    : Mixin is not on the classpath, " + configs.size()
            + " config(s) skipped");
         log.say("mixins    : mods needing bytecode changes will not work");
      } catch (Exception e) {
         Throwable cause = e.getCause() == null ? e : e.getCause();
         throw new IllegalStateException("Mixin failed to start: " + cause, cause);
      }
   }

   /** The jars Mixin and LaunchWrapper need, as maven coordinates. */
   static List<String> requiredLibraries() {
      List<String> out = new ArrayList<String>();
      out.add("net.minecraft:launchwrapper:1.12");
      out.add("org.spongepowered:mixin:0.8.5");
      out.add("org.ow2.asm:asm:9.6");
      out.add("org.ow2.asm:asm-tree:9.6");
      out.add("org.ow2.asm:asm-analysis:9.6");
      out.add("org.ow2.asm:asm-commons:9.6");
      out.add("org.ow2.asm:asm-util:9.6");
      out.add("com.google.guava:guava:32.1.2-jre");
      out.add("com.google.code.gson:gson:2.10.1");
      out.add("org.apache.commons:commons-lang3:3.12.0");
      out.add("org.apache.logging.log4j:log4j-api:2.20.0");
      out.add("org.apache.logging.log4j:log4j-core:2.20.0");
      out.add("net.sf.jopt-simple:jopt-simple:5.0.4");
      return out;
   }

   private static void set(Class<?> owner, String field, Object value) throws Exception {
      Field f = owner.getDeclaredField(field);
      f.setAccessible(true);
      f.set(null, value);
   }
}
