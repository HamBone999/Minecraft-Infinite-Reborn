package infinite.loader.mods;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Validates dependencies and puts mods in load order.
 *
 * <p>Three failures are worth catching before a single class is loaded, because each one
 * produces a baffling crash later otherwise: a missing required dependency, a dependency
 * present but at the wrong version, and a cycle in the ordering constraints.
 */
public final class ModSorter {

   public static final class Result {
      public final List<ModInfo> order;
      public final List<String> errors;

      Result(List<ModInfo> order, List<String> errors) {
         this.order = Collections.unmodifiableList(order);
         this.errors = Collections.unmodifiableList(errors);
      }

      public boolean ok() {
         return errors.isEmpty();
      }
   }

   private ModSorter() {
   }

   public static Result sort(List<ModInfo> mods) {
      List<String> errors = new ArrayList<String>();
      Map<String, ModInfo> byId = new HashMap<String, ModInfo>();

      for (ModInfo m : mods) {
         ModInfo clash = byId.put(m.modId, m);
         if (clash != null) {
            errors.add("Two mods both claim the id '" + m.modId + "': "
               + describe(clash) + " and " + describe(m));
         }
      }

      for (ModInfo m : mods) {
         for (ModInfo.Dependency d : m.dependencies) {
            ModInfo target = byId.get(d.modId);
            if (target == null) {
               if (d.required) {
                  errors.add(m.displayName + " requires '" + d.modId + "' "
                     + range(d) + "but it is not installed.");
               }
               continue;
            }
            if (!Versions.satisfies(target.version, d.versionRange)) {
               errors.add(m.displayName + " requires '" + d.modId + "' " + range(d)
                  + "but " + target.version + " is installed.");
            }
         }
      }

      // Edges point from "loads earlier" to "loads later".
      Map<String, Set<String>> after = new HashMap<String, Set<String>>();
      for (ModInfo m : mods) {
         after.put(m.modId, new LinkedHashSet<String>());
      }
      for (ModInfo m : mods) {
         for (ModInfo.Dependency d : m.dependencies) {
            if (!byId.containsKey(d.modId)) {
               continue;
            }
            if ("AFTER".equals(d.ordering)) {
               after.get(d.modId).add(m.modId);          // m loads after its dependency
            } else if ("BEFORE".equals(d.ordering)) {
               after.get(m.modId).add(d.modId);
            } else if (d.required) {
               after.get(d.modId).add(m.modId);          // required implies ordered
            }
         }
      }

      List<ModInfo> order = new ArrayList<ModInfo>();
      Set<String> done = new HashSet<String>();
      Set<String> visiting = new LinkedHashSet<String>();

      List<ModInfo> stable = new ArrayList<ModInfo>(mods);
      Collections.sort(stable, (a, b) -> a.modId.compareTo(b.modId));

      for (ModInfo m : stable) {
         visit(m.modId, byId, after, done, visiting, order, errors);
      }

      return new Result(order, errors);
   }

   private static void visit(String id, Map<String, ModInfo> byId, Map<String, Set<String>> after,
                             Set<String> done, Set<String> visiting, List<ModInfo> order,
                             List<String> errors) {
      if (done.contains(id)) {
         return;
      }
      if (!visiting.add(id)) {
         List<String> cycle = new ArrayList<String>(visiting);
         cycle.add(id);
         errors.add("Dependency cycle: " + String.join(" -> ", cycle));
         return;
      }
      // Anything that must load before this one goes first.
      for (Map.Entry<String, Set<String>> e : after.entrySet()) {
         if (e.getValue().contains(id)) {
            visit(e.getKey(), byId, after, done, visiting, order, errors);
         }
      }
      visiting.remove(id);
      if (done.add(id)) {
         ModInfo m = byId.get(id);
         if (m != null) {
            order.add(m);
         }
      }
   }

   private static String range(ModInfo.Dependency d) {
      return d.versionRange.isEmpty() ? "" : d.versionRange + " ";
   }

   private static String describe(ModInfo m) {
      return m.source == null ? m.displayName : m.source.getName();
   }
}
