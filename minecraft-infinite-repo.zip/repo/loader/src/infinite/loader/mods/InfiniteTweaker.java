package infinite.loader.mods;

import java.io.File;
import java.util.List;

/**
 * The LaunchWrapper tweaker that sets Mixin up.
 *
 * <p>Mixin's LaunchWrapper service decides which phase to start in by looking for
 * {@code Launch.launch} in the call stack, and its platform manager refuses to finish
 * initialising outside the tweaker handshake. Driving {@code MixinBootstrap} reflectively from
 * outside therefore half-initialises and silently transforms nothing.
 *
 * <p>So the loader goes through {@code Launch.main} like Forge always did, and this class is
 * the tweaker it names. Everything Mixin needs then happens in the order Mixin expects.
 *
 * <p>Discovery has already run by this point; {@link ModEngine} leaves its results in statics
 * because a tweaker is constructed reflectively by LaunchWrapper and cannot be handed anything.
 */
public final class InfiniteTweaker implements net.minecraft.launchwrapper.ITweaker {

   /** Set by ModEngine before Launch.main is called. */
   static boolean server;
   static List<String> mixinConfigs;
   static List<File> modJars;
   static ModEngine engine;

   private String[] arguments = new String[0];

   @Override
   public void acceptOptions(List<String> args, File gameDir, File assetsDir, String profile) {
      arguments = args == null ? new String[0] : args.toArray(new String[0]);
   }

   @Override
   public void injectIntoClassLoader(net.minecraft.launchwrapper.LaunchClassLoader classLoader) {
      try {
         if (modJars != null) {
            for (File jar : modJars) {
               classLoader.addURL(jar.toURI().toURL());
            }
         }

         // The loader and the mod API must be single copy. If the transforming loader
         // defined its own ModContext, a mod's constructor would receive an instance of a
         // different class with the same name and fail with a ClassCastException.
         // Everything else, the game included, stays transformable.
         classLoader.addClassLoaderExclusion("infinite.loader.");
         classLoader.addClassLoaderExclusion("infinite.api.");

         if (mixinConfigs == null || mixinConfigs.isEmpty()) {
            return;
         }

         org.spongepowered.asm.launch.MixinBootstrap.init();

         // Mixin cannot work the side out on its own here, and without it any mixin an addon
         // scopes to one side is skipped with only a warning to show for it.
         org.spongepowered.asm.mixin.MixinEnvironment.getDefaultEnvironment().setSide(
            server ? org.spongepowered.asm.mixin.MixinEnvironment.Side.SERVER
                   : org.spongepowered.asm.mixin.MixinEnvironment.Side.CLIENT);

         for (String config : mixinConfigs) {
            org.spongepowered.asm.mixin.Mixins.addConfiguration(config);
         }
         classLoader.registerTransformer("org.spongepowered.asm.mixin.transformer.Proxy");

      } catch (Throwable t) {
         throw new IllegalStateException("Could not set up mod transformation: " + t, t);
      }
   }

   @Override
   public String getLaunchTarget() {
      return "infinite.loader.mods.GameStart";
   }

   @Override
   public String[] getLaunchArguments() {
      if (mixinConfigs != null && !mixinConfigs.isEmpty()) {
         org.spongepowered.asm.launch.MixinBootstrap.getPlatform().inject();
      }
      return arguments;
   }
}
