package infinite.loader.mods;

import java.lang.reflect.Method;

/**
 * The class LaunchWrapper hands control to once transformation is set up.
 *
 * <p>Nothing game related may be touched before this point. A class that is already defined
 * cannot be transformed, so constructing mods any earlier would silently skip their mixins.
 */
public final class GameStart {

   /** Set by ModEngine before Launch.main. */
   static ModEngine engine;
   static String mainClass;

   private GameStart() {
   }

   public static void main(String[] args) throws Exception {
      // This class is classloader-excluded so it stays single copy, which means its own
      // loader is the app loader. Everything mod or game related must go through the
      // transforming loader explicitly.
      ClassLoader transforming = net.minecraft.launchwrapper.Launch.classLoader;

      if (engine != null) {
         engine.constructAndSetup(transforming);
      }
      if (mainClass == null) {
         return;                                   // headless test, nothing to hand off to
      }
      Class<?> game = Class.forName(mainClass, true, transforming);
      Method main = game.getMethod("main", String[].class);
      main.invoke(null, (Object) args);
   }
}
