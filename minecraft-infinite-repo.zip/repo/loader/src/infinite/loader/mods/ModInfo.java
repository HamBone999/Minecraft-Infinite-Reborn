package infinite.loader.mods;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * One mod's metadata, read from {@code infinite.mods.toml}.
 *
 * <p>The keys deliberately match {@code neoforge.mods.toml}, so anyone who has written a
 * NeoForge mod already knows the file:
 *
 * <pre>
 * modLoader = "javafml"
 * loaderVersion = "[1,)"
 * license = "MIT"
 *
 * [[mods]]
 * modId = "examplemod"
 * version = "1.0.0"
 * displayName = "Example Mod"
 * authors = "you"
 * description = "..."
 * entrypoint = "com.example.ExampleMod"
 *
 * [[mixins]]
 * config = "examplemod.mixins.json"
 *
 * [[dependencies.examplemod]]
 * modId = "infinite"
 * type = "required"
 * versionRange = "[1.0,)"
 * ordering = "AFTER"
 * </pre>
 */
public final class ModInfo {

   public static final class Dependency {
      public final String modId;
      public final boolean required;
      public final String versionRange;
      /** BEFORE, AFTER or NONE. Controls load order independently of whether it is required. */
      public final String ordering;

      Dependency(String modId, boolean required, String versionRange, String ordering) {
         this.modId = modId;
         this.required = required;
         this.versionRange = versionRange == null ? "" : versionRange;
         this.ordering = ordering == null ? "NONE" : ordering.toUpperCase();
      }

      @Override
      public String toString() {
         return modId + (required ? " (required " : " (optional ") + versionRange + ")";
      }
   }

   public final String modId;
   public final String version;
   public final String displayName;
   public final String description;
   public final String authors;
   /** Class carrying {@code @Mod}. Named outright so the loader never has to scan the jar. */
   public final String entrypoint;
   public final String license;
   public final String loaderVersion;
   public final List<String> mixinConfigs;
   public final List<Dependency> dependencies;
   /** The jar this came from. Null for mods supplied directly, such as Infinite itself. */
   public final File source;

   ModInfo(String modId, String version, String displayName, String description, String authors,
           String entrypoint, String license, String loaderVersion, List<String> mixinConfigs,
           List<Dependency> dependencies, File source) {
      this.modId = modId;
      this.version = version;
      this.displayName = displayName;
      this.description = description;
      this.authors = authors;
      this.entrypoint = entrypoint;
      this.license = license;
      this.loaderVersion = loaderVersion;
      this.mixinConfigs = Collections.unmodifiableList(mixinConfigs);
      this.dependencies = Collections.unmodifiableList(dependencies);
      this.source = source;
   }

   /**
    * Read every mod declared in one manifest. A single file may declare more than one, which
    * is how a jar ships an API module and an implementation module together.
    */
   @SuppressWarnings("unchecked")
   public static List<ModInfo> parse(String toml, File source) {
      Map<String, Object> root = Toml.parse(toml);
      String loaderVersion = str(root, "loaderVersion", "");
      String license = str(root, "license", "");

      List<String> mixins = new ArrayList<String>();
      Object mixinBlock = root.get("mixins");
      if (mixinBlock instanceof List) {
         for (Object o : (List<Object>) mixinBlock) {
            if (o instanceof Map) {
               String config = str((Map<String, Object>) o, "config", null);
               if (config != null) {
                  mixins.add(config);
               }
            }
         }
      }

      Map<String, Object> dependencyBlock = root.get("dependencies") instanceof Map
         ? (Map<String, Object>) root.get("dependencies")
         : null;

      List<ModInfo> out = new ArrayList<ModInfo>();
      Object modsBlock = root.get("mods");
      if (!(modsBlock instanceof List)) {
         throw new IllegalArgumentException("no [[mods]] block");
      }
      for (Object o : (List<Object>) modsBlock) {
         if (!(o instanceof Map)) {
            continue;
         }
         Map<String, Object> m = (Map<String, Object>) o;
         String modId = str(m, "modId", null);
         if (modId == null || modId.isEmpty()) {
            throw new IllegalArgumentException("a [[mods]] entry has no modId");
         }
         out.add(new ModInfo(
            modId,
            str(m, "version", "0.0.0"),
            str(m, "displayName", modId),
            str(m, "description", ""),
            str(m, "authors", ""),
            str(m, "entrypoint", null),
            license,
            loaderVersion,
            mixins,
            dependenciesOf(dependencyBlock, modId),
            source));
      }
      return out;
   }

   @SuppressWarnings("unchecked")
   private static List<Dependency> dependenciesOf(Map<String, Object> block, String modId) {
      List<Dependency> out = new ArrayList<Dependency>();
      if (block == null) {
         return out;
      }
      Object mine = block.get(modId);
      if (!(mine instanceof List)) {
         return out;
      }
      for (Object o : (List<Object>) mine) {
         if (!(o instanceof Map)) {
            continue;
         }
         Map<String, Object> d = (Map<String, Object>) o;
         String id = str(d, "modId", null);
         if (id == null) {
            continue;
         }
         String type = str(d, "type", "required");
         boolean required = !"optional".equalsIgnoreCase(type)
            && !"incompatible".equalsIgnoreCase(type)
            && !"discouraged".equalsIgnoreCase(type);
         out.add(new Dependency(id, required, str(d, "versionRange", ""),
            str(d, "ordering", "NONE")));
      }
      return out;
   }

   private static String str(Map<String, Object> m, String key, String fallback) {
      Object v = m == null ? null : m.get(key);
      return v == null ? fallback : String.valueOf(v);
   }

   @Override
   public String toString() {
      return modId + " " + version;
   }
}
