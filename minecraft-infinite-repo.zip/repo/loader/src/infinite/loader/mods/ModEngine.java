package infinite.loader.mods;

import java.io.File;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Discovers mods, applies their mixins, constructs them and runs the lifecycle.
 *
 * <p>The sequence matters and is not negotiable:
 *
 * <ol>
 *   <li><b>Discover.</b> Read every manifest. No game class has been touched yet.</li>
 *   <li><b>Sort.</b> Validate dependencies and settle load order. Failing here is cheap;
 *       failing after classes are loaded is not.</li>
 *   <li><b>Classloader.</b> Infinite plus every mod jar on one transforming loader.</li>
 *   <li><b>Mixin.</b> Register configs and go to the default phase. This has to happen before
 *       anything loads a game class, because a class already defined cannot be transformed.</li>
 *   <li><b>Construct.</b> Instantiate each {@code @Mod} in order. Mods register callbacks.</li>
 *   <li><b>Setup.</b> Fire the callbacks, at which point registries are safe to touch.</li>
 * </ol>
 *
 * <p>Everything reflective, because the loader is compiled against neither Infinite nor Mixin.
 */
public final class ModEngine {

   public interface Log {
      void say(String message);
   }

   private final Log log;
   private final List<ModInfo> loaded = new ArrayList<ModInfo>();
   private final Map<String, Object> instances = new HashMap<String, Object>();
   private final List<Object> contexts = new ArrayList<Object>();
   private ClassLoader classLoader;
   private List<ModInfo> pending = new ArrayList<ModInfo>();

   /** Ships inside the loader jar. Fires BlockBreak, BlockPlace, EntitySpawn, ChunkPopulate. */
   static final String CORE_MIXINS = "infinite.core.mixins.json";
   /** Client only: receives the server's entity table at login. */
   static final String CLIENT_MIXINS = "infinite.client.mixins.json";
   /** Server only: sends that table to each joining player. */
   static final String SERVER_MIXINS = "infinite.server.mixins.json";

   public ModEngine(Log log) {
      this.log = log == null ? m -> { } : log;
   }

   public ClassLoader classLoader() {
      return classLoader;
   }

   public List<ModInfo> loadedMods() {
      return loaded;
   }

   /**
    * Run everything up to and including common setup.
    *
    * @param modsDir   the mods folder, may be absent
    * @param selfInfo  Infinite's own metadata, so it participates as a mod
    * @param mainClass the game entry point to hand off to, or null for a headless run
    * @param gameArgs  arguments forwarded to the game
    */
   public void start(File modsDir, ModInfo selfInfo, String mainClass, List<String> gameArgs)
         throws Exception {

      ModDiscovery.Found found = ModDiscovery.scan(modsDir);
      for (String w : found.warnings) {
         log.say("mods      : " + w);
      }

      List<ModInfo> all = new ArrayList<ModInfo>();
      if (selfInfo != null) {
         all.add(selfInfo);
      }
      all.addAll(found.mods);

      ModSorter.Result sorted = ModSorter.sort(all);
      if (!sorted.ok()) {
         StringBuilder b = new StringBuilder("Cannot load mods:\n");
         for (String e : sorted.errors) {
            b.append("  - ").append(e).append('\n');
         }
         throw new IllegalStateException(b.toString());
      }

      log.say("mods      : " + sorted.order.size() + " to load");
      for (ModInfo m : sorted.order) {
         log.say("            " + m.modId + " " + m.version
            + (m.source == null ? "" : "  (" + m.source.getName() + ")"));
      }

      InfiniteTweaker.modJars = found.jars;
      InfiniteTweaker.engine = this;
      GameStart.engine = this;
      GameStart.mainClass = mainClass;

      List<String> configs = new ArrayList<String>();
      // The loader's own mixins fire the core events. They go first so a mod listening for
      // an event is guaranteed the event exists by the time its own mixins apply.
      addOwnConfig(configs, CORE_MIXINS);

      // The sync mixins are per side: each targets a class the other side does not have, so
      // registering both would fail on whichever half is missing.
      boolean server = isServer(mainClass);
      InfiniteTweaker.server = server;
      addOwnConfig(configs, server ? SERVER_MIXINS : CLIENT_MIXINS);
      log.say("side      : " + (server ? "server" : "client"));

      for (ModInfo m : sorted.order) {
         configs.addAll(m.mixinConfigs);
      }
      InfiniteTweaker.mixinConfigs = configs;
      if (!configs.isEmpty()) {
         log.say("mixins    : " + configs.size() + " config(s)");
      }

      pending = sorted.order;

      // Hand off to LaunchWrapper. It builds the transforming class loader, runs this
      // tweaker, and then calls GameStart, which is where mods are actually constructed.
      Class<?> launch = Class.forName(Transformers.LAUNCH);
      List<String> args = new ArrayList<String>();
      args.add("--tweakClass");
      args.add(InfiniteTweaker.class.getName());
      args.addAll(gameArgs);
      launch.getMethod("main", String[].class)
         .invoke(null, (Object) args.toArray(new String[0]));
   }

   /**
    * Construct every mod and run common setup. Called from {@link GameStart}, inside the
    * transforming class loader.
    */
   void constructAndSetup(ClassLoader loader) throws Exception {
      this.classLoader = loader;
      construct(pending);
      fire("setupTasks", "setup");
      loaded.addAll(pending);
   }

   /**
    * Which side this is. Taken from the entry point, since the client runs
    * {@code net.minecraft.client.Minecraft} and the server
    * {@code net.minecraft.server.MinecraftServer}. Case-insensitive, because getting this
    * wrong registers the wrong mixins and the failure is a warning rather than a crash.
    * {@code -Dinfinite.side=server} overrides it for embedding and tests.
    */
   static boolean isServer(String mainClass) {
      String forced = System.getProperty("infinite.side");
      if (forced != null) {
         return forced.equalsIgnoreCase("server");
      }
      if (mainClass == null) {
         return false;
      }
      String lower = mainClass.toLowerCase();
      return lower.contains(".server.") || lower.endsWith("server")
         || lower.contains("minecraftserver");
   }

   /** Only add a config the loader actually ships, so a trimmed build degrades quietly. */
   private void addOwnConfig(List<String> configs, String name) {
      if (ModEngine.class.getResource("/" + name) != null) {
         configs.add(name);
      }
   }

   /** Client only, once a display exists. */
   public void clientSetup() {
      fire("clientSetupTasks", "client setup");
   }

   // =====================================================================================

   private void construct(List<ModInfo> order) throws Exception {
      Class<?> contextClass = classLoader.loadClass("infinite.api.ModContext");
      Constructor<?> newContext =
         contextClass.getConstructor(String.class, String.class, File.class);

      for (ModInfo info : order) {
         if (info.entrypoint == null || info.entrypoint.isEmpty()) {
            continue;                                    // metadata only, nothing to construct
         }
         Class<?> type;
         try {
            type = classLoader.loadClass(info.entrypoint);
         } catch (ClassNotFoundException missing) {
            throw new IllegalStateException(info.modId + " names entrypoint "
               + info.entrypoint + " but that class is not in its jar.", missing);
         }
         Object ctx = newContext.newInstance(info.modId, info.version, info.source);

         Object instance;
         try {
            instance = type.getConstructor(contextClass).newInstance(ctx);
         } catch (NoSuchMethodException noContextConstructor) {
            instance = type.getConstructor().newInstance();
         }
         instances.put(info.modId, instance);
         contexts.add(ctx);
         log.say("mods      : constructed " + info.modId);
      }
   }

   @SuppressWarnings("unchecked")
   private void fire(String taskGetter, String label) {
      for (Object ctx : contexts) {
         try {
            List<Runnable> tasks =
               (List<Runnable>) ctx.getClass().getMethod(taskGetter).invoke(ctx);
            for (Runnable r : tasks) {
               r.run();
            }
         } catch (Exception e) {
            Throwable cause = e.getCause() == null ? e : e.getCause();
            throw new IllegalStateException("A mod failed during " + label + ": " + cause, cause);
         }
      }
   }
}
