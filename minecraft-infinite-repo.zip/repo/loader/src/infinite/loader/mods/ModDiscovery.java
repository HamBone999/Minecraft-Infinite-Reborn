package infinite.loader.mods;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Finds mod jars in a {@code mods/} folder and reads their manifests.
 *
 * <p>A jar is a mod if it contains {@code META-INF/infinite.mods.toml}. Anything else in the
 * folder is reported and skipped rather than silently ignored, because a jar that quietly does
 * nothing is one of the more annoying things to debug.
 */
public final class ModDiscovery {

   public static final String MANIFEST = "META-INF/infinite.mods.toml";

   public static final class Found {
      public final List<ModInfo> mods = new ArrayList<ModInfo>();
      public final List<File> jars = new ArrayList<File>();
      public final List<String> warnings = new ArrayList<String>();
   }

   private ModDiscovery() {
   }

   public static Found scan(File modsDir) {
      Found found = new Found();
      if (modsDir == null || !modsDir.isDirectory()) {
         return found;
      }
      File[] files = modsDir.listFiles();
      if (files == null) {
         return found;
      }
      Arrays.sort(files);

      for (File f : files) {
         if (f.isDirectory() || f.getName().startsWith(".")) {
            continue;
         }
         String lower = f.getName().toLowerCase();
         if (lower.endsWith(".jar.disabled") || lower.endsWith(".disabled")) {
            found.warnings.add("skipped (disabled): " + f.getName());
            continue;
         }
         if (!lower.endsWith(".jar")) {
            found.warnings.add("not a jar, ignored: " + f.getName());
            continue;
         }
         try {
            String toml = read(f, MANIFEST);
            if (toml == null) {
               found.warnings.add("no " + MANIFEST + ", ignored: " + f.getName());
               continue;
            }
            List<ModInfo> declared = ModInfo.parse(toml, f);
            found.mods.addAll(declared);
            found.jars.add(f);
         } catch (Exception e) {
            found.warnings.add("could not read " + f.getName() + ": " + e.getMessage());
         }
      }
      return found;
   }

   /** Read one entry out of a jar, or null when it is not there. */
   public static String read(File jar, String entry) throws IOException {
      ZipFile zip = new ZipFile(jar);
      try {
         ZipEntry e = zip.getEntry(entry);
         if (e == null) {
            return null;
         }
         InputStream in = zip.getInputStream(e);
         try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) > 0) {
               out.write(buf, 0, r);
            }
            return new String(out.toByteArray(), "UTF-8");
         } finally {
            in.close();
         }
      } finally {
         zip.close();
      }
   }
}
