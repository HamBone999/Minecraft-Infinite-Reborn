package infinite.loader.mods;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * A TOML reader covering the subset mod metadata uses.
 *
 * <p>Supports top level key/value pairs, {@code [table]}, {@code [[array.of.tables]]}, dotted
 * keys, strings (basic, literal and multi-line), integers, floats, booleans and inline arrays.
 * It does not support inline tables, dates or the more exotic escapes, because no mod manifest
 * needs them.
 *
 * <p>Written rather than pulled in because the loader runs before anything else is on the
 * classpath and adding a dependency there costs more than the ~200 lines this takes.
 *
 * <p>Tables become {@link Map}, arrays of tables become {@link List} of Map, everything else
 * maps to the obvious Java type.
 */
public final class Toml {

   private final String src;
   private int pos;

   private Toml(String src) {
      this.src = src;
   }

   public static Map<String, Object> parse(String text) {
      return new Toml(text).document();
   }

   // =====================================================================================

   private Map<String, Object> document() {
      Map<String, Object> root = new LinkedHashMap<String, Object>();
      Map<String, Object> current = root;

      while (true) {
         skipDead();
         if (pos >= src.length()) {
            return root;
         }
         if (peek() == '[') {
            boolean arrayOfTables = pos + 1 < src.length() && src.charAt(pos + 1) == '[';
            pos += arrayOfTables ? 2 : 1;
            List<String> path = headerPath();
            expect(']');
            if (arrayOfTables) {
               expect(']');
            }
            current = arrayOfTables ? appendTable(root, path) : descend(root, path);
         } else {
            List<String> key = keyPath();
            skipInline();
            expect('=');
            skipInline();
            Object value = value();
            Map<String, Object> target = key.size() == 1
               ? current
               : descend(current, key.subList(0, key.size() - 1));
            target.put(key.get(key.size() - 1), value);
         }
      }
   }

   /** Walk (creating as needed) to the table at {@code path}. */
   @SuppressWarnings("unchecked")
   private Map<String, Object> descend(Map<String, Object> from, List<String> path) {
      Map<String, Object> node = from;
      for (String part : path) {
         Object next = node.get(part);
         if (next instanceof List) {
            List<Object> l = (List<Object>) next;          // last element of an array of tables
            next = l.isEmpty() ? null : l.get(l.size() - 1);
         }
         if (!(next instanceof Map)) {
            Map<String, Object> made = new LinkedHashMap<String, Object>();
            node.put(part, made);
            node = made;
         } else {
            node = (Map<String, Object>) next;
         }
      }
      return node;
   }

   @SuppressWarnings("unchecked")
   private Map<String, Object> appendTable(Map<String, Object> root, List<String> path) {
      Map<String, Object> parent = path.size() == 1
         ? root
         : descend(root, path.subList(0, path.size() - 1));
      String name = path.get(path.size() - 1);
      Object existing = parent.get(name);
      List<Object> list;
      if (existing instanceof List) {
         list = (List<Object>) existing;
      } else {
         list = new ArrayList<Object>();
         parent.put(name, list);
      }
      Map<String, Object> made = new LinkedHashMap<String, Object>();
      list.add(made);
      return made;
   }

   // =====================================================================================

   private List<String> headerPath() {
      skipInline();
      List<String> path = keyPath();
      skipInline();
      return path;
   }

   private List<String> keyPath() {
      List<String> out = new ArrayList<String>();
      while (true) {
         skipInline();
         out.add(bareOrQuoted());
         skipInline();
         if (pos < src.length() && peek() == '.') {
            pos++;
            continue;
         }
         return out;
      }
   }

   private String bareOrQuoted() {
      if (pos >= src.length()) {
         throw error("expected a key");
      }
      char c = peek();
      if (c == '"' || c == '\'') {
         return quoted();
      }
      int start = pos;
      while (pos < src.length()) {
         char k = src.charAt(pos);
         if (Character.isLetterOrDigit(k) || k == '_' || k == '-') {
            pos++;
         } else {
            break;
         }
      }
      if (start == pos) {
         throw error("expected a key");
      }
      return src.substring(start, pos);
   }

   private Object value() {
      if (pos >= src.length()) {
         throw error("expected a value");
      }
      char c = peek();
      if (c == '"' || c == '\'') {
         return quoted();
      }
      if (c == '[') {
         return array();
      }
      int start = pos;
      while (pos < src.length() && "\r\n#,]".indexOf(src.charAt(pos)) < 0) {
         pos++;
      }
      String raw = src.substring(start, pos).trim();
      if (raw.equals("true")) {
         return Boolean.TRUE;
      }
      if (raw.equals("false")) {
         return Boolean.FALSE;
      }
      String numeric = raw.replace("_", "");
      try {
         if (numeric.indexOf('.') >= 0 || numeric.indexOf('e') >= 0 || numeric.indexOf('E') >= 0) {
            return Double.valueOf(numeric);
         }
         return Long.valueOf(numeric);
      } catch (NumberFormatException notANumber) {
         return raw;
      }
   }

   private List<Object> array() {
      expect('[');
      List<Object> out = new ArrayList<Object>();
      while (true) {
         skipDead();
         if (pos >= src.length()) {
            throw error("unterminated array");
         }
         if (peek() == ']') {
            pos++;
            return out;
         }
         out.add(value());
         skipDead();
         if (pos < src.length() && peek() == ',') {
            pos++;
         }
      }
   }

   private String quoted() {
      char q = src.charAt(pos);
      boolean multi = src.startsWith(String.valueOf(new char[]{q, q, q}), pos);
      pos += multi ? 3 : 1;
      StringBuilder b = new StringBuilder();
      while (pos < src.length()) {
         char c = src.charAt(pos);
         if (multi && src.startsWith(String.valueOf(new char[]{q, q, q}), pos)) {
            pos += 3;
            return b.toString();
         }
         if (!multi && c == q) {
            pos++;
            return b.toString();
         }
         if (c == '\\' && q == '"') {
            pos++;
            b.append(escape());
            continue;
         }
         b.append(c);
         pos++;
      }
      throw error("unterminated string");
   }

   private char escape() {
      char c = src.charAt(pos++);
      switch (c) {
         case 'n': return '\n';
         case 't': return '\t';
         case 'r': return '\r';
         case '"': return '"';
         case '\\': return '\\';
         case 'u': {
            String hex = src.substring(pos, pos + 4);
            pos += 4;
            return (char) Integer.parseInt(hex, 16);
         }
         default: return c;
      }
   }

   // =====================================================================================

   /** Whitespace, newlines and comments. */
   private void skipDead() {
      while (pos < src.length()) {
         char c = src.charAt(pos);
         if (c == '#') {
            while (pos < src.length() && src.charAt(pos) != '\n') {
               pos++;
            }
         } else if (Character.isWhitespace(c)) {
            pos++;
         } else {
            return;
         }
      }
   }

   /** Whitespace that does not end a statement. */
   private void skipInline() {
      while (pos < src.length() && (src.charAt(pos) == ' ' || src.charAt(pos) == '\t')) {
         pos++;
      }
   }

   private char peek() {
      return src.charAt(pos);
   }

   private void expect(char c) {
      skipInline();
      if (pos >= src.length() || src.charAt(pos) != c) {
         throw error("expected '" + c + "'");
      }
      pos++;
   }

   private IllegalArgumentException error(String message) {
      int line = 1;
      for (int i = 0; i < pos && i < src.length(); i++) {
         if (src.charAt(i) == '\n') {
            line++;
         }
      }
      return new IllegalArgumentException(message + " at line " + line);
   }
}
