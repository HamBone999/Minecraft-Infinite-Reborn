package infinite.loader.mods;

/**
 * Maven style version ranges, the same notation NeoForge uses.
 *
 * <pre>
 *   [1.0,2.0)     1.0 inclusive to 2.0 exclusive
 *   [1.0,)        1.0 or newer
 *   (,2.0]        up to and including 2.0
 *   [1.2.3]       exactly 1.2.3
 *   1.0           shorthand for [1.0,)
 *   ""            anything
 * </pre>
 *
 * <p>Comparison is numeric segment by segment, so 1.10 is newer than 1.9. A non numeric
 * segment (a "-beta3" tail) compares lexically and sorts below the same version without one,
 * which matches the usual expectation that a release beats its own pre-releases.
 */
public final class Versions {

   private Versions() {
   }

   public static boolean satisfies(String version, String range) {
      if (range == null || range.trim().isEmpty()) {
         return true;
      }
      String r = range.trim();
      if (r.charAt(0) != '[' && r.charAt(0) != '(') {
         return compare(version, r) >= 0;                  // bare version means "or newer"
      }

      boolean lowInclusive = r.charAt(0) == '[';
      boolean highInclusive = r.charAt(r.length() - 1) == ']';
      String body = r.substring(1, r.length() - 1);

      int comma = body.indexOf(',');
      if (comma < 0) {
         return compare(version, body.trim()) == 0;        // [1.2.3] is an exact pin
      }

      String low = body.substring(0, comma).trim();
      String high = body.substring(comma + 1).trim();

      if (!low.isEmpty()) {
         int c = compare(version, low);
         if (c < 0 || (c == 0 && !lowInclusive)) {
            return false;
         }
      }
      if (!high.isEmpty()) {
         int c = compare(version, high);
         if (c > 0 || (c == 0 && !highInclusive)) {
            return false;
         }
      }
      return true;
   }

   public static int compare(String a, String b) {
      String[] left = split(a);
      String[] right = split(b);
      int n = Math.max(left.length, right.length);
      for (int i = 0; i < n; i++) {
         String l = i < left.length ? left[i] : "0";
         String r = i < right.length ? right[i] : "0";
         int c = compareSegment(l, r);
         if (c != 0) {
            return c;
         }
      }
      return 0;
   }

   private static String[] split(String v) {
      return (v == null ? "0" : v.trim()).split("[.\\-+]");
   }

   private static int compareSegment(String l, String r) {
      boolean ln = isNumeric(l);
      boolean rn = isNumeric(r);
      if (ln && rn) {
         return Long.compare(Long.parseLong(l), Long.parseLong(r));
      }
      // A numeric segment outranks a qualifier, so 1.0 is newer than 1.0-beta.
      if (ln) {
         return 1;
      }
      if (rn) {
         return -1;
      }
      return l.compareToIgnoreCase(r);
   }

   private static boolean isNumeric(String s) {
      if (s.isEmpty()) {
         return false;
      }
      for (int i = 0; i < s.length(); i++) {
         if (!Character.isDigit(s.charAt(i))) {
            return false;
         }
      }
      return true;
   }
}
