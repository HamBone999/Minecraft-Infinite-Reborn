package infinite.loader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Launcher profile registration.
 *
 * <p>Infinite is registered as a version the launcher already knows how to run, so it appears
 * in the version list alongside everything else and the launcher supplies Java, memory,
 * accounts, natives and the game directory.
 *
 * <p>No patching is involved. The official Alpha 1.0.4 jar and {@code Infinite.jar} on one
 * classpath, with {@code net.minecraft.client.Minecraft} as the main class, is a working game.
 * The 27 Mojang textures resolve out of the official jar because it is already on that
 * classpath, so the asset extraction the standalone loader performs is unnecessary here.
 *
 * <p>Two launcher families:
 * <ul>
 *   <li><b>Mojang launcher</b> - a version JSON that {@code inheritsFrom} a1.0.4, adding the
 *       Infinite library and overriding LWJGL, plus an entry in
 *       {@code launcher_profiles.json}.</li>
 *   <li><b>Prism / MultiMC</b> - an instance whose {@code mmc-pack.json} lists Minecraft
 *       a1.0.4, LWJGL 2.9.4 and an Infinite component.</li>
 * </ul>
 */
final class Profiles {

   static final String GROUP_PATH = "gg/infinite/infinite";
   private static final String LWJGL_VERSION = "2.9.4-nightly-20150209";

   private Profiles() {
   }

   // =====================================================================================
   // Mojang launcher
   // =====================================================================================

   /**
    * Install into a {@code .minecraft} directory.
    *
    * @return the version id that was registered
    */
   static String installMojang(File dotMinecraft, File modJar, String version,
                               Loader.Progress p) throws IOException {
      String id = "infinite-" + version;

      // The launcher holds launcher_profiles.json in memory and rewrites it on exit, so an
      // edit made while it is open is discarded. This is the most common reason a freshly
      // installed profile does not appear.
      p.step("NOTE: close the Minecraft launcher completely before running this.");
      p.step("      It rewrites launcher_profiles.json on exit and will undo the change.");
      p.step("");

      if (!new File(dotMinecraft, "launcher_profiles.json").isFile()
         && !new File(dotMinecraft, "versions").isDirectory()) {
         throw new IOException(dotMinecraft + " does not look like a .minecraft folder"
            + " (no launcher_profiles.json and no versions/).");
      }

      // inheritsFrom only resolves if the parent version is actually installed.
      File parentJson = new File(dotMinecraft, "versions/a1.0.4/a1.0.4.json");
      if (!parentJson.isFile()) {
         throw new IOException("Alpha 1.0.4 is not installed in this launcher.\n"
            + "  expected " + parentJson + "\n\n"
            + "The Infinite profile inherits from it, so it has to exist first."
            + " In the launcher:\n"
            + "  Installations -> New -> tick \"historical versions\" in the version filter\n"
            + "  -> pick a1.0.4 -> create it and launch it once.\n"
            + "Then run this again.");
      }
      p.step("parent   : found versions/a1.0.4/a1.0.4.json");

      File lib = new File(dotMinecraft,
         "libraries/" + GROUP_PATH + "/" + version + "/infinite-" + version + ".jar");
      copy(modJar, lib);
      p.step("library  -> " + rel(dotMinecraft, lib));

      // Same 27 renamed textures as the Prism path needs, delivered as a second library.
      boolean haveAssets = false;
      File baseJar = Assets.findBaseJar(dotMinecraft, true);
      if (baseJar != null) {
         File assetsLib = new File(dotMinecraft, "libraries/" + GROUP_PATH + "-assets/"
            + version + "/infinite-assets-" + version + ".jar");
         File parentDir = assetsLib.getParentFile();
         if (parentDir != null && !parentDir.isDirectory() && !parentDir.mkdirs()) {
            throw new IOException("could not create " + parentDir);
         }
         int n = Assets.build(baseJar, assetsLib);
         haveAssets = true;
         p.step("assets   -> " + rel(dotMinecraft, assetsLib) + "  (" + n + " textures)");
      } else {
         for (String line : Assets.missingBaseJarAdvice(true).split("\n")) {
            p.step(line);
         }
      }

      File versionDir = new File(dotMinecraft, "versions/" + id);
      if (!versionDir.isDirectory() && !versionDir.mkdirs()) {
         throw new IOException("could not create " + versionDir);
      }
      File json = new File(versionDir, id + ".json");
      write(json, versionJson(id, version, haveAssets));
      p.step("version  -> " + rel(dotMinecraft, json));

      File profiles = new File(dotMinecraft, "launcher_profiles.json");
      addProfile(profiles, id, version);
      p.step("profile  -> " + rel(dotMinecraft, profiles));
      return id;
   }

   /**
    * A child version JSON. {@code inheritsFrom} pulls in a1.0.4's own libraries, assets and
    * arguments; this adds the mod jar and moves LWJGL up to the version the mod expects.
    *
    * <p>Libraries listed here are placed ahead of the inherited ones, so the newer LWJGL
    * takes precedence.
    */
   private static String versionJson(String id, String version, boolean withAssets) {
      StringBuilder b = new StringBuilder();
      b.append("{\n");
      b.append("  \"id\": \"").append(id).append("\",\n");
      b.append("  \"inheritsFrom\": \"a1.0.4\",\n");
      b.append("  \"type\": \"old_alpha\",\n");
      b.append("  \"mainClass\": \"net.minecraft.client.Minecraft\",\n");
      b.append("  \"minecraftArguments\": \"${auth_player_name} ${auth_session}\",\n");
      b.append("  \"libraries\": [\n");
      b.append("    { \"name\": \"gg.infinite:infinite:").append(version).append("\" },\n");
      if (withAssets) {
         b.append("    { \"name\": \"gg.infinite:infinite-assets:")
          .append(version).append("\" },\n");
      }
      b.append(lwjgl("org.lwjgl.lwjgl:lwjgl:")).append(",\n");
      b.append(lwjgl("org.lwjgl.lwjgl:lwjgl_util:")).append(",\n");
      b.append(lwjglNatives()).append("\n");
      b.append("  ]\n");
      b.append("}\n");
      return b.toString();
   }

   private static String lwjgl(String coord) {
      return "    { \"name\": \"" + coord + LWJGL_VERSION + "\","
         + " \"url\": \"https://libraries.minecraft.net/\" }";
   }

   private static String lwjglNatives() {
      return "    { \"name\": \"org.lwjgl.lwjgl:lwjgl-platform:" + LWJGL_VERSION + "\","
         + " \"url\": \"https://libraries.minecraft.net/\","
         + " \"natives\": { \"windows\": \"natives-windows\","
         + " \"linux\": \"natives-linux\", \"osx\": \"natives-osx\" },"
         + " \"extract\": { \"exclude\": [ \"META-INF/\" ] } }";
   }

   /**
    * Add an entry to launcher_profiles.json without disturbing what is already there. The
    * edit is textual and deliberately minimal: the file holds the player's accounts and every
    * other profile, so a full reserialise risks losing data that is not modelled here.
    */
   private static void addProfile(File file, String id, String version) throws IOException {
      String key = "infinite-" + version;
      // The launcher sorts installations by lastUsed, and a profile without one sorts to the
      // bottom of a long list where it looks absent.
      String now = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
         .format(new java.util.Date());
      String entry = "\"" + key + "\": {"
         + "\"name\": \"Minecraft Infinite " + version + "\","
         + "\"type\": \"custom\","
         + "\"icon\": \"Grass\","
         + "\"lastVersionId\": \"" + id + "\","
         + "\"created\": \"" + now + "\","
         + "\"lastUsed\": \"" + now + "\","
         + "\"javaArgs\": \"-Xmx2G -Djava.util.Arrays.useLegacyMergeSort=true\""
         + "}";

      if (!file.isFile()) {
         write(file, "{\n  \"profiles\": {\n    " + entry + "\n  },\n  \"version\": 3\n}\n");
         return;
      }

      String text = read(file);
      if (text.contains("\"" + key + "\"")) {
         return;                                   // already registered
      }
      int i = text.indexOf("\"profiles\"");
      if (i < 0) {
         throw new IOException("launcher_profiles.json has no \"profiles\" section; not"
            + " editing it. Add the profile by hand, or register with Prism instead.");
      }
      int brace = text.indexOf('{', i);
      if (brace < 0) {
         throw new IOException("launcher_profiles.json is not shaped as expected");
      }
      // back up the original before touching it
      copyBytes(file, new File(file.getAbsolutePath() + ".infinite-backup"));

      int after = brace + 1;
      String rest = text.substring(after).trim();
      String sep = rest.startsWith("}") ? "" : ",";
      String out = text.substring(0, after) + "\n    " + entry + sep + text.substring(after);
      write(file, out);
   }

   // =====================================================================================
   // Prism / MultiMC
   // =====================================================================================

   /**
    * Build an instance directory Prism and MultiMC can both import.
    *
    * <h2>Why this overrides net.minecraft</h2>
    *
    * <p>Upstream's a1.0.4 component launches the game through MultiMC's legacy applet path:
    *
    * <pre>
    *   "mainClass": "ax",
    *   "+traits": [ "legacyLaunch", "no-texturepacks" ]
    * </pre>
    *
    * <p>{@code legacyLaunch} is not a hint, it selects a different launcher entirely, and it
    * starts vanilla's obfuscated {@code ax}. Adding an Infinite component alongside it does
    * nothing: the jar lands on the classpath and is never called into, so the instance boots
    * cleanly into the base game. That is a silent failure with no error to go on.
    *
    * <p>So the instance carries its own {@code net.minecraft} patch that drops
    * {@code legacyLaunch} and names Infinite's real main class. A local patch replaces the
    * component outright rather than merging, which is why every field has to be repeated here.
    *
    * <p>Infinite ships as a jar mod rather than a library for the same reason a working
    * instance does: MultiMC merges jar mods into the main jar, so the mod's classes are
    * present under the names the game asks for, and the 27 Mojang textures still resolve from
    * the vanilla half of the merge.
    */
   static void installPrism(File instanceDir, File modJar, String version, Loader.Progress p)
         throws IOException {
      File patches = new File(instanceDir, "patches");
      File jarmods = new File(instanceDir, "jarmods");
      if (!patches.isDirectory() && !patches.mkdirs()) {
         throw new IOException("could not create " + patches);
      }
      if (!jarmods.isDirectory() && !jarmods.mkdirs()) {
         throw new IOException("could not create " + jarmods);
      }

      String jarName = "Infinite-" + version + ".jar";
      File jar = new File(jarmods, jarName);
      copy(modJar, jar);
      if (!jar.isFile() || jar.length() != modJar.length()) {
         throw new IOException("wrote " + jar + " but it is not there afterwards."
            + " Check the folder is writable.");
      }
      p.step("jarmod   -> jarmods/" + jarName + "  (" + jar.length() + " bytes)");

      // The 27 renamed Mojang textures. A jar mod merge does not rename anything, so without
      // these the shadow and menu background draw as missing-texture squares.
      String assetsName = "InfiniteAssets-" + version + ".jar";
      File assetsJar = new File(jarmods, assetsName);
      boolean haveAssets = false;
      File launcherRoot = instanceDir.getParentFile() == null
         ? null : instanceDir.getParentFile().getParentFile();
      File baseJar = launcherRoot == null ? null : Assets.findBaseJar(launcherRoot, false);
      if (baseJar != null) {
         int n = Assets.build(baseJar, assetsJar);
         haveAssets = true;
         p.step("assets   -> jarmods/" + assetsName + "  (" + n + " textures)");
      } else {
         for (String line : Assets.missingBaseJarAdvice(false).split("\n")) {
            p.step(line);
         }
      }

      // An earlier build of this installer shipped Infinite as a library. That layout boots
      // the base game, so clearing it out is part of upgrading rather than tidiness.
      File staleLibs = new File(instanceDir, "libraries");
      if (staleLibs.isDirectory() && deleteTree(staleLibs)) {
         p.step("cleaned  : removed the libraries/ layout from a previous install");
      }

      write(new File(patches, "net.minecraft.json"), minecraftOverride());
      p.step("patch    -> patches/net.minecraft.json  (drops legacyLaunch)");

      // The assets jar is listed first so the mod jar wins any name it also defines. In
      // practice they do not overlap, but the order is the one that stays correct if they
      // ever do.
      StringBuilder mods = new StringBuilder();
      if (haveAssets) {
         mods.append("        {\n")
             .append("            \"name\": \"org.multimc.jarmods:infinite-assets:")
             .append(version).append("\",\n")
             .append("            \"MMC-displayname\": \"Minecraft Infinite assets\",\n")
             .append("            \"MMC-filename\": \"").append(assetsName).append("\",\n")
             .append("            \"MMC-hint\": \"local\"\n")
             .append("        },\n");
      }
      mods.append("        {\n")
          .append("            \"name\": \"org.multimc.jarmods:infinite:")
          .append(version).append("\",\n")
          .append("            \"MMC-displayname\": \"Minecraft Infinite\",\n")
          .append("            \"MMC-filename\": \"").append(jarName).append("\",\n")
          .append("            \"MMC-hint\": \"local\"\n")
          .append("        }\n");

      write(new File(patches, "custom.jarmod.infinite.json"),
           "{\n"
         + "    \"formatVersion\": 1,\n"
         + "    \"uid\": \"custom.jarmod.infinite\",\n"
         + "    \"name\": \"Minecraft Infinite\",\n"
         + "    \"version\": \"" + version + "\",\n"
         + "    \"jarMods\": [\n"
         + mods
         + "    ]\n"
         + "}\n");

      write(new File(instanceDir, "mmc-pack.json"),
           "{\n"
         + "    \"formatVersion\": 1,\n"
         + "    \"components\": [\n"
         + "        {\n"
         + "            \"cachedName\": \"LWJGL 2\",\n"
         + "            \"cachedVersion\": \"" + LWJGL_VERSION + "\",\n"
         + "            \"cachedVolatile\": true,\n"
         + "            \"dependencyOnly\": true,\n"
         + "            \"uid\": \"org.lwjgl\",\n"
         + "            \"version\": \"" + LWJGL_VERSION + "\"\n"
         + "        },\n"
         + "        {\n"
         + "            \"cachedName\": \"Minecraft\",\n"
         + "            \"important\": true,\n"
         + "            \"uid\": \"net.minecraft\",\n"
         + "            \"version\": \"a1.0.4\"\n"
         + "        },\n"
         + "        {\n"
         + "            \"cachedName\": \"Minecraft Infinite\",\n"
         + "            \"uid\": \"custom.jarmod.infinite\",\n"
         + "            \"version\": \"" + version + "\"\n"
         + "        }\n"
         + "    ]\n"
         + "}\n");

      write(new File(instanceDir, "instance.cfg"),
           "InstanceType=OneSix\n"
         + "OverrideJavaArgs=true\n"
         + "JvmArgs=-Djava.util.Arrays.useLegacyMergeSort=true\n"
         + "iconKey=default\n"
         + "name=Minecraft Infinite " + version + "\n"
         + "notes=\n");

      p.step("instance -> " + instanceDir);
   }

   /**
    * A full replacement for the a1.0.4 component.
    *
    * <p>Everything upstream declares has to be repeated, because a patch with the same uid
    * replaces the component rather than merging into it. The two lines that matter are
    * {@code mainClass} and the absence of {@code legacyLaunch}.
    */
   private static String minecraftOverride() {
      return "{\n"
         + "    \"formatVersion\": 1,\n"
         + "    \"uid\": \"net.minecraft\",\n"
         + "    \"name\": \"Minecraft\",\n"
         + "    \"version\": \"a1.0.4\",\n"
         + "    \"type\": \"old_alpha\",\n"
         + "    \"releaseTime\": \"2010-07-09T00:00:00+02:00\",\n"
         + "    \"mainClass\": \"net.minecraft.client.Minecraft\",\n"
         + "    \"minecraftArguments\": \"${auth_player_name} ${auth_session}\",\n"
         + "    \"+traits\": [ \"texturepacks\" ],\n"
         + "    \"assetIndex\": {\n"
         + "        \"id\": \"pre-1.6\",\n"
         + "        \"sha1\": \"3d8e55480977e32acd9844e545177e69a52f594b\",\n"
         + "        \"size\": 74091,\n"
         + "        \"totalSize\": 49505710,\n"
         + "        \"url\": \"https://launchermeta.mojang.com/v1/packages/"
         + "3d8e55480977e32acd9844e545177e69a52f594b/pre-1.6.json\"\n"
         + "    },\n"
         + "    \"mainJar\": {\n"
         + "        \"name\": \"com.mojang:minecraft:a1.0.4:client\",\n"
         + "        \"downloads\": {\n"
         + "            \"artifact\": {\n"
         + "                \"sha1\": \"e5838277b3bb193e58408713f1fc6e005c5f3c0c\",\n"
         + "                \"size\": 749244,\n"
         + "                \"url\": \"https://launcher.mojang.com/v1/objects/"
         + "e5838277b3bb193e58408713f1fc6e005c5f3c0c/client.jar\"\n"
         + "            }\n"
         + "        }\n"
         + "    },\n"
         + "    \"requires\": [\n"
         + "        { \"uid\": \"org.lwjgl\", \"suggests\": \"" + LWJGL_VERSION + "\" }\n"
         + "    ]\n"
         + "}\n";
   }

   // =====================================================================================
   // Finding launchers
   // =====================================================================================

   /** Directories that look like a .minecraft, in the usual places. */
   static List<File> findMojangLaunchers() {
      List<File> out = new ArrayList<File>();
      String home = System.getProperty("user.home", ".");
      String appdata = System.getenv("APPDATA");
      add(out, appdata == null ? null : new File(appdata, ".minecraft"));
      add(out, new File(home, ".minecraft"));
      add(out, new File(home, "Library/Application Support/minecraft"));
      return out;
   }

   private static void add(List<File> out, File f) {
      if (f != null && f.isDirectory() && !out.contains(f)) {
         out.add(f);
      }
   }

   // =====================================================================================

   /** Recursive delete, used to clear a layout an older installer left behind. */
   private static boolean deleteTree(File f) {
      File[] kids = f.listFiles();
      if (kids != null) {
         for (File k : kids) {
            if (!deleteTree(k)) {
               return false;
            }
         }
      }
      return f.delete();
   }

   private static void copy(File from, File to) throws IOException {
      File parent = to.getParentFile();
      if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
         throw new IOException("could not create " + parent);
      }
      copyBytes(from, to);
   }

   private static void copyBytes(File from, File to) throws IOException {
      InputStream in = new java.io.FileInputStream(from);
      OutputStream out = new FileOutputStream(to);
      try {
         byte[] buf = new byte[1 << 16];
         int r;
         while ((r = in.read(buf)) > 0) {
            out.write(buf, 0, r);
         }
      } finally {
         out.close();
         in.close();
      }
   }

   private static String read(File f) throws IOException {
      byte[] b = new byte[(int) f.length()];
      InputStream in = new java.io.FileInputStream(f);
      try {
         int off = 0;
         int r;
         while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) {
            off += r;
         }
      } finally {
         in.close();
      }
      return new String(b, "UTF-8");
   }

   private static void write(File f, String s) throws IOException {
      File parent = f.getParentFile();
      if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
         throw new IOException("could not create " + parent);
      }
      OutputStream out = new FileOutputStream(f);
      try {
         out.write(s.getBytes("UTF-8"));
      } finally {
         out.close();
      }
   }

   private static String rel(File base, File f) {
      String b = base.getAbsolutePath();
      String p = f.getAbsolutePath();
      return p.startsWith(b) ? p.substring(b.length() + 1) : p;
   }
}
