package infinite.loader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * Builds the Mojang asset jar an installed instance needs.
 *
 * <h2>Why this exists</h2>
 *
 * <p>Infinite reads 27 original textures from Alpha 1.0.4, but it looks for most of them under
 * names it chose rather than the ones Mojang used:
 *
 * <pre>
 *   misc/shadow.png                &lt;- shadow.png
 *   gui/background/background.png  &lt;- dirt.png
 *   mob/creeper/creeper.png        &lt;- mob/creeper.png
 * </pre>
 *
 * <p>The standalone loader handles that by extracting them into {@code assets-cache/} with the
 * rename applied. A launcher install has no loader: MultiMC merges the jar mod into the
 * vanilla jar, and the Mojang launcher puts both on one classpath. Neither renames anything,
 * so every renamed asset resolves to nothing and draws as the missing-texture checkerboard.
 * Entity shadows and the menu background are the two most visible.
 *
 * <p>So the installer builds a small jar containing exactly those 27 files, at the paths
 * Infinite asks for, taken from the player's own copy of the game. Nothing here is
 * redistributed; the jar is assembled on the player's machine from a file they already have.
 */
final class Assets {

   private static final String ASSET_LIST = "/mojang-assets.txt";

   private Assets() {
   }

   /** Destination path inside the built jar to source path inside the official jar. */
   static Map<String, String> list() throws IOException {
      Map<String, String> out = new LinkedHashMap<String, String>();
      InputStream in = Assets.class.getResourceAsStream(ASSET_LIST);
      if (in == null) {
         throw new IOException("asset list missing from the installer jar; this build is broken");
      }
      java.io.BufferedReader r =
         new java.io.BufferedReader(new java.io.InputStreamReader(in, "UTF-8"));
      try {
         String line;
         while ((line = r.readLine()) != null) {
            String s = line.trim();
            if (s.isEmpty() || s.startsWith("#")) {
               continue;
            }
            int arrow = s.indexOf("<-");
            if (arrow >= 0) {
               out.put(s.substring(0, arrow).trim(), s.substring(arrow + 2).trim());
            } else {
               out.put(s, s);
            }
         }
      } finally {
         r.close();
      }
      return out;
   }

   /**
    * Write a jar of the renamed Mojang assets.
    *
    * @return how many were written
    */
   static int build(File baseJar, File outJar) throws IOException {
      Map<String, String> assets = list();
      File parent = outJar.getParentFile();
      if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
         throw new IOException("could not create " + parent);
      }

      ZipFile zip = new ZipFile(baseJar);
      ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outJar));
      int n = 0;
      try {
         for (Map.Entry<String, String> e : assets.entrySet()) {
            ZipEntry source = zip.getEntry(e.getValue());
            if (source == null) {
               throw new IOException("the base jar has no '" + e.getValue()
                  + "'. Wrong version, or a damaged download.");
            }
            out.putNextEntry(new ZipEntry(e.getKey()));
            InputStream in = zip.getInputStream(source);
            try {
               byte[] buf = new byte[8192];
               int r;
               while ((r = in.read(buf)) > 0) {
                  out.write(buf, 0, r);
               }
            } finally {
               in.close();
            }
            out.closeEntry();
            n++;
         }
      } finally {
         out.close();
         zip.close();
      }
      return n;
   }

   /**
    * Find the player's Alpha 1.0.4 jar for a given launcher.
    *
    * <p>The two families store it differently, and neither has it before the version has been
    * downloaded at least once.
    *
    * @return the jar, or null when it is not there yet
    */
   static File findBaseJar(File launcherRoot, boolean mojangLauncher) {
      File[] candidates = mojangLauncher
         ? new File[]{
              new File(launcherRoot, "versions/a1.0.4/a1.0.4.jar"),
              new File(launcherRoot,
                 "libraries/com/mojang/minecraft/a1.0.4/minecraft-a1.0.4-client.jar"),
           }
         : new File[]{
              new File(launcherRoot,
                 "libraries/com/mojang/minecraft/a1.0.4/minecraft-a1.0.4-client.jar"),
              new File(launcherRoot, "versions/a1.0.4/a1.0.4.jar"),
           };
      for (File f : candidates) {
         if (f.isFile() && f.length() > 0) {
            return f;
         }
      }
      return null;
   }

   /** What to tell someone when the base jar is not on disk yet. */
   static String missingBaseJarAdvice(boolean mojangLauncher) {
      return "NOTE: could not find your Alpha 1.0.4 jar, so 27 Mojang textures were not"
         + " installed.\n"
         + "      Entity shadows and the menu background will show as purple and black"
         + " squares.\n"
         + "      Launch " + (mojangLauncher ? "the a1.0.4 installation" : "an a1.0.4 instance")
         + " once so the launcher downloads it, then run this installer again.";
   }
}
