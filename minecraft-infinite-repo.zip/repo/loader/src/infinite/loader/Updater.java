package infinite.loader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Update channel and library resolution.
 *
 * <p>A manifest describes the release: which files make it up, their hashes and sizes, and
 * where to get them. Everything is verified by SHA-1 rather than trusted by name, so a
 * truncated download or a stale mirror fails loudly instead of producing a broken install.
 *
 * <p>Two jobs:
 * <ul>
 *   <li><b>Libraries</b> - resolve LWJGL and the rest from a local cache, then from the
 *       player's launcher, and only then from the network. None of it is redistributed here;
 *       every artifact is either already on disk or fetched from its own upstream.</li>
 *   <li><b>Updates</b> - compare the local manifest against a remote one and pull down
 *       whatever changed. The mod jar can be replaced in place because nothing has opened it
 *       yet. The loader's own jar is locked while running on Windows, so a replacement lands
 *       beside it as {@code .new} and is left for the installer to deal with.</li>
 * </ul>
 */
final class Updater {

   private static final int TIMEOUT_MS = 20_000;

   private Updater() {
   }

   // =====================================================================================
   // Libraries
   // =====================================================================================

   static final class Lib {
      String path;      // relative location under libraries/
      String sha1;
      long size;
      String url;
      boolean natives;
   }

   /**
    * Read the library list for this platform out of a manifest.
    * Entries carrying a {@code natives} map contribute the binary for this OS only.
    */
   static List<Lib> libraries(Map<String, Object> manifest, String osTag, boolean arm64) {
      List<Lib> out = new ArrayList<Lib>();
      List<Object> libs = Json.arr(manifest.get("libraries"));
      if (libs == null) {
         return out;
      }
      String want = arm64 ? osTag + "-arm64" : osTag;
      for (Object o : libs) {
         Map<String, Object> m = Json.obj(o);
         if (m == null) {
            continue;
         }
         Map<String, Object> artifact = Json.obj(m.get("artifact"));
         if (artifact != null) {
            out.add(toLib(artifact, false));
         }
         Map<String, Object> natives = Json.obj(m.get("natives"));
         if (natives != null) {
            Map<String, Object> pick = Json.obj(natives.get(want));
            if (pick == null && arm64) {
               pick = Json.obj(natives.get(osTag));   // fall back to the x86-64 build
            }
            if (pick != null) {
               out.add(toLib(pick, true));
            }
         }
      }
      return out;
   }

   private static Lib toLib(Map<String, Object> m, boolean natives) {
      Lib l = new Lib();
      l.path = Json.str(m, "path");
      l.sha1 = Json.str(m, "sha1");
      l.size = Json.num(m, "size", -1);
      l.url = Json.str(m, "url");
      l.natives = natives;
      return l;
   }

   /**
    * Ensure every library is present in {@code cacheDir}, taking it from the launcher's own
    * library tree when possible so nothing needs downloading.
    *
    * @return the resolved files, in manifest order
    */
   static List<File> resolve(List<Lib> libs, File cacheDir, File launcherLibraries,
                             Loader.Progress progress) throws IOException {
      List<File> out = new ArrayList<File>();
      for (Lib l : libs) {
         File target = new File(cacheDir, l.path.replace('/', File.separatorChar));
         if (ok(target, l.sha1, l.size)) {
            out.add(target);
            continue;
         }

         // The launcher may already have this artifact.
         if (launcherLibraries != null) {
            File fromLauncher = new File(launcherLibraries, l.path.replace('/', File.separatorChar));
            if (ok(fromLauncher, l.sha1, l.size)) {
               out.add(fromLauncher);
               continue;
            }
         }

         if (l.url == null) {
            throw new IOException("Library " + l.path + " is missing and the manifest gives no"
               + " URL to fetch it from.");
         }
         progress.step("downloading " + name(l.path));
         download(l.url, target, l.sha1);
         out.add(target);
      }
      return out;
   }

   // =====================================================================================
   // Updates
   // =====================================================================================

   static final class Update {
      String version;
      Map<String, Object> remote;
      final List<String> changed = new ArrayList<String>();
   }

   /**
    * Compare the shipped manifest with the one at {@code url}.
    *
    * @return what would change, or null if the install is current or the check could not run
    */
   static Update check(Map<String, Object> local, String url) {
      try {
         Map<String, Object> remote = Json.obj(Json.parse(fetch(url)));
         if (remote == null) {
            return null;
         }
         String here = Json.str(local, "version");
         String there = Json.str(remote, "version");
         if (there == null || there.equals(here)) {
            return null;
         }
         Update u = new Update();
         u.version = there;
         List<Object> files = Json.arr(remote.get("files"));
         if (files != null) {
            for (Object o : files) {
               String p = Json.str(Json.obj(o), "path");
               if (p != null) {
                  u.changed.add(p);
               }
            }
         }
         u.remote = remote;
         return u;
      } catch (Exception e) {
         // A failed update check must not block launching.
         return null;
      }
   }

   /**
    * Download the files in an update. The loader's own jar cannot be overwritten while it is
    * running on Windows, so it is written alongside as {@code .new} and swapped by the start
    * script next time.
    */
   static void apply(Update u, File dir, String selfName, Loader.Progress progress)
         throws IOException {
      List<Object> files = Json.arr(u.remote.get("files"));
      if (files == null) {
         return;
      }
      for (Object o : files) {
         Map<String, Object> m = Json.obj(o);
         String path = Json.str(m, "path");
         String sha1 = Json.str(m, "sha1");
         String url = Json.str(m, "url");
         long size = Json.num(m, "size", -1);
         if (path == null || url == null) {
            continue;
         }
         File target = new File(dir, path.replace('/', File.separatorChar));
         if (ok(target, sha1, size)) {
            continue;
         }
         boolean self = path.equals(selfName);
         File dest = self ? new File(dir, selfName + ".new") : target;
         progress.step("updating " + path);
         download(url, dest, sha1);
      }
      // Write the manifest last, so an interrupted update is retried rather than assumed
      // complete on the next run.
      String manifestUrl = Json.str(u.remote, "self");
      if (manifestUrl != null) {
         download(manifestUrl, new File(dir, "version.json"), null);
      }
   }

   // =====================================================================================

   static boolean ok(File f, String sha1, long size) {
      if (f == null || !f.isFile()) {
         return false;
      }
      if (size >= 0 && f.length() != size) {
         return false;
      }
      return sha1 == null || sha1.equalsIgnoreCase(Loader.sha1(f));
   }

   static String fetch(String url) throws IOException {
      HttpURLConnection c = open(url);
      InputStream in = c.getInputStream();
      try {
         java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream();
         byte[] buf = new byte[8192];
         int r;
         while ((r = in.read(buf)) > 0) {
            b.write(buf, 0, r);
         }
         return new String(b.toByteArray(), "UTF-8");
      } finally {
         in.close();
         c.disconnect();
      }
   }

   /** Download to a temporary file and only move it into place once the hash checks out. */
   static void download(String url, File target, String expectSha1) throws IOException {
      File parent = target.getParentFile();
      if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
         throw new IOException("could not create " + parent);
      }
      File tmp = new File(target.getAbsolutePath() + ".part");
      HttpURLConnection c = open(url);
      InputStream in = c.getInputStream();
      OutputStream out = new FileOutputStream(tmp);
      try {
         byte[] buf = new byte[1 << 16];
         int r;
         while ((r = in.read(buf)) > 0) {
            out.write(buf, 0, r);
         }
      } finally {
         out.close();
         in.close();
         c.disconnect();
      }
      if (expectSha1 != null && !expectSha1.equalsIgnoreCase(Loader.sha1(tmp))) {
         boolean ignored = tmp.delete();
         throw new IOException("checksum mismatch downloading " + url);
      }
      if (target.isFile() && !target.delete()) {
         throw new IOException("could not replace " + target);
      }
      if (!tmp.renameTo(target)) {
         throw new IOException("could not move " + tmp + " into place");
      }
   }

   private static HttpURLConnection open(String url) throws IOException {
      HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
      c.setConnectTimeout(TIMEOUT_MS);
      c.setReadTimeout(TIMEOUT_MS);
      c.setInstanceFollowRedirects(true);
      c.setRequestProperty("User-Agent", "InfiniteLoader");
      int code = c.getResponseCode();
      if (code / 100 != 2) {
         throw new IOException("HTTP " + code + " for " + url);
      }
      return c;
   }

   private static String name(String path) {
      int i = path.lastIndexOf('/');
      return i < 0 ? path : path.substring(i + 1);
   }
}
