package infinite.loader;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Installer.
 *
 * <p>Registers Minecraft Infinite with the launchers found on this machine, so it appears in
 * the version list alongside everything else and the launcher handles Java, memory, accounts
 * and natives.
 *
 * <p>Nothing in an existing Minecraft install is modified. The mod does not patch the game; it
 * runs beside it on the same classpath and reads 27 textures out of the official jar.
 *
 * <p>Flags:
 * <ul>
 *   <li>{@code --download [--dir DIR]} - fetch a release from the update channel instead of
 *       registering an install that is already on disk.</li>
 *   <li>{@code --register-mojang DIR}, {@code --register-prism DIR} - register into one
 *       specific launcher, skipping detection.</li>
 *   <li>{@code --headless} - no dialogs; register into every launcher that qualifies.</li>
 * </ul>
 */
public final class Installer {

   /** Baked in at build time; overridable for testing a staging channel. */
   private static final String DEFAULT_MANIFEST =
      "https://example.invalid/infinite/latest/version.json";

   private static javax.swing.JTextArea log;
   private static javax.swing.JProgressBar bar;

   public static void main(String[] args) throws Exception {
      String manifestUrl = System.getProperty("infinite.manifest", DEFAULT_MANIFEST);
      File dir = null;
      boolean headless = java.awt.GraphicsEnvironment.isHeadless();
      boolean download = false;

      File registerMojang = null;
      File registerPrism = null;
      String registerVersion = null;

      for (int i = 0; i < args.length; i++) {
         if ("--register-mojang".equals(args[i]) && i + 1 < args.length) {
            registerMojang = new File(args[++i]);
         } else if ("--register-prism".equals(args[i]) && i + 1 < args.length) {
            registerPrism = new File(args[++i]);
         } else if ("--version".equals(args[i]) && i + 1 < args.length) {
            registerVersion = args[++i];
         } else if ("--dir".equals(args[i]) && i + 1 < args.length) {
            dir = new File(args[++i]);
         } else if ("--manifest".equals(args[i]) && i + 1 < args.length) {
            manifestUrl = args[++i];
         } else if ("--download".equals(args[i])) {
            download = true;
         } else if ("--headless".equals(args[i])) {
            headless = true;
         }
      }

      if (registerMojang != null || registerPrism != null) {
         registerExplicit(registerMojang, registerPrism, dir, registerVersion);
         return;
      }

      if (download) {
         downloadRelease(dir, manifestUrl, headless);
         return;
      }

      register(dir, headless);
   }

   // =====================================================================================
   // Registration - the default action
   // =====================================================================================

   private static void register(File source, boolean headless) {
      if (source == null) {
         source = installRoot();
      }
      File modJar = new File(source, "Infinite.jar");
      String version = versionOf(source);

      if (!modJar.isFile() && !headless) {
         modJar = askForModJar(source);
         if (modJar == null) {
            return;
         }
         version = versionOf(modJar.getParentFile());
      }
      if (!modJar.isFile()) {
         fail(headless, "Infinite.jar not found in " + source
            + "\n\nRun the installer from the folder it was unzipped into,"
            + " or pass --dir to say where the install is.");
         return;
      }

      List<Launchers.Found> found = Launchers.findAll();
      if (found.isEmpty()) {
         fail(headless, "No Minecraft launcher was found on this machine.\n\n"
            + "Infinite can still be started directly:\n"
            + "    java -jar InfiniteLoader.jar");
         return;
      }

      List<Launchers.Found> chosen = headless
         ? eligible(found)
         : askWhichLaunchers(found);
      if (chosen == null || chosen.isEmpty()) {
         return;
      }

      StringBuilder report = new StringBuilder();
      List<String> failures = new ArrayList<String>();
      final StringBuilder detail = new StringBuilder();
      Loader.Progress p = new Loader.Progress() {
         public void step(String m) {
            System.out.println("[register] " + m);
            detail.append(m).append('\n');
         }
      };

      for (Launchers.Found f : chosen) {
         try {
            if (f.kind == Launchers.Kind.MOJANG) {
               String id = Profiles.installMojang(f.root, modJar, version, p);
               report.append("Minecraft Launcher: added \"Minecraft Infinite ")
                  .append(version).append("\" (").append(id).append(")\n");
            } else {
               File instance = new File(new File(f.root, "instances"),
                  "Minecraft Infinite " + version);
               Profiles.installPrism(instance, modJar, version, p);
               report.append(f.label).append(": created instance ")
                  .append(instance.getName()).append("\n");
            }
         } catch (IOException e) {
            failures.add(f.label + " (" + f.root + "):\n" + e.getMessage());
         }
      }

      String summary = report.length() == 0
         ? "Nothing was registered."
         : "Registered:\n\n" + report;
      if (!failures.isEmpty()) {
         summary += "\nSkipped:\n\n";
         for (String s : failures) {
            summary += s + "\n\n";
         }
      }
      if (report.length() > 0) {
         summary += "\nRestart your launcher and pick Minecraft Infinite from the version list.";
      }

      System.out.println();
      System.out.println(summary);
      if (!headless) {
         javax.swing.JOptionPane.showMessageDialog(null, summary, "Minecraft Infinite",
            report.length() > 0
               ? javax.swing.JOptionPane.INFORMATION_MESSAGE
               : javax.swing.JOptionPane.WARNING_MESSAGE);
      }
      if (report.length() == 0) {
         System.exit(1);
      }
   }

   /** Register into launchers named on the command line, without detection. */
   private static void registerExplicit(File mojang, File prism, File source, String version) {
      if (source == null) {
         source = installRoot();
      }
      File modJar = new File(source, "Infinite.jar");
      if (!modJar.isFile()) {
         System.err.println("[register] Infinite.jar not found in " + source
            + " (pass --dir to say where the install is)");
         System.exit(1);
         return;
      }
      if (version == null) {
         version = versionOf(source);
      }
      Loader.Progress p = new Loader.Progress() {
         public void step(String m) {
            System.out.println("[register] " + m);
         }
      };
      try {
         if (mojang != null) {
            String id = Profiles.installMojang(mojang, modJar, version, p);
            System.out.println("[register] registered as " + id
               + " - pick it from the launcher's version list");
         }
         if (prism != null) {
            Profiles.installPrism(prism, modJar, version, p);
            System.out.println("[register] import that folder in Prism, or zip it and use"
               + " Add Instance > Import from zip");
         }
      } catch (IOException e) {
         System.err.println();
         System.err.println("[register] " + e.getMessage());
         System.err.println();
         System.exit(1);
      }
   }

   private static List<Launchers.Found> eligible(List<Launchers.Found> all) {
      List<Launchers.Found> out = new ArrayList<Launchers.Found>();
      for (Launchers.Found f : all) {
         if (Launchers.hasAlpha(f)) {
            out.add(f);
         } else {
            System.out.println("[register] skipping " + f.root
               + " - Alpha 1.0.4 is not installed there");
         }
      }
      return out;
   }

   /** Checkbox list of the launchers that were found. Returns null if cancelled. */
   private static List<Launchers.Found> askWhichLaunchers(List<Launchers.Found> found) {
      systemLookAndFeel();

      javax.swing.JPanel panel = new javax.swing.JPanel(new BorderLayout(0, 10));
      panel.add(new javax.swing.JLabel(
         "<html>Install Minecraft Infinite into these launchers?<br><br>"
         + "Nothing already installed is modified. Close your launcher before continuing -"
         + "<br>the Minecraft Launcher rewrites its settings on exit and would undo this."
         + "</html>"), BorderLayout.NORTH);

      javax.swing.JPanel list = new javax.swing.JPanel(new GridLayout(0, 1, 0, 4));
      List<javax.swing.JCheckBox> boxes = new ArrayList<javax.swing.JCheckBox>();
      for (Launchers.Found f : found) {
         boolean ready = Launchers.hasAlpha(f);
         String text = "<html><b>" + f.label + "</b><br>"
            + "<font size=-2>" + f.root + "</font>"
            + (ready ? "" : "<br><font size=-2 color=#aa0000>Alpha 1.0.4 is not installed"
               + " here - create and launch an a1.0.4 installation first</font>")
            + "</html>";
         javax.swing.JCheckBox cb = new javax.swing.JCheckBox(text, ready);
         cb.setEnabled(ready);
         boxes.add(cb);
         list.add(cb);
      }
      javax.swing.JScrollPane scroll = new javax.swing.JScrollPane(list);
      scroll.setBorder(null);
      scroll.setPreferredSize(new Dimension(560, Math.min(300, 24 + found.size() * 52)));
      panel.add(scroll, BorderLayout.CENTER);

      int ok = javax.swing.JOptionPane.showConfirmDialog(null, panel,
         "Minecraft Infinite - install", javax.swing.JOptionPane.OK_CANCEL_OPTION,
         javax.swing.JOptionPane.PLAIN_MESSAGE);
      if (ok != javax.swing.JOptionPane.OK_OPTION) {
         return null;
      }

      List<Launchers.Found> chosen = new ArrayList<Launchers.Found>();
      for (int i = 0; i < found.size(); i++) {
         if (boxes.get(i).isSelected() && boxes.get(i).isEnabled()) {
            chosen.add(found.get(i));
         }
      }
      return chosen;
   }

   private static File askForModJar(File startIn) {
      systemLookAndFeel();
      javax.swing.JOptionPane.showMessageDialog(null,
         "Infinite.jar was not found next to this installer.\n\n"
         + "Pick it from wherever you unzipped the release.",
         "Minecraft Infinite", javax.swing.JOptionPane.INFORMATION_MESSAGE);
      javax.swing.JFileChooser fc = new javax.swing.JFileChooser(startIn);
      fc.setDialogTitle("Select Infinite.jar");
      fc.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
      if (fc.showOpenDialog(null) != javax.swing.JFileChooser.APPROVE_OPTION) {
         return null;
      }
      return fc.getSelectedFile();
   }

   /** The folder the installer jar itself lives in, falling back to the working directory. */
   private static File installRoot() {
      try {
         java.security.CodeSource cs =
            Installer.class.getProtectionDomain().getCodeSource();
         if (cs != null && cs.getLocation() != null) {
            File self = new File(cs.getLocation().toURI());
            if (self.isFile() && self.getParentFile() != null) {
               return self.getParentFile();
            }
         }
      } catch (Exception ignored) {
         // running from a class directory, or a security manager is in the way
      }
      return new File(System.getProperty("user.dir", "."));
   }

   /** Release version out of the manifest beside the jar; "unknown" if there isn't one. */
   private static String versionOf(File dir) {
      if (dir == null) {
         return "unknown";
      }
      File f = new File(dir, "version.json");
      if (!f.isFile()) {
         return "unknown";
      }
      try {
         Map<String, Object> m = Json.obj(Json.parse(readFile(f)));
         String v = Json.str(m, "version");
         return v == null ? "unknown" : v;
      } catch (Exception e) {
         return "unknown";
      }
   }

   private static String readFile(File f) throws IOException {
      byte[] b = new byte[(int) f.length()];
      java.io.InputStream in = new java.io.FileInputStream(f);
      try {
         int off = 0;
         int r;
         while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) {
            off += r;
         }
      } finally {
         in.close();
      }
      return new String(b, "UTF-8");
   }

   private static void fail(boolean headless, String message) {
      System.err.println();
      System.err.println(message);
      System.err.println();
      if (!headless) {
         systemLookAndFeel();
         javax.swing.JOptionPane.showMessageDialog(null, message, "Minecraft Infinite",
            javax.swing.JOptionPane.ERROR_MESSAGE);
      }
      System.exit(1);
   }

   private static void systemLookAndFeel() {
      try {
         javax.swing.UIManager.setLookAndFeel(
            javax.swing.UIManager.getSystemLookAndFeelClassName());
      } catch (Exception ignored) {
         // cosmetic only
      }
   }

   // =====================================================================================
   // Download - only when asked for explicitly
   // =====================================================================================

   private static void downloadRelease(File dir, String manifestUrl, boolean headless)
         throws Exception {
      if (headless) {
         if (dir == null) {
            dir = new File(System.getProperty("user.dir"), "Infinite");
         }
         install(dir, manifestUrl, new Loader.Progress() {
            public void step(String m) {
               System.out.println("[install] " + m);
            }
         });
         System.out.println("[install] done: " + dir);
         return;
      }
      if (dir == null) {
         dir = chooseDirectory();
         if (dir == null) {
            return;
         }
      }
      runWithUi(dir, manifestUrl);
   }

   private static File chooseDirectory() {
      systemLookAndFeel();
      File suggested = new File(System.getProperty("user.home", "."), "Minecraft Infinite");
      int ok = javax.swing.JOptionPane.showConfirmDialog(
         null,
         "This will download Minecraft Infinite to:\n\n   " + suggested + "\n\n"
            + "You need Java 8+ and your own copy of Minecraft Alpha 1.0.4.\n"
            + "Nothing in your Minecraft install is modified.\n\n"
            + "Download here? Choose No to pick a different folder.",
         "Minecraft Infinite - download",
         javax.swing.JOptionPane.YES_NO_CANCEL_OPTION,
         javax.swing.JOptionPane.QUESTION_MESSAGE);

      if (ok == javax.swing.JOptionPane.CANCEL_OPTION
         || ok == javax.swing.JOptionPane.CLOSED_OPTION) {
         return null;
      }
      if (ok == javax.swing.JOptionPane.YES_OPTION) {
         return suggested;
      }

      javax.swing.JFileChooser fc = new javax.swing.JFileChooser();
      fc.setDialogTitle("Choose a folder");
      fc.setFileSelectionMode(javax.swing.JFileChooser.DIRECTORIES_ONLY);
      if (fc.showSaveDialog(null) != javax.swing.JFileChooser.APPROVE_OPTION) {
         return null;
      }
      return fc.getSelectedFile();
   }

   private static void runWithUi(final File dir, final String manifestUrl) {
      final javax.swing.JFrame frame = new javax.swing.JFrame("Downloading Minecraft Infinite");
      log = new javax.swing.JTextArea(14, 58);
      log.setEditable(false);
      bar = new javax.swing.JProgressBar();
      bar.setIndeterminate(true);
      frame.setLayout(new BorderLayout(8, 8));
      frame.add(new javax.swing.JScrollPane(log), BorderLayout.CENTER);
      frame.add(bar, BorderLayout.SOUTH);
      frame.setPreferredSize(new Dimension(620, 320));
      frame.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
      frame.pack();
      frame.setLocationRelativeTo(null);
      frame.setVisible(true);

      new Thread(new Runnable() {
         public void run() {
            try {
               install(dir, manifestUrl, new Loader.Progress() {
                  public void step(String m) {
                     append(m);
                  }
               });
               bar.setIndeterminate(false);
               bar.setValue(100);
               append("");
               append("Done. Run the installer again to add it to your launcher,");
               append("or start it directly with: java -jar InfiniteLoader.jar");
               javax.swing.JOptionPane.showMessageDialog(frame,
                  "Downloaded to:\n   " + dir + "\n\nRun the installer from that folder to"
                  + " add it to your launcher.",
                  "Minecraft Infinite", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception e) {
               bar.setIndeterminate(false);
               append("");
               append("FAILED: " + e);
               javax.swing.JOptionPane.showMessageDialog(frame,
                  "Download failed:\n\n" + e.getMessage(),
                  "Minecraft Infinite", javax.swing.JOptionPane.ERROR_MESSAGE);
            }
         }
      }, "installer").start();
   }

   private static void append(final String s) {
      if (log == null) {
         System.out.println("[install] " + s);
         return;
      }
      javax.swing.SwingUtilities.invokeLater(new Runnable() {
         public void run() {
            log.append(s + "\n");
            log.setCaretPosition(log.getDocument().getLength());
         }
      });
   }

   // =====================================================================================

   static void install(File dir, String manifestUrl, Loader.Progress p) throws IOException {
      p.step("fetching " + manifestUrl);
      String text = Updater.fetch(manifestUrl);
      Map<String, Object> manifest = Json.obj(Json.parse(text));
      if (manifest == null) {
         throw new IOException("manifest is not a JSON object");
      }
      String version = Json.str(manifest, "version");
      p.step("release " + version);

      if (!dir.isDirectory() && !dir.mkdirs()) {
         throw new IOException("could not create " + dir);
      }

      List<Object> files = Json.arr(manifest.get("files"));
      if (files == null || files.isEmpty()) {
         throw new IOException("manifest lists no files");
      }
      for (Object o : files) {
         Map<String, Object> m = Json.obj(o);
         String path = Json.str(m, "path");
         String url = Json.str(m, "url");
         String sha1 = Json.str(m, "sha1");
         long size = Json.num(m, "size", -1);
         if (path == null || url == null) {
            continue;
         }
         File target = new File(dir, path.replace('/', File.separatorChar));
         if (Updater.ok(target, sha1, size)) {
            p.step("have " + path);
            continue;
         }
         p.step("downloading " + path);
         Updater.download(url, target, sha1);
      }

      // Keep the manifest so the loader knows what it has and can update from here.
      OutputStream out = new FileOutputStream(new File(dir, "version.json"));
      try {
         out.write(text.getBytes("UTF-8"));
      } finally {
         out.close();
      }

      p.step("");
      p.step("Run the installer again from this folder to add it to your launcher.");
   }

   private Installer() {
   }
}
