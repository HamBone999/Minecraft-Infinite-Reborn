package infinite.loader;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Locates Minecraft launchers on this machine. */
final class Launchers {

   enum Kind { MOJANG, PRISM }

   static final class Found {
      final Kind kind;
      final File root;      // .minecraft, or the launcher folder for Prism/MultiMC
      final String label;

      Found(Kind kind, File root, String label) {
         this.kind = kind;
         this.root = root;
         this.label = label;
      }

      @Override
      public String toString() {
         return label + "  -  " + root;
      }
   }

   private Launchers() {
   }

   static List<Found> findAll() {
      List<Found> out = new ArrayList<Found>();
      String home = System.getProperty("user.home", ".");
      String appdata = System.getenv("APPDATA");

      mojang(out, appdata == null ? null : new File(appdata, ".minecraft"));
      mojang(out, new File(home, ".minecraft"));
      mojang(out, new File(home, "Library/Application Support/minecraft"));
      mojang(out, new File(home, "curseforge/minecraft/Install"));

      // Prism and MultiMC are frequently portable, so a fixed list of paths is not enough.
      List<File> roots = new ArrayList<File>();
      addDir(roots, appdata);
      addDir(roots, System.getenv("LOCALAPPDATA"));
      addDir(roots, home);
      addDir(roots, home + File.separator + "Desktop");
      addDir(roots, home + File.separator + "Documents");
      addDir(roots, home + File.separator + "Downloads");
      addDir(roots, home + File.separator + ".local/share");
      addDir(roots, home + File.separator + "Library/Application Support");
      addDir(roots, System.getenv("ProgramFiles"));
      addDir(roots, System.getenv("ProgramFiles(x86)"));
      for (File r : File.listRoots()) {
         addDir(roots, r.getAbsolutePath() + "Games");
      }
      for (File r : roots) {
         scanForPrism(out, r, 0);
      }
      return out;
   }

   /** A launcher folder is one holding both instances/ and libraries/. */
   private static void scanForPrism(List<Found> out, File dir, int depth) {
      if (depth > 3) {
         return;
      }
      File[] kids = dir.listFiles();
      if (kids == null) {
         return;
      }
      for (File k : kids) {
         if (!k.isDirectory()) {
            continue;
         }
         String n = k.getName().toLowerCase();
         if (n.startsWith(".") || n.equals("windows") || n.equals("node_modules")) {
            continue;
         }
         if (new File(k, "instances").isDirectory() && new File(k, "libraries").isDirectory()) {
            String label = n.contains("prism") ? "Prism Launcher"
               : n.contains("multimc") ? "MultiMC" : "Prism/MultiMC";
            if (!contains(out, k)) {
               out.add(new Found(Kind.PRISM, k, label));
            }
            continue;
         }
         scanForPrism(out, k, depth + 1);
      }
   }

   private static void mojang(List<Found> out, File dir) {
      if (dir == null || !dir.isDirectory() || contains(out, dir)) {
         return;
      }
      if (new File(dir, "launcher_profiles.json").isFile()
         || new File(dir, "versions").isDirectory()) {
         out.add(new Found(Kind.MOJANG, dir, "Minecraft Launcher"));
      }
   }

   private static boolean contains(List<Found> out, File dir) {
      for (Found f : out) {
         if (f.root.equals(dir)) {
            return true;
         }
      }
      return false;
   }

   private static void addDir(List<File> out, String path) {
      if (path == null || path.startsWith("null")) {
         return;
      }
      File f = new File(path);
      if (f.isDirectory()) {
         out.add(f);
      }
   }

   /** True when Alpha 1.0.4 is installed, which the version profile inherits from. */
   static boolean hasAlpha(Found f) {
      if (f.kind == Kind.MOJANG) {
         return new File(f.root, "versions/a1.0.4/a1.0.4.json").isFile();
      }
      return true;   // Prism downloads it on first launch of the instance
   }
}
