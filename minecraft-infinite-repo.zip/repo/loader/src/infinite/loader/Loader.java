package infinite.loader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Minecraft Infinite launcher.
 *
 * <p>The mod is standalone code — it does not reference a single class from the official
 * Alpha 1.0.4 jar. What it does need is 27 original Mojang textures, which cannot be
 * redistributed. So this loader borrows them from the player's own copy at runtime.
 *
 * <p>Finding that copy is the whole install experience, so it tries hard, in order:
 * <ol>
 *   <li>an explicit {@code -Dinfinite.base=} or {@code INFINITE_BASE_JAR},</li>
 *   <li>a path remembered from last time,</li>
 *   <li>a bounded search of the places launchers actually put things,</li>
 *   <li>a file picker.</li>
 * </ol>
 * Whatever works gets remembered, so this only ever happens once.
 */
public final class Loader {

   private static final String EXPECTED_SHA1 = "e5838277b3bb193e58408713f1fc6e005c5f3c0c";
   private static final String MAIN_CLASS = "net.minecraft.client.Minecraft";
   private static final String ASSET_LIST = "/mojang-assets.txt";
   private static final String CONFIG = "infinite.properties";
   private static final String JAR_NAME = "minecraft-a1.0.4-client.jar";

   /** Give up scanning after this long so a slow disk can't hang the launch. */
   private static final long SCAN_BUDGET_MS = 12_000L;

   private static File configFile;

   public static void main(String[] args) throws Exception {
      boolean checkOnly = false;
      boolean reset = false;
      boolean noUpdate = false;
      List<String> passthrough = new ArrayList<String>();
      for (String a : args) {
         if ("--check".equals(a)) {
            checkOnly = true;
         } else if ("--reset".equals(a)) {
            reset = true;
         } else if ("--no-update".equals(a)) {
            noUpdate = true;
         } else {
            passthrough.add(a);
         }
      }

      File here = jarDir();
      configFile = new File(here, CONFIG);
      if (reset && configFile.isFile() && configFile.delete()) {
         say("forgot the remembered Minecraft location");
      }

      Map<String, Object> boot = readManifest(here);
      if (boot != null) {
         say("version   : " + Json.str(boot, "version"));
         if (!noUpdate) {
            checkForUpdates(here, boot);
         }
      }

      File modJar = resolveModJar(here);
      say("mod jar   : " + modJar);

      File baseJar = resolveBaseJar();
      say("base jar  : " + baseJar);
      say("verified  : sha1 " + EXPECTED_SHA1);

      File cache = new File(here, "assets-cache");
      say("assets    : " + extractAssets(baseJar, cache) + " ready");

      // The mod draws through LWJGL 2. Prism/MultiMC normally supply it, so running outside
      // a launcher means supplying it here: the jars on the classpath, and the native
      // libraries unpacked somewhere java.library.path can see.
      List<File> libJars;
      List<File> libNatives = new ArrayList<File>();
      Map<String, Object> manifest = readManifest(here);
      if (manifest != null) {
         // Declared libraries: taken from the cache, then the launcher, then the network.
         List<Updater.Lib> want = Updater.libraries(manifest, osTag(), isArm64());
         List<File> resolved = Updater.resolve(
            want, new File(here, "libraries"), launcherLibraries(baseJar), PROGRESS);
         libJars = new ArrayList<File>();
         for (int i = 0; i < want.size(); i++) {
            (want.get(i).natives ? libNatives : libJars).add(resolved.get(i));
         }
      } else {
         // No manifest: fall back to scavenging the launcher, as before.
         Lwjgl found = findLwjgl(here, baseJar);
         libJars = found.jars;
         libNatives = found.natives;
      }
      File natives = new File(here, "natives");
      int unpacked = unpackNatives(libNatives, natives);
      say("lwjgl     : " + libJars.size() + " jars, " + unpacked + " native files");
      System.setProperty("org.lwjgl.librarypath", natives.getAbsolutePath());
      System.setProperty("net.java.games.input.librarypath", natives.getAbsolutePath());

      if (checkOnly) {
         say("");
         say("--check passed. Not launching.");
         return;
      }

      List<URL> cp = new ArrayList<URL>();
      cp.add(modJar.toURI().toURL());
      cp.add(cache.toURI().toURL());
      for (File j : libJars) {
         cp.add(j.toURI().toURL());
      }

      URLClassLoader cl = new URLClassLoader(
         cp.toArray(new URL[0]),
         // Platform loader, not the app loader: the mod must not resolve classes out of
         // the loader's own jar.
         ClassLoader.getSystemClassLoader().getParent()
      );
      Thread.currentThread().setContextClassLoader(cl);

      Class<?> mc = Class.forName(MAIN_CLASS, true, cl);
      Method main = mc.getMethod("main", String[].class);
      say("launching " + MAIN_CLASS);
      say("");
      main.invoke(null, (Object) passthrough.toArray(new String[0]));
   }

   // =====================================================================================
   // Finding LWJGL
   // =====================================================================================

   private static final class Lwjgl {
      final List<File> jars = new ArrayList<File>();
      final List<File> natives = new ArrayList<File>();
   }

   /** windows | osx | linux, matching the classifiers launchers use. */
   private static String osTag() {
      String os = System.getProperty("os.name", "").toLowerCase();
      if (os.contains("win")) {
         return "windows";
      }
      if (os.contains("mac") || os.contains("darwin")) {
         return "osx";
      }
      return "linux";
   }

   private static boolean isArm64() {
      String a = System.getProperty("os.arch", "").toLowerCase();
      return a.contains("aarch64") || a.contains("arm64");
   }

   /**
    * Collect LWJGL from a bundled lwjgl/ folder if present, otherwise from the launcher
    * library tree that the base jar lives in. Nothing is downloaded and nothing is copied
    * out of the launcher except the native binaries, which have to be unpacked to be loaded.
    */
   private static Lwjgl findLwjgl(File here, File baseJar) {
      Lwjgl out = new Lwjgl();

      File bundled = new File(here, "lwjgl");
      if (bundled.isDirectory()) {
         collectLwjgl(bundled, out);
         if (!out.jars.isEmpty()) {
            return out;
         }
      }

      File dir = launcherLibraries(baseJar);
      if (dir != null && dir.isDirectory()) {
         collectLwjgl(new File(dir, "org"), out);
         collectLwjgl(new File(dir, "net"), out);
      }

      if (out.jars.isEmpty()) {
         fail("Could not find LWJGL.\n\n"
            + "The mod needs LWJGL 2 to open a window and draw. Your launcher normally\n"
            + "provides it, and it usually sits beside Minecraft itself in:\n"
            + "  <launcher folder>/libraries/org/lwjgl/\n\n"
            + "Searched from: " + baseJar.getParentFile() + "\n\n"
            + "Launch your Alpha 1.0.4 instance once from the launcher so it downloads\n"
            + "LWJGL, then run this again.");
      }
      return out;
   }

   private static void collectLwjgl(File root, Lwjgl out) {
      if (!root.isDirectory()) {
         return;
      }
      String os = osTag();
      String arm = os + "-arm64";
      Deque<File> q = new ArrayDeque<File>();
      q.add(root);
      while (!q.isEmpty()) {
         File[] kids = q.poll().listFiles();
         if (kids == null) {
            continue;
         }
         for (File k : kids) {
            if (k.isDirectory()) {
               q.add(k);
               continue;
            }
            String n = k.getName().toLowerCase();
            if (!n.endsWith(".jar")) {
               continue;
            }
            boolean relevant = n.startsWith("lwjgl") || n.startsWith("jinput") || n.startsWith("jutils");
            if (!relevant) {
               continue;
            }
            if (n.contains("-natives-")) {
               // only this platform's binaries
               boolean mine = isArm64() && n.contains("natives-" + arm)
                  || !n.contains("-arm64") && n.contains("natives-" + os);
               if (mine) {
                  out.natives.add(k);
               }
            } else if (!n.contains("sources") && !n.contains("javadoc") && k.length() > 1024) {
               out.jars.add(k);
            }
         }
      }
   }

   /** Native libraries cannot be loaded from inside a jar, so unpack them once. */
   private static int unpackNatives(List<File> nativeJars, File dest) throws IOException {
      int n = 0;
      for (File nj : nativeJars) {
         ZipFile zip = new ZipFile(nj);
         try {
            java.util.Enumeration<? extends ZipEntry> en = zip.entries();
            while (en.hasMoreElements()) {
               ZipEntry e = en.nextElement();
               String name = e.getName();
               if (e.isDirectory() || name.startsWith("META-INF/") || name.indexOf('/') >= 0) {
                  continue;   // natives live flat at the jar root
               }
               File target = new File(dest, name);
               if (target.isFile() && target.length() == e.getSize()) {
                  n++;
                  continue;
               }
               if (!dest.isDirectory() && !dest.mkdirs()) {
                  fail("Could not create " + dest);
               }
               InputStream in = zip.getInputStream(e);
               OutputStream o = new FileOutputStream(target);
               try {
                  byte[] buf = new byte[8192];
                  int r;
                  while ((r = in.read(buf)) > 0) {
                     o.write(buf, 0, r);
                  }
               } finally {
                  o.close();
                  in.close();
               }
               n++;
            }
         } finally {
            zip.close();
         }
      }
      return n;
   }

   // =====================================================================================
   // Finding the player's own Minecraft
   // =====================================================================================

   private static File resolveBaseJar() {
      // 1. explicit
      String explicit = System.getProperty("infinite.base");
      if (explicit == null) {
         explicit = System.getenv("INFINITE_BASE_JAR");
      }
      if (explicit != null) {
         File f = new File(explicit);
         if (!f.isFile()) {
            fail("Not found: " + f + "\n(from -Dinfinite.base / INFINITE_BASE_JAR)");
         }
         requireCorrect(f);
         return f;
      }

      // 2. remembered
      File saved = readSaved();
      if (saved != null && saved.isFile() && EXPECTED_SHA1.equals(quietSha1(saved))) {
         return saved;
      }

      // 3. search
      say("looking for your Minecraft Alpha 1.0.4 files...");
      File found = search();
      if (found != null) {
         say("found     : " + found);
         remember(found);
         return found;
      }

      // 4. ask
      File picked = pick();
      if (picked != null) {
         remember(picked);
         return picked;
      }

      fail("Could not find your Minecraft Alpha 1.0.4 client jar.\n\n"
         + "This mod needs 27 original textures from it. They cannot be redistributed.\n\n"
         + "If you have ever played Alpha 1.0.4, your launcher already downloaded it. Look for:\n"
         + "  Mojang launcher : %APPDATA%\\.minecraft\\versions\\a1.0.4\\a1.0.4.jar\n"
         + "  Prism / MultiMC : <launcher>/libraries/com/mojang/minecraft/a1.0.4/" + JAR_NAME + "\n\n"
         + "If you have not, create an Alpha 1.0.4 instance in your launcher and start it\n"
         + "once  -  that downloads the file from Mojang. Then run this again.\n\n"
         + "Or name the file directly:\n"
         + "  java -Dinfinite.base=\"C:\\path\\to\\" + JAR_NAME + "\" -jar InfiniteLoader.jar");
      return null;
   }

   /**
    * Breadth-first sweep of the places launchers live, including portable installs, which a
    * fixed %APPDATA% check would miss. Bounded by depth, visit count and a wall clock so this
    * stays a launch step rather than a disk crawl.
    */
   private static File search() {
      List<File> roots = new ArrayList<File>();
      String home = System.getProperty("user.home", ".");
      addIf(roots, System.getenv("APPDATA"));
      addIf(roots, System.getenv("LOCALAPPDATA"));
      addIf(roots, home);
      addIf(roots, home + File.separator + "Desktop");
      addIf(roots, home + File.separator + "Documents");
      addIf(roots, home + File.separator + "Downloads");
      addIf(roots, home + File.separator + ".minecraft");
      addIf(roots, home + File.separator + "Library/Application Support");
      addIf(roots, home + File.separator + ".local/share");
      addIf(roots, System.getenv("ProgramFiles"));
      addIf(roots, System.getenv("ProgramFiles(x86)"));
      addIf(roots, jarDir().getAbsolutePath());
      // Portable launchers often sit on a second drive.
      for (File r : File.listRoots()) {
         addIf(roots, r.getAbsolutePath() + "Games");
         addIf(roots, r.getAbsolutePath() + "Minecraft");
      }

      long deadline = System.currentTimeMillis() + SCAN_BUDGET_MS;
      int visited = 0;
      Deque<Object[]> queue = new ArrayDeque<Object[]>();
      for (File r : roots) {
         queue.add(new Object[]{ r, Integer.valueOf(0) });
      }

      while (!queue.isEmpty()) {
         if (System.currentTimeMillis() > deadline || visited > 60_000) {
            break;
         }
         Object[] item = queue.poll();
         File dir = (File) item[0];
         int depth = ((Integer) item[1]).intValue();
         if (depth > 7) {
            continue;
         }
         File[] kids = dir.listFiles();
         if (kids == null) {
            continue;
         }
         visited++;
         for (File k : kids) {
            if (k.isFile()) {
               if (looksLikeBaseJar(k, dir)) {
                  if (EXPECTED_SHA1.equals(quietSha1(k))) {
                     return k;
                  }
               }
            } else if (k.isDirectory() && !skip(k.getName())) {
               queue.add(new Object[]{ k, Integer.valueOf(depth + 1) });
            }
         }
      }
      return null;
   }

   /**
    * Worth hashing? Launchers disagree about naming:
    *   Prism / MultiMC   libraries/com/mojang/minecraft/a1.0.4/minecraft-a1.0.4-client.jar
    *   Mojang launcher   versions/a1.0.4/a1.0.4.jar
    * so match on the version string appearing in either the file name or its folder, and let
    * the SHA-1 be the thing that actually decides.
    */
   private static boolean looksLikeBaseJar(File f, File parent) {
      String n = f.getName().toLowerCase();
      if (!n.endsWith(".jar")) {
         return false;
      }
      if (n.contains("a1.0.4")) {
         return true;
      }
      String p = parent == null ? "" : parent.getName().toLowerCase();
      // versions/a1.0.4/<anything>.jar, and the same shape with separators removed
      return p.contains("a1.0.4") || p.replace(".", "").contains("a104");
   }

   /** Directories that never contain a launcher library and cost a lot to walk. */
   private static boolean skip(String name) {
      String n = name.toLowerCase();
      return n.startsWith(".")
         && !n.equals(".minecraft") && !n.equals(".local") && !n.equals(".var")
         || n.equals("windows") || n.equals("system32") || n.equals("winsxs")
         || n.equals("node_modules") || n.equals("$recycle.bin")
         || n.equals("temp") || n.equals("tmp") || n.equals("cache")
         || n.equals("onedrivetemp") || n.equals("programdata");
   }

   private static void addIf(List<File> out, String path) {
      if (path == null || path.startsWith("null")) {
         return;
      }
      File f = new File(path);
      if (f.isDirectory()) {
         out.add(f);
      }
   }

   /** Last resort: ask. Far friendlier than telling someone to edit a batch file. */
   private static File pick() {
      if (java.awt.GraphicsEnvironment.isHeadless()) {
         return null;
      }
      try {
         javax.swing.UIManager.setLookAndFeel(
            javax.swing.UIManager.getSystemLookAndFeelClassName());
      } catch (Exception ignored) {
         // cosmetic only
      }

      int choice = javax.swing.JOptionPane.showConfirmDialog(
         null,
         "Minecraft Infinite needs a few original textures from\n"
            + "Minecraft Alpha 1.0.4, which we're not allowed to include.\n\n"
            + "We couldn't find your copy automatically.\n\n"
            + "If you've played Alpha 1.0.4 before, it's at:\n"
            + "   <launcher>/libraries/com/mojang/minecraft/a1.0.4/\n\n"
            + "Would you like to locate " + JAR_NAME + " now?",
         "Minecraft Infinite  -  one-time setup",
         javax.swing.JOptionPane.OK_CANCEL_OPTION,
         javax.swing.JOptionPane.QUESTION_MESSAGE);
      if (choice != javax.swing.JOptionPane.OK_OPTION) {
         return null;
      }

      while (true) {
         javax.swing.JFileChooser fc = new javax.swing.JFileChooser();
         fc.setDialogTitle("Select " + JAR_NAME);
         fc.setFileSelectionMode(javax.swing.JFileChooser.FILES_ONLY);
         fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Minecraft jar (*.jar)", "jar"));
         if (fc.showOpenDialog(null) != javax.swing.JFileChooser.APPROVE_OPTION) {
            return null;
         }
         File f = fc.getSelectedFile();
         if (f != null && f.isFile() && EXPECTED_SHA1.equals(quietSha1(f))) {
            return f;
         }
         int again = javax.swing.JOptionPane.showConfirmDialog(
            null,
            "That file isn't the official Alpha 1.0.4 client.\n\n"
               + (f == null ? "" : "  " + f.getName() + "\n\n")
               + "It needs to be exactly " + JAR_NAME + ",\n"
               + "the one your launcher downloaded.\n\n"
               + "Try another file?",
            "Wrong file",
            javax.swing.JOptionPane.YES_NO_OPTION,
            javax.swing.JOptionPane.WARNING_MESSAGE);
         if (again != javax.swing.JOptionPane.YES_OPTION) {
            return null;
         }
      }
   }

   // =====================================================================================

   private static File readSaved() {
      if (configFile == null || !configFile.isFile()) {
         return null;
      }
      try {
         Properties p = new Properties();
         InputStream in = new java.io.FileInputStream(configFile);
         try {
            p.load(in);
         } finally {
            in.close();
         }
         String v = p.getProperty("baseJar");
         return v == null ? null : new File(v);
      } catch (IOException e) {
         return null;
      }
   }

   private static void remember(File jar) {
      try {
         Properties p = new Properties();
         p.setProperty("baseJar", jar.getAbsolutePath());
         OutputStream out = new FileOutputStream(configFile);
         try {
            p.store(out, "Where your Minecraft Alpha 1.0.4 jar lives. Delete to search again,"
               + " or run the loader with --reset.");
         } finally {
            out.close();
         }
      } catch (IOException e) {
         say("(could not save the location; it will be searched for again next time)");
      }
   }

   private static void requireCorrect(File f) {
      String actual = quietSha1(f);
      if (!EXPECTED_SHA1.equals(actual)) {
         fail("That is not the official Alpha 1.0.4 client jar.\n"
            + "  expected sha1 " + EXPECTED_SHA1 + "\n"
            + "  actual   sha1 " + actual + "\n"
            + "  file          " + f);
      }
   }

   // =====================================================================================

   private static Map<String, String> assetList() throws IOException {
      Map<String, String> out = new LinkedHashMap<String, String>();
      InputStream in = Loader.class.getResourceAsStream(ASSET_LIST);
      if (in == null) {
         fail("Asset list missing from the loader jar. This build is broken.");
      }
      java.io.BufferedReader r =
         new java.io.BufferedReader(new java.io.InputStreamReader(in, "UTF-8"));
      String line;
      while ((line = r.readLine()) != null) {
         String s = line.trim();
         if (s.isEmpty() || s.startsWith("#")) {
            continue;
         }
         int arrow = s.indexOf("<-");
         if (arrow >= 0) {
            out.put(s.substring(0, arrow).trim(), s.substring(arrow + 2).trim());
         } else {
            out.put(s, s);
         }
      }
      r.close();
      return out;
   }

   private static int extractAssets(File baseJar, File cacheDir) throws IOException {
      Map<String, String> assets = assetList();
      ZipFile zip = new ZipFile(baseJar);
      int n = 0;
      try {
         for (Map.Entry<String, String> e : assets.entrySet()) {
            ZipEntry entry = zip.getEntry(e.getValue());
            if (entry == null) {
               fail("Base jar is missing '" + e.getValue() + "'. Wrong jar, or a bad download.");
            }
            File target = new File(cacheDir, e.getKey().replace('/', File.separatorChar));
            if (target.isFile() && target.length() == entry.getSize()) {
               n++;
               continue;
            }
            File parent = target.getParentFile();
            if (parent != null && !parent.isDirectory() && !parent.mkdirs()) {
               fail("Could not create " + parent);
            }
            InputStream in = zip.getInputStream(entry);
            OutputStream out = new FileOutputStream(target);
            try {
               byte[] buf = new byte[8192];
               int r;
               while ((r = in.read(buf)) > 0) {
                  out.write(buf, 0, r);
               }
            } finally {
               out.close();
               in.close();
            }
            n++;
         }
      } finally {
         zip.close();
      }
      return n;
   }

   private static File resolveModJar(File here) {
      String explicit = System.getProperty("infinite.mod");
      if (explicit != null) {
         File f = new File(explicit);
         if (!f.isFile()) {
            fail("Mod jar not found: " + f);
         }
         return f;
      }
      File[] candidates = here.listFiles();
      if (candidates != null) {
         for (File f : candidates) {
            String n = f.getName().toLowerCase();
            if (n.endsWith(".jar") && n.contains("infinite") && !n.contains("loader")) {
               return f;
            }
         }
      }
      fail("Could not find Infinite.jar.\n"
         + "It must sit in the same folder as InfiniteLoader.jar.");
      return null;
   }

   private static final Progress PROGRESS = new Progress() {
      public void step(String message) {
         say(message);
      }
   };

   /** The release manifest sitting beside the loader jar, if there is one. */
   private static Map<String, Object> readManifest(File here) {
      File f = new File(here, "version.json");
      if (!f.isFile()) {
         return null;
      }
      try {
         byte[] b = new byte[(int) f.length()];
         InputStream in = new java.io.FileInputStream(f);
         try {
            int off = 0;
            int r;
            while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) {
               off += r;
            }
         } finally {
            in.close();
         }
         return Json.obj(Json.parse(new String(b, "UTF-8")));
      } catch (Exception e) {
         say("(version.json unreadable: " + e.getMessage() + ")");
         return null;
      }
   }

   /**
    * Look for a newer release and pull it down. Non-fatal by design: being offline, or a
    * manifest host having a bad day, must not stop the game starting.
    */
   private static void checkForUpdates(File here, Map<String, Object> local) {
      String url = Json.str(local, "updateUrl");
      if (url == null) {
         return;
      }
      Updater.Update u = Updater.check(local, url);
      if (u == null) {
         return;
      }
      say("update    : " + Json.str(local, "version") + " -> " + u.version);
      try {
         // The mod jar is replaced in place. The loader's own jar is skipped, because it is
         // locked while running on Windows and there is no start script to swap it afterwards.
         // A new loader arrives with the next release through the installer.
         Updater.apply(u, here, "InfiniteLoader.jar", PROGRESS);
         say("update    : done");
         if (u.changed.contains("InfiniteLoader.jar")) {
            say("update    : the loader changed too - download the new release and run"
               + " InfiniteInstaller.jar to pick that up");
         }
      } catch (Exception e) {
         say("update    : failed (" + e.getMessage() + ") - continuing on the current version");
      }
   }

   /**
    * The launcher's libraries/ directory, deduced from where the base jar sits. The two
    * layouts put it in different places relative to the jar:
    *   Prism / MultiMC   libraries/com/mojang/minecraft/a1.0.4/<jar>   -> walk up to "libraries"
    *   Mojang launcher   versions/a1.0.4/<jar>                          -> libraries/ is a sibling
    *                                                                       of versions/
    * so check both on the way up.
    */
   private static File launcherLibraries(File baseJar) {
      File dir = baseJar.getParentFile();
      for (int i = 0; i < 6 && dir != null; i++) {
         if ("libraries".equalsIgnoreCase(dir.getName())) {
            return dir;
         }
         File sibling = new File(dir, "libraries");
         if (sibling.isDirectory()) {
            return sibling;
         }
         dir = dir.getParentFile();
      }
      return null;
   }

   private static File jarDir() {
      try {
         File self = new File(
            Loader.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         File dir = self.isDirectory() ? self : self.getParentFile();
         return dir == null ? new File(".") : dir;
      } catch (Exception e) {
         return new File(".");
      }
   }

   /** Progress lines, so downloads are not a silent hang. */
   interface Progress {
      void step(String message);
   }

   static String sha1(File f) {
      return quietSha1(f);
   }

   private static String quietSha1(File f) {
      try {
         MessageDigest md = MessageDigest.getInstance("SHA-1");
         InputStream in = new java.io.FileInputStream(f);
         try {
            byte[] buf = new byte[1 << 16];
            int r;
            while ((r = in.read(buf)) > 0) {
               md.update(buf, 0, r);
            }
         } finally {
            in.close();
         }
         StringBuilder sb = new StringBuilder();
         for (byte b : md.digest()) {
            sb.append(Character.forDigit((b >> 4) & 0xF, 16))
              .append(Character.forDigit(b & 0xF, 16));
         }
         return sb.toString();
      } catch (Exception e) {
         return "";
      }
   }

   private static void say(String s) {
      System.out.println("[infinite] " + s);
   }

   private static void fail(String s) {
      System.err.println();
      System.err.println("[infinite] " + s);
      System.err.println();
      if (!java.awt.GraphicsEnvironment.isHeadless()) {
         try {
            javax.swing.JOptionPane.showMessageDialog(
               null, s, "Minecraft Infinite", javax.swing.JOptionPane.ERROR_MESSAGE);
         } catch (Throwable ignored) {
            // console message already printed
         }
      }
      System.exit(1);
   }

   private Loader() {
   }
}
