# Minecraft Infinite

![Minecraft](https://img.shields.io/badge/Minecraft-Alpha%201.0.4-brightgreen)
![Java](https://img.shields.io/badge/Java-8%2B-orange)
![Mojang code](https://img.shields.io/badge/Mojang%20code-none-blue)

A big mod for Minecraft **Alpha 1.0.4**. Infinite worlds, a rewritten server, a pile of desync
fixes, and a mod loader so other people can build on it.

> [!IMPORTANT]
> There is no Mojang code or Mojang art in this repo and there never will be. What is here is
> my own source plus diffs against decompiled vanilla classes. The build works against a copy
> of the official client jar that **you** supply. [DISTRIBUTION.md](DISTRIBUTION.md) explains
> why it is built this way.

## Install

Grab the release zip, unzip it, close your launcher, double click `InfiniteInstaller.jar`. It
finds your launchers, you tick the ones you want, done. Full steps in [INSTALL.md](INSTALL.md).

## What's in here

| Path | What it is |
| --- | --- |
| `src/main/java/` | My classes. Ordinary source, readable without owning the game. |
| `patches/` | Unified diffs against decompiled vanilla classes. One per touched class. |
| `loader/` | The installer and the standalone loader. Java 8, no dependencies. |
| `server/` | Start scripts and config template for the dedicated server. |
| `spike/` | Runnable proof that Mixin can transform an Infinite class. |
| `examples/` | A working addon: registers a block, mixins into Infinite. |
| `base/` | Toolchain lock, expected base jar hash, the Mojang asset exclusion list. |
| `tools/` | The round trip gate that keeps unsafe patches out, and the manifest generator. |
| `licenses/`, `NOTICE.md` | Third party attribution. |

## How big is the encumbered part

Measured against the official Alpha 1.0.4 client (375 classes, 59 assets):

| | Count | |
| --- | ---: | --- |
| Third party classes | 3,548 | declared as dependencies, not committed |
| Project classes | 1,651 | at least **1,276 cannot be vanilla derived** |
| Project assets | 2,215 | **2,188 are original work** |
| Mojang assets to exclude | 27 | listed in `base/mojang-assets.txt` |

Over three quarters of the code and over 98% of the art is original. The vanilla derived part
is small enough to manage as a patch set, and small enough that moving to runtime injection
later is realistic instead of wishful.

## Build

```sh
./gradlew setup    # verify your jar, decompile, apply patches   (once)
./gradlew build    # compile and assemble
```

> [!WARNING]
> This builds the **client** only. The server patches are current and committed, but there is
> no Gradle server target yet, so producing a server jar is still manual. See
> [docs/SERVER.md](docs/SERVER.md).

You need your own `minecraft-a1.0.4-client.jar`. See [CONTRIBUTING.md](CONTRIBUTING.md).

The installer and loader build on their own, nothing to do with Gradle:

```sh
loader/build.sh
```

## Docs

| Doc | What it covers |
| --- | --- |
| [INSTALL.md](INSTALL.md) | Installing and playing |
| [CONTRIBUTING.md](CONTRIBUTING.md) | Bring your own jar, the patch workflow, the round trip gate |
| [DISTRIBUTION.md](DISTRIBUTION.md) | Why the repo is shaped like this, and what is still unsolved |
| [docs/PROFILES.md](docs/PROFILES.md) | How the installer registers with launchers |
| [docs/LOADER.md](docs/LOADER.md) | The standalone loader, and the measurement that killed the jarmod |
| [docs/REBASE-NOTES.md](docs/REBASE-NOTES.md) | Dropping my fork, and the fixes I carried across |
| [docs/MODDING.md](docs/MODDING.md) | **Writing an addon.** Start here if you want to make a mod |
| [docs/SERVER.md](docs/SERVER.md) | The dedicated server: patches, running it, registry sync |
| [docs/MODLOADER.md](docs/MODLOADER.md) | How the mod loader works inside, and what's proven |
| [docs/RELEASING.md](docs/RELEASING.md) | Cutting a release, and the update channel |

## Licence

The mod is mine. Bundled third party components keep their own licences, listed in
[NOTICE.md](NOTICE.md).

Minecraft is a trademark of Mojang AB / Microsoft. This project is not affiliated with,
endorsed by, or associated with either of them.
