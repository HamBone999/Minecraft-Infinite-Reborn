# Minecraft Infinite Server

![Minecraft](https://img.shields.io/badge/Minecraft-Alpha%201.0.4-brightgreen)
![Java](https://img.shields.io/badge/Java-8%2B-orange)
![Base jar](https://img.shields.io/badge/base%20jar-not%20needed-blue)

Dedicated server for [Minecraft Infinite](https://github.com/). Runs on its own. You do **not**
need a copy of Minecraft to host one.

## Run it

**Windows:** double click `start-server.bat`
**macOS / Linux:** `./start-server.sh`

Or straight up:

```sh
java -Xms1G -Xmx4G -Djava.util.Arrays.useLegacyMergeSort=true -jar minecraft-infinite-server.jar nogui
```

First start writes `server.properties`, `ops.txt`, `banned-players.txt`, `banned-ips.txt`,
`white-list.txt` and a `world/` folder into whatever directory you ran it from. Put the jar in
its own folder.

> [!IMPORTANT]
> Shut down with the **`stop`** command, not the X button. Closing the window can lose recent
> world changes.

## Addons

Put addon jars in `mods/`. The start script notices they're there and boots through
`InfiniteLoader.jar` instead of the bare server jar, which applies their mixins and sends your
entity registry to each joining client.

> [!IMPORTANT]
> **Clients must have the same addons.** At login the server sends its entity name-to-id
> table and the client remaps to match, so the two agree even if ids were allocated
> differently. A client missing an addon the server has is told exactly which one and refuses
> to remap rather than spawning wrong entities.
>
> Running addons needs **Java 8** on the server. Without addons in `mods/`, any Java 8+ works.

Writing an addon: [../docs/MODDING.md](../docs/MODDING.md).

## Settings worth knowing

Edit `server.properties`:

| Key | Notes |
| --- | --- |
| `server-port` | Default 25565. |
| `online-mode` | Leave it `true`. `false` means anyone can join as anyone. |
| `level-name` | Folder the world lives in. |

Memory lives in the start script, not `server.properties`. Change `MEMORY=4G` at the top of
`start-server.bat`, or `MEMORY=4G` in `start-server.sh`. Your machine needs more than that in
total, leave a couple of GB for the OS.

## Letting people in from outside

Port forward `server-port` on your router, or run a tunnel. Clients running Infinite support
**SRV records**, so if you point `_minecraft._tcp.yourdomain` at your host and port, players
type just `yourdomain` with no port.

Players need a **real Microsoft account** either way. The server checks against Mojang's
session servers.

## What's fixed in this build

The desync work, in short:

- Entity tracker sent a move packet on every interval for every entity, even standing still.
  **1034 packets in 14 seconds → 7.**
- Chunk compression could ship truncated data (`Bad compressed data format`).
- `unloadOldChunks()` could wedge permanently on an orphaned hash.
- `terrainMap` grew forever. Now a 256 entry LRU.
- The anti-speed check was a flat constant, so a lag spike or GC pause kicked legitimate
  players. Now proportional to real elapsed time.
- Creative block breaking never got its confirmation packet, so blocks flickered back after
  four seconds.

Full detail, including what's still broken, in [../docs/REBASE-NOTES.md](../docs/REBASE-NOTES.md).

> [!NOTE]
> This folder holds the scaffolding only. The server jar is a build artifact and is never
> committed here, for the reasons in [../DISTRIBUTION.md](../DISTRIBUTION.md). Copy these
> files next to a built `minecraft-infinite-server.jar`, or use the release zip.

## Files

```
minecraft-infinite-server.jar   the server, built separately, not in this repo
InfiniteLoader.jar              used automatically when mods/ has addons in it
start-server.bat                Windows launcher
start-server.sh                 macOS / Linux launcher
mods/                           addon jars go here
server.properties               written on first run
NOTICE.md                       third party licences
version.json                    release manifest
docs/                           how this was built
```

## Troubleshooting

| Problem | Fix |
| --- | --- |
| Window flashes and closes | Use the start script, it pauses on the error. If you ran the jar directly you saw nothing. |
| `crash-dump.hprof` appeared | The server ran out of memory. Raise `MEMORY` in the start script. Keep the file, it records what filled the heap. |
| Players can't connect but localhost works | Port forwarding or your tunnel, not the server. Check the port matches `server-port`. |
| Players get kicked for moving too fast | Should be fixed in this build. If it still happens, the kick message names the actual numbers now, so send me that. |
| `UnsupportedClassVersionError` | Java is older than 8. Check with `java -version`. |

---

Minecraft is a trademark of Mojang AB / Microsoft. This project is not affiliated with,
endorsed by, or associated with either of them.
