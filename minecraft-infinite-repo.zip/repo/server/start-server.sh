#!/bin/sh
# Minecraft Infinite dedicated server launcher.
# Put this next to the server jar and run it.

# --- settings you might want to change ---------------------
JAR="minecraft-infinite-server.jar"
MEMORY="4G"
AUTO_RESTART=0
#
#   MEMORY        RAM the server may use. 4G = 4 GB. Your machine needs more
#                 than this in TOTAL, leave a couple of GB for the OS.
#
#   AUTO_RESTART  set to 1 to relaunch automatically when the server stops.
#                 Off by default on purpose: if the server is crashing, a
#                 restart loop hides the crash instead of showing it to you.
# -----------------------------------------------------------

cd "$(dirname "$0")" || exit 1

if [ ! -f "$JAR" ]; then
   echo
   echo "  ERROR: cannot find \"$JAR\" in this folder."
   echo "  This script must sit next to the server jar."
   echo
   echo "  Jars found here:"
   ls -1 ./*.jar 2>/dev/null || echo "    (none)"
   echo
   echo "  If the name differs, edit this file and change the JAR line near the top."
   exit 1
fi

if ! command -v java >/dev/null 2>&1; then
   echo
   echo "  ERROR: Java was not found on your PATH."
   echo "  Install Java 8 or newer, or edit this file and replace java on the"
   echo "  launch line with the full path to your java binary."
   exit 1
fi

echo
echo " ============================================"
echo "  Minecraft Infinite Server"
echo "  jar    : $JAR"
echo "  memory : $MEMORY"
echo " ============================================"
echo
java -version 2>&1
echo
echo " Type commands straight into this window. Try: help"
echo " Shut down with the \"stop\" command, not Ctrl-C."
echo " Killing the process can lose recent world changes."
echo

while :; do
   if [ -d mods ] && [ -n "$(ls -A mods/*.jar 2>/dev/null)" ]; then
      # Addons present, so go through the loader: it applies mixins and sends the entity
      # registry to joining clients. Needs Java 8.
      java -Xms1G -Xmx"$MEMORY" \
           -XX:+HeapDumpOnOutOfMemoryError \
           -XX:HeapDumpPath="$PWD/crash-dump.hprof" \
           -Djava.util.Arrays.useLegacyMergeSort=true \
           -Dinfinite.side=server \
           -jar InfiniteLoader.jar nogui
   else
      java -Xms1G -Xmx"$MEMORY" \
           -XX:+HeapDumpOnOutOfMemoryError \
           -XX:HeapDumpPath="$PWD/crash-dump.hprof" \
           -Djava.util.Arrays.useLegacyMergeSort=true \
           -jar "$JAR" nogui
   fi
   CODE=$?

   echo
   echo " Server stopped. Exit code: $CODE"

   if [ -f crash-dump.hprof ]; then
      echo
      echo " *** crash-dump.hprof was written, the server ran OUT OF MEMORY."
      echo " *** Keep that file. It records exactly what filled the heap."
   fi

   [ "$AUTO_RESTART" = "1" ] || break
   echo " Restarting in 5 seconds, Ctrl-C to stop."
   sleep 5
done
