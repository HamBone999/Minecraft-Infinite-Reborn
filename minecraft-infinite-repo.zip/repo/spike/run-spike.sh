#!/bin/sh
# Proves a third-party jar can change Infinite's behaviour with no change to Infinite.
# Needs Java 8 and the jars listed in LIBS.md on the classpath.
set -e
cd "$(dirname "$0")"
CP="$(ls libs/*.jar | tr '\n' ':')../Infinite.jar"
mkdir -p out
javac -nowarn -proc:none --release 8 -cp "$CP" -d out src/infinite/spike/*.java
cp spike.mixins.json out/
java -cp "$CP:out" net.minecraft.launchwrapper.Launch --tweakClass infinite.spike.SpikeTweaker
