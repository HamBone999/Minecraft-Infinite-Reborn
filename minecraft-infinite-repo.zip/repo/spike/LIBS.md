# Spike dependencies

Drop these in `libs/`. None are redistributed here, all are fetched from their own upstream.

| Artifact | Where |
| --- | --- |
| `mixin-0.8.5.jar` | `https://repo.spongepowered.org/repository/maven-public/org/spongepowered/mixin/0.8.5/` |
| `launchwrapper-1.12.jar` | `https://libraries.minecraft.net/net/minecraft/launchwrapper/1.12/` |
| `asm-9.6.jar`, `asm-tree`, `asm-analysis`, `asm-commons`, `asm-util` | Maven Central, `org/ow2/asm/` |
| `guava-32.1.2-jre.jar` | Maven Central |
| `log4j-api-2.20.0.jar`, `log4j-core-2.20.0.jar` | Maven Central |
| `commons-lang3-3.12.0.jar` | Maven Central |
| `gson-2.10.1.jar` | Maven Central |
| `jopt-simple-5.0.4.jar` | Maven Central |

**Java 8 only.** See `docs/MODLOADER.md` for why.
