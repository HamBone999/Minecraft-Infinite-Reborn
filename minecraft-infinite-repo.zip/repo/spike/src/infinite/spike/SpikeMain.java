package infinite.spike;

import java.lang.reflect.Field;
import net.minecraft.launchwrapper.Launch;

public class SpikeMain {
   public static void main(String[] args) throws Exception {
      System.out.println();
      System.out.println("  SpikeMain loader   : " + SpikeMain.class.getClassLoader());
      System.out.println("  Launch.classLoader : " + Launch.classLoader);

      // Force the target through the transforming loader explicitly.
      Class<?> list = Launch.classLoader.loadClass("net.minecraft.game.block.BlockList");
      System.out.println("  BlockList loader   : " + list.getClassLoader());

      Field f = list.getDeclaredField("stone");
      f.setAccessible(true);
      Object stone = f.get(null);
      System.out.println("  Block loader       : " + stone.getClass().getClassLoader());

      float hardness = (Float) stone.getClass().getMethod("getHardness").invoke(stone);
      System.out.println();
      System.out.println("  =============================================");
      System.out.println("   stone.getHardness() = " + hardness);
      System.out.println("   vanilla 1.5  |  mixin applied 0.125");
      System.out.println("  =============================================");
      System.exit(Math.abs(hardness - 0.125F) < 1e-6 ? 0 : 3);
   }
}
