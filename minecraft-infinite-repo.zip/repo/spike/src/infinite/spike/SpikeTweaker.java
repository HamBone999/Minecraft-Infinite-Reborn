package infinite.spike;

import java.io.File;
import java.util.List;
import net.minecraft.launchwrapper.ITweaker;
import net.minecraft.launchwrapper.LaunchClassLoader;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

public class SpikeTweaker implements ITweaker {

   public void acceptOptions(List<String> args, File gameDir, File assetsDir, String profile) {
   }

   public void injectIntoClassLoader(LaunchClassLoader classLoader) {
      MixinBootstrap.init();
      Mixins.addConfiguration("spike.mixins.json");
      MixinEnvironment.getDefaultEnvironment().setSide(MixinEnvironment.Side.SERVER);
      // MixinTweaker normally does this; without it the transformer never sees a class.
      classLoader.registerTransformer("org.spongepowered.asm.mixin.transformer.Proxy");
   }

   public String getLaunchTarget() {
      return "infinite.spike.SpikeMain";
   }

   public String[] getLaunchArguments() {
      MixinBootstrap.getPlatform().inject();
      return new String[0];
   }
}
