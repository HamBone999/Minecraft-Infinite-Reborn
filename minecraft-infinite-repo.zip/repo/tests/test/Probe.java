package infinite.test;

import java.lang.reflect.Field;
import java.util.Map;

import infinite.api.EntityRegistry;
import infinite.api.WorldgenRegistry;
import infinite.api.event.BlockBreakEvent;
import infinite.api.event.EntitySpawnEvent;
import infinite.api.event.EventBus;

public class Probe {

   /** A minimal real entity: extends Entity and has the (World) constructor. */
   public static class Wraith extends net.minecraft.game.entity.Entity {
      public Wraith(net.minecraft.game.world.World world) { super(world); }
      protected void init() { }
      protected void readFromNBT(com.mojang.nbt.tag.special.CompoundTag tag) { }
      protected void writeToNBT(com.mojang.nbt.tag.special.CompoundTag tag) { }
   }

   public static class TestFeature {
      public boolean place(Object world, java.util.Random r, int x, int y, int z) {
         return true;
      }
   }

   public static void main(String[] args) throws Exception {
      int failures = 0;

      // ---- event bus ------------------------------------------------------------------
      final StringBuilder seen = new StringBuilder();
      EventBus bus = EventBus.get();
      bus.subscribe(BlockBreakEvent.class, EventBus.Priority.LOW, "test",
         e -> seen.append("low "));
      bus.subscribe(BlockBreakEvent.class, EventBus.Priority.HIGHEST, "test",
         e -> seen.append("highest "));
      bus.post(new BlockBreakEvent(null, 1, 2, 3));
      boolean ordered = seen.toString().equals("highest low ");
      System.out.println("  bus priority order      : " + seen.toString().trim()
         + (ordered ? "   OK" : "   WRONG"));
      if (!ordered) failures++;

      // cancelling stops later listeners
      final int[] afterCancel = {0};
      bus.subscribe(EntitySpawnEvent.class, EventBus.Priority.HIGHEST, "test",
         e -> e.setCancelled(true));
      bus.subscribe(EntitySpawnEvent.class, EventBus.Priority.LOW, "test",
         e -> afterCancel[0]++);
      EntitySpawnEvent spawn = bus.post(new EntitySpawnEvent(null, "dummy"));
      boolean cancelOk = spawn.isCancelled() && afterCancel[0] == 0;
      System.out.println("  cancel halts dispatch   : " + (cancelOk ? "OK" : "WRONG"));
      if (!cancelOk) failures++;

      // a throwing listener is evicted, not fatal
      int before = bus.listenerCount();
      bus.subscribe(BlockBreakEvent.class, EventBus.Priority.NORMAL, "bad",
         e -> { throw new RuntimeException("deliberate"); });
      bus.post(new BlockBreakEvent(null, 0, 0, 0));
      boolean evicted = bus.listenerCount() == before;
      System.out.println("  throwing listener evicted: " + (evicted ? "OK" : "WRONG"));
      if (!evicted) failures++;

      // ---- entity registry ------------------------------------------------------------
      EntityRegistry.register(Wraith.class, "infinite_test_wraith", 210);
      Class<?> em = Class.forName("net.minecraft.game.entity.EntityManager");
      Field sc = em.getDeclaredField("stringToClass");
      sc.setAccessible(true);
      Map<?, ?> stringToClass = (Map<?, ?>) sc.get(null);
      boolean entityOk = stringToClass.containsKey("infinite_test_wraith");
      System.out.println("  entity registered       : " + (entityOk ? "OK" : "WRONG")
         + "   (EntityManager now has " + stringToClass.size() + " entries)");
      if (!entityOk) failures++;

      // duplicate id is refused
      boolean refused = false;
      try {
         EntityRegistry.register(Wraith.class, "another", 210);
      } catch (IllegalStateException expected) {
         refused = true;
      }
      System.out.println("  duplicate id refused    : " + (refused ? "OK" : "WRONG"));
      if (!refused) failures++;

      int auto = EntityRegistry.registerAuto(Wraith.class, "infinite_test_auto");
      System.out.println("  auto id allocated       : " + auto);

      // ---- worldgen registry ----------------------------------------------------------
      WorldgenRegistry.add(new TestFeature(), "test", 8, 4, 48);
      boolean genOk = WorldgenRegistry.registered().size() == 1;
      System.out.println("  worldgen feature added  : " + (genOk ? "OK" : "WRONG")
         + "   " + WorldgenRegistry.registered());
      if (!genOk) failures++;

      boolean rejected = false;
      try {
         WorldgenRegistry.add(new Object(), "test", 1, 0, 10);
      } catch (IllegalArgumentException expected) {
         rejected = true;
      }
      System.out.println("  non-feature rejected    : " + (rejected ? "OK" : "WRONG"));
      if (!rejected) failures++;

      // ---- the core mixins actually applied -------------------------------------------
      Class<?> blockList = Class.forName("net.minecraft.game.block.BlockList");
      Field stoneField = blockList.getDeclaredField("stone");
      stoneField.setAccessible(true);
      Object stone = stoneField.get(null);
      float hardness = (Float) stone.getClass().getMethod("getHardness").invoke(stone);
      Field blocks = blockList.getDeclaredField("blocks");
      blocks.setAccessible(true);
      boolean addon = ((Object[]) blocks.get(null))[1500] != null;
      System.out.println("  addon mixin applied     : " + (hardness == 0.125F ? "OK" : "WRONG"));
      System.out.println("  addon block registered  : " + (addon ? "OK" : "WRONG"));
      if (hardness != 0.125F) failures++;
      if (!addon) failures++;

      System.out.println();
      System.out.println(failures == 0 ? "  ALL PASS" : "  " + failures + " FAILURE(S)");
      System.exit(failures == 0 ? 0 : 3);
   }
}
