package infinite.test;

import infinite.api.RegistrySync;

/** Server side checks: the sync mixin applied, and the payload it would send is sane. */
public class ServerProbe {
   public static void main(String[] args) throws Exception {
      int failures = 0;

      Class<?> handler = Class.forName("net.minecraft.server.network.NetServerHandler");
      String found = null;
      for (java.lang.reflect.Method m : handler.getDeclaredMethods()) {
         // Mixin mangles constructor injections, e.g. handler$zzd000$infinite$sendRegistry,
         // so match on the fragment rather than the start.
         if (m.getName().contains("infinite$sendRegistry")) {
            found = m.getName();
         }
      }
      System.out.println("  server mixin applied    : " + (found != null ? "OK   (" + found + ")" : "WRONG"));
      if (found == null) failures++;

      byte[] payload = RegistrySync.encode();
      int entities = RegistrySync.snapshot().size();
      System.out.println("  registry payload        : " + payload.length + " bytes, "
         + entities + " entities");
      boolean sane = payload.length > 100 && entities > 100;
      System.out.println("  payload sane            : " + (sane ? "OK" : "WRONG"));
      if (!sane) failures++;

      java.util.Map<String, Integer> round = RegistrySync.decode(payload);
      boolean rt = round.equals(RegistrySync.snapshot());
      System.out.println("  payload round trips     : " + (rt ? "OK" : "WRONG"));
      if (!rt) failures++;

      System.out.println();
      System.out.println(failures == 0 ? "  ALL PASS" : "  " + failures + " FAILURE(S)");
      System.exit(failures == 0 ? 0 : 3);
   }
}
