package infinite.test;

import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.Map;

import infinite.api.EntityRegistry;
import infinite.api.RegistrySync;

/** Exercises the login registry sync without needing two JVMs. */
public class SyncProbe {

   public static class Wraith extends net.minecraft.game.entity.Entity {
      public Wraith(net.minecraft.game.world.World w) { super(w); }
      protected void init() { }
      protected void readFromNBT(com.mojang.nbt.tag.special.CompoundTag t) { }
      protected void writeToNBT(com.mojang.nbt.tag.special.CompoundTag t) { }
   }

   public static class Golem extends net.minecraft.game.entity.Entity {
      public Golem(net.minecraft.game.world.World w) { super(w); }
      protected void init() { }
      protected void readFromNBT(com.mojang.nbt.tag.special.CompoundTag t) { }
      protected void writeToNBT(com.mojang.nbt.tag.special.CompoundTag t) { }
   }

   public static void main(String[] args) throws Exception {
      int failures = 0;

      // This machine registers two modded entities at "its own" ids.
      EntityRegistry.register(Wraith.class, "wraith", 210);
      EntityRegistry.register(Golem.class, "golem", 211);
      Map<String, Integer> mine = RegistrySync.snapshot();
      System.out.println("  local ids               : wraith=" + mine.get("wraith")
         + " golem=" + mine.get("golem"));

      // Pretend a server allocated them the other way round, which is exactly what happens
      // when two machines load the same mods in a different order.
      byte[] payload = RegistrySync.encode();
      Map<String, Integer> serverTable = RegistrySync.decode(payload);
      System.out.println("  payload round trips     : "
         + (serverTable.equals(mine) ? "OK" : "WRONG"));
      if (!serverTable.equals(mine)) failures++;

      Map<String, Integer> swapped = new LinkedHashMap<String, Integer>(serverTable);
      swapped.put("wraith", 211);
      swapped.put("golem", 210);

      RegistrySync.Result result = RegistrySync.apply(swapped);
      System.out.println("  remap applied           : " + result);
      boolean remapOk = result.clean() && result.remapped.size() == 2;
      System.out.println("  disagreement corrected  : " + (remapOk ? "OK" : "WRONG"));
      if (!remapOk) failures++;

      // The live registry must now read the server's numbers.
      Class<?> em = Class.forName("net.minecraft.game.entity.EntityManager");
      Field f = em.getDeclaredField("IdToClass");
      f.setAccessible(true);
      Map<?, ?> idToClass = (Map<?, ?>) f.get(null);
      Object at210 = idToClass.get(210);
      Object at211 = idToClass.get(211);
      boolean live = String.valueOf(at210).contains("Golem")
                  && String.valueOf(at211).contains("Wraith");
      System.out.println("  live table follows server: " + (live ? "OK" : "WRONG")
         + "   210=" + simple(at210) + " 211=" + simple(at211));
      if (!live) failures++;

      // A server with an entity we don't have must fail loudly and change nothing.
      Map<String, Integer> hasExtra = new LinkedHashMap<String, Integer>(swapped);
      hasExtra.put("basilisk", 212);
      RegistrySync.Result bad = RegistrySync.apply(hasExtra);
      boolean refused = !bad.clean() && bad.missingOnClient.contains("basilisk");
      System.out.println("  missing entity detected : " + (refused ? "OK" : "WRONG"));
      if (!refused) failures++;

      Object still210 = ((Map<?, ?>) f.get(null)).get(210);
      boolean unchanged = String.valueOf(still210).contains("Golem");
      System.out.println("  failed sync changed none: " + (unchanged ? "OK" : "WRONG"));
      if (!unchanged) failures++;

      System.out.println();
      System.out.println("  --- failure message a player would see ---");
      for (String line : RegistrySync.describeFailure(bad).split("\n")) {
         System.out.println("  | " + line);
      }

      System.out.println();
      System.out.println(failures == 0 ? "  ALL PASS" : "  " + failures + " FAILURE(S)");
      System.exit(failures == 0 ? 0 : 3);
   }

   private static String simple(Object o) {
      String s = String.valueOf(o);
      int i = s.lastIndexOf('.');
      return i < 0 ? s : s.substring(i + 1);
   }
}
