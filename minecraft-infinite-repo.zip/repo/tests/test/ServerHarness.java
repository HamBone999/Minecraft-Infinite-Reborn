package infinite.test;

import java.io.File;
import java.util.Arrays;

import infinite.loader.mods.ModEngine;
import infinite.loader.mods.ModInfo;

/** Boots the engine in server mode so the server-side sync mixin is exercised. */
public class ServerHarness {
   public static void main(String[] args) throws Exception {
      ModInfo self = ModInfo.parse(
           "loaderVersion=\"[1,)\"\nlicense=\"n/a\"\n\n"
         + "[[mods]]\nmodId=\"infinite\"\nversion=\"1.0-210826\"\n"
         + "displayName=\"Minecraft Infinite\"\n", null).get(0);
      ModEngine engine = new ModEngine(m -> System.out.println("[infinite] " + m));
      engine.start(new File("mods"), self, "infinite.test.ServerProbe", Arrays.<String>asList());
   }
}
