# Mod loader tests

`Harness` boots the loader with `mods/` and hands off to `Probe`, which asserts the event bus,
the entity registry, the worldgen registry, and that both an addon's mixin and its block
registration took effect.

```sh
CP="loader/libs/*:Infinite.jar:loader/InfiniteLoader.jar"
javac -proc:none --release 8 -cp "$CP" -d out $(find tests -name '*.java')
mkdir -p run/mods && cp examples/greenstone-1.2.0.jar run/mods/
cd run && java -cp "$CP:../out" infinite.test.Harness
```

Java 8. Exits 0 on pass, 3 on failure, so it drops straight into CI.
