#!/bin/sh
# Asserts the Prism/MultiMC instance is built the way that actually launches Infinite.
#
# Two failures shipped from here before, both silent:
#
#   1. The mod jar written to the maven tree, which MultiMC refuses with
#      "Some artifacts marked as 'local' are missing their files".
#   2. The mod delivered as a library without overriding net.minecraft. Upstream's a1.0.4
#      component carries the legacyLaunch trait and mainClass "ax", so MultiMC launched the
#      base game through its applet path and never called into Infinite. The instance booted
#      fine and looked correct, which is what made it expensive.
#
#   3. The 27 Mojang textures Infinite reads under renamed paths were never installed, so
#      entity shadows and the menu background drew as missing-texture squares. A jar mod
#      merge does not rename anything, so they have to be extracted at install time.
#
# All three are cheap to assert, so they are asserted.
#
# Usage: prism-layout-check.sh <release-dir> [path-to-a1.0.4-client.jar]
set -e
R="${1:?usage: prism-layout-check.sh <release-dir>}"
T=$(mktemp -d)
mkdir -p "$T/home/Desktop/PrismLauncher/instances" "$T/home/Desktop/PrismLauncher/libraries"
mkdir -p "$T/home/.minecraft/versions/a1.0.4"
echo '{"id":"a1.0.4"}' > "$T/home/.minecraft/versions/a1.0.4/a1.0.4.json"
printf '{\n "profiles": {},\n "version": 3\n}\n' > "$T/home/.minecraft/launcher_profiles.json"

# Give it a base jar so the asset extraction path is exercised, not skipped.
mkdir -p "$T/home/Desktop/PrismLauncher/libraries/com/mojang/minecraft/a1.0.4"
if [ -n "$2" ] && [ -f "$2" ]; then
  cp "$2" "$T/home/Desktop/PrismLauncher/libraries/com/mojang/minecraft/a1.0.4/minecraft-a1.0.4-client.jar"
fi

I="$T/home/Desktop/PrismLauncher/instances/Minecraft Infinite 1.0-210826"
# Seed the old broken library layout so the upgrade path is covered too.
mkdir -p "$I/libraries/gg/infinite/infinite/1.0-210826"
: > "$I/libraries/infinite-1.0-210826.jar"

java -Duser.home="$T/home" -jar "$R/InfiniteInstaller.jar" --dir "$R" --headless >/dev/null

fail=0
[ -f "$I/jarmods/Infinite-"*.jar ] || { echo "FAIL: no jarmod written"; fail=1; }
[ -d "$I/libraries" ] && { echo "FAIL: stale libraries/ layout survived"; fail=1; }

python3 - "$I" <<'PY2' || fail=1
import json, sys, glob
i = sys.argv[1]
ok = True
mc = json.load(open(i + "/patches/net.minecraft.json"))
if mc.get("mainClass") != "net.minecraft.client.Minecraft":
    print("FAIL: mainClass is", mc.get("mainClass"), "- the base game will launch"); ok = False
if "legacyLaunch" in mc.get("+traits", []):
    print("FAIL: legacyLaunch trait present - the base game will launch"); ok = False
jm = json.load(open(i + "/patches/custom.jarmod.infinite.json"))
entry = jm["jarMods"][0]
if entry.get("MMC-hint") != "local":
    print("FAIL: jarmod is not marked local"); ok = False
if not glob.glob(i + "/jarmods/" + entry["MMC-filename"]):
    print("FAIL: jarmod file", entry["MMC-filename"], "is missing"); ok = False
names = [m.get("MMC-filename", "") for m in jm["jarMods"]]
if any(n.startswith("InfiniteAssets-") for n in names):
    import zipfile
    aj = [n for n in names if n.startswith("InfiniteAssets-")][0]
    z = zipfile.ZipFile(i + "/jarmods/" + aj)
    for needed in ("misc/shadow.png", "gui/background/background.png"):
        if needed not in z.namelist():
            print("FAIL: assets jar has no", needed); ok = False
    if len(z.namelist()) != 27:
        print("FAIL: assets jar has", len(z.namelist()), "entries, expected 27"); ok = False
else:
    print("SKIP: no base jar supplied, asset extraction not checked")
pack = json.load(open(i + "/mmc-pack.json"))
uids = [c["uid"] for c in pack["components"]]
if "custom.jarmod.infinite" not in uids:
    print("FAIL: pack does not list the Infinite component"); ok = False
sys.exit(0 if ok else 1)
PY2

MJ=$(find "$T/home/.minecraft/libraries" -path '*gg/infinite*' -name '*.jar' | head -1)
[ -n "$MJ" ] || { echo "FAIL: Mojang library is not in the maven tree"; fail=1; }

rm -rf "$T"
[ $fail -eq 0 ] && echo "PASS: jarmod layout, legacyLaunch dropped, renamed assets, stale layout cleaned" || exit 1
