# Contributing

## Bring your own jar

There is no Mojang code or Mojang art in this repo and there never will be. The build works
against **your own copy** of the official Minecraft **Alpha 1.0.4** client jar.

If you've ever launched the instance, your launcher already downloaded it:

```
<launcher>/libraries/com/mojang/minecraft/a1.0.4/minecraft-a1.0.4-client.jar
```

Point the build at it:

```properties
# local.properties  (gitignored)
baseJar=/absolute/path/to/minecraft-a1.0.4-client.jar
```

The build checks its SHA-1 against `base/base.jar.sha1` and stops on a mismatch. That check
isn't bureaucracy. Every patch here is a diff against the decompilation of that exact file, so
a different jar produces patches that misapply in ways that often still compile.

> [!CAUTION]
> I will not link you to a copy and neither should anyone in an issue or a PR. Get it through
> the launcher, the way the licence intends. Linking a pirated jar turns a clean design into a
> distribution channel and I'll delete the comment.

## Build

```sh
./gradlew setup    # verify, decompile, apply patches   (once)
./gradlew build    # compile and assemble
```

The installer and loader are separate and don't need Gradle or the base jar:

```sh
loader/build.sh
```

## Changing vanilla code

Edit the files under `build/patched/`, then:

```sh
./gradlew regeneratePatches
```

That re-diffs your working tree back into `patches/`. **Commit the regenerated patch, never
the patched source.**

New code goes in `src/main/java/` as ordinary source. Only reach for a patch when you actually
need to change a vanilla class. Every patch is friction. It has to survive decompiler upgrades
and it can only be read by someone who owns the game.

## The round trip gate

```sh
./gradlew roundTripCheck
```

Runs in CI. It recompiles each patched class *without* your changes and asserts the resulting
set of class files matches the original jar's.

> [!WARNING]
> This catches a nasty one. Some classes decompile to source that compiles fine but produces a
> **different set of class files**, silently dropping anonymous inner classes the original
> bytecode still references. On this project `Minecraft.java` does exactly that, its decompiled
> source loses `Minecraft$2`. A patch there ships a broken client with no compile error
> anywhere.

If the gate rejects a class, that class can't be modified through source. Express the change as
a bytecode transformation or leave it alone.

## Toolchain

`base/decompiler.lock` pins the decompiler and its flags. Patches are diffs against that exact
output, so changing it invalidates all of them. Bumping it is a deliberate commit: change the
lock, run `regeneratePatches`, commit both together.

## Art

`base/mojang-assets.txt` lists the 27 files that are byte identical to Mojang's. They must
never be committed here. The build fails if one shows up in `src/main/resources`.

Four more are *modified* versions of Mojang originals: `armor/cloth_1.png`, `armor/cloth_2.png`,
`gui/gui.png`, `gui/icons.png`. Derivative works of their art, so treat them as encumbered
until someone redraws them from scratch. If you want a genuinely useful first contribution,
that's it.

## Code style

Match what's around you. Comments explain why something is the way it is, not what the line
below does. If a comment is narrating a decision I made rather than describing the code, it
shouldn't be there.
