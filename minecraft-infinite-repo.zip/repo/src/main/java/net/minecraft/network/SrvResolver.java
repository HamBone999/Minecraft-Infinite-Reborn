package net.minecraft.network;

import java.util.Hashtable;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

/**
 * Resolves Minecraft SRV records (_minecraft._tcp.<host>) so players can connect using a
 * bare domain name whose real host and port live somewhere else.
 *
 * The lookup is only attempted when the player did not type an explicit port, which the
 * callers signal by passing the default port. Anything that is obviously not a resolvable
 * domain (IP literals, localhost, single-label names) is skipped outright, and every
 * failure path falls back to the address exactly as given, so behaviour is unchanged for
 * every address that worked before.
 */
public final class SrvResolver {
   public static final int DEFAULT_PORT = 25565;

   private SrvResolver() {
   }

   /**
    * @return a two-element array of {host, port}; the input unchanged if no SRV record applies.
    */
   public static String[] resolve(String hostname, int port) {
      String[] unchanged = new String[]{hostname, Integer.toString(port)};
      if (port != DEFAULT_PORT || hostname == null) {
         return unchanged;
      }

      String host = hostname.trim();
      if (host.length() == 0 || host.indexOf(46) < 0 || host.indexOf(58) >= 0) {
         return unchanged;
      }

      if (host.equalsIgnoreCase("localhost") || isIpLiteral(host)) {
         return unchanged;
      }

      DirContext context = null;

      try {
         Hashtable<String, String> env = new Hashtable<>();
         env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
         env.put("java.naming.provider.url", "dns:");
         env.put("com.sun.jndi.dns.timeout.initial", "2000");
         env.put("com.sun.jndi.dns.timeout.retries", "1");
         context = new InitialDirContext(env);
         Attributes attributes = context.getAttributes("_minecraft._tcp." + host, new String[]{"SRV"});
         Attribute record = attributes == null ? null : attributes.get("srv");
         if (record != null) {
            Object value = record.get();
            if (value != null) {
               // "priority weight port target"
               String[] fields = value.toString().trim().split("\\s+");
               if (fields.length >= 4) {
                  String target = fields[3];
                  while (target.endsWith(".")) {
                     target = target.substring(0, target.length() - 1);
                  }

                  int srvPort = Integer.parseInt(fields[2]);
                  if (target.length() > 0 && srvPort > 0 && srvPort <= 65535) {
                     System.out.println("Resolved SRV record for " + host + " -> " + target + ":" + srvPort);
                     return new String[]{target, Integer.toString(srvPort)};
                  }
               }
            }
         }
      } catch (Throwable var13) {
         // No SRV record, no DNS provider, or a malformed answer: use the address as typed.
      } finally {
         if (context != null) {
            try {
               context.close();
            } catch (Throwable var12) {
            }
         }
      }

      return unchanged;
   }

   /** Cheap check for a dotted-quad IPv4 literal, so raw IPs never trigger a DNS round trip. */
   private static boolean isIpLiteral(String host) {
      for (int i = 0; i < host.length(); i++) {
         char c = host.charAt(i);
         if (c != '.' && (c < '0' || c > '9')) {
            return false;
         }
      }

      return true;
   }
}
