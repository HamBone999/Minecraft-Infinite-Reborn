#!/usr/bin/env python3
"""
Generate version.json for a release.

Everything the loader needs to install or update itself: the files that make up the release,
the libraries it depends on, and where each came from -- all hash-verified.

Library metadata is lifted from the Prism/MultiMC org.lwjgl.json component so the URLs,
sizes and hashes are Mojang's own rather than hand-written.

  client:  make_manifest.py <release-dir> <version> <base-url> <lwjgl-component.json>
  server:  make_manifest.py <release-dir> <version> <base-url> --server

  --update-url URL   override the moving "latest" pointer

The server manifest carries no libraries and no baseJar requirement. The server jar has no
sound stack, no LWJGL, and needs nothing from a copy of Minecraft -- verified by hashing every
entry against the official Alpha 1.0.4 jar (zero matches) and resolving every CONSTANT_Class
entry against its 375 classes (zero references).
"""
import hashlib, json, os, sys

def sha1(p):
    h = hashlib.sha1()
    with open(p, 'rb') as f:
        for c in iter(lambda: f.read(1 << 16), b''):
            h.update(c)
    return h.hexdigest()

def maven_path(name, classifier=None):
    """group:artifact:version [+ classifier] -> the standard maven repository layout."""
    group, artifact, version = name.split(':')[:3]
    fname = f"{artifact}-{version}" + (f"-{classifier}" if classifier else "") + ".jar"
    return f"{group.replace('.', '/')}/{artifact}/{version}/{fname}"


def libs_from_component(path):
    """Convert a launcher library component into the flatter shape the loader reads.

    The component carries sha1/size/url but no repository path -- launchers derive that from
    the maven coordinate, so the same derivation is used here. That keeps the cache layout
    identical to the launcher's, so files already on disk can be reused instead of downloaded.
    """
    with open(path, encoding='utf-8') as f:
        comp = json.load(f)
    out = []
    for lib in comp.get('libraries', []):
        name = lib.get('name')
        if not name:
            continue
        entry = {'name': name}
        dl = lib.get('downloads', {})
        art = dl.get('artifact')
        if art and art.get('size', 0) > 1024:      # skip the empty marker artifacts
            entry['artifact'] = {
                'path': art.get('path') or maven_path(name),
                'sha1': art['sha1'], 'size': art['size'], 'url': art['url'],
            }
        natives = {}
        for classifier, spec in (dl.get('classifiers') or {}).items():
            tag = classifier.replace('natives-', '')     # windows / osx / linux / osx-arm64
            natives[tag] = {
                'path': spec.get('path') or maven_path(name, classifier),
                'sha1': spec['sha1'], 'size': spec['size'], 'url': spec['url'],
            }
        if natives:
            entry['natives'] = natives
        if 'artifact' in entry or 'natives' in entry:
            out.append(entry)
    return out

def main():
    argv = sys.argv[1:]
    server = '--server' in argv
    args = [a for a in argv if not a.startswith('--')]
    flags = {a.split('=')[0]: a.split('=', 1)[1] for a in argv if a.startswith('--') and '=' in a}
    if len(args) < (3 if server else 4):
        print(__doc__)
        return 2
    release, version, base_url = args[:3]
    base_url = base_url.rstrip('/')
    component = None if server else args[3]

    files = []
    for name in sorted(os.listdir(release)):
        p = os.path.join(release, name)
        if not os.path.isfile(p) or name == 'version.json':
            continue
        if not name.endswith(('.jar', '.bat', '.sh', '.md', '.txt', '.example')):
            continue
        files.append({
            'path': name,
            'sha1': sha1(p),
            'size': os.path.getsize(p),
            'url': f'{base_url}/{version}/{name}',
        })

    manifest = {
        'formatVersion': 1,
        'id': 'infinite-server' if server else 'infinite',
        'name': 'Minecraft Infinite Server' if server else 'Minecraft Infinite',
        'version': version,
        'mainClass': ('net.minecraft.server.MinecraftServer' if server
                      else 'net.minecraft.client.Minecraft'),
        'self': f'{base_url}/{version}/version.json',
        'updateUrl': flags.get('--update-url', f'{base_url}/latest/version.json'),
        'files': files,
    }
    if not server:
        manifest['requires'] = {
            'baseJar': {
                'id': 'a1.0.4',
                'sha1': 'e5838277b3bb193e58408713f1fc6e005c5f3c0c',
                'size': 749244,
            }
        }
        manifest['libraries'] = libs_from_component(component)

    out = os.path.join(release, 'version.json')
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2)
        f.write('\n')
    print(f"wrote {out}")
    print(f"  id        {manifest['id']}")
    print(f"  version   {version}")
    print(f"  files     {len(files)}")
    print(f"  libraries {len(manifest.get('libraries', []))}")
    return 0

if __name__ == '__main__':
    sys.exit(main())
