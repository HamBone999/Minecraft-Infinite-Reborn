#!/usr/bin/env python3
"""
Round-trip gate.

Patches are diffs against decompiler output, so a patch is only trustworthy if that class
survives decompile -> recompile intact. Some do not: the decompiler can produce source that
compiles but yields a different set of class files, silently dropping anonymous inner classes
the original bytecode still references.

We hit exactly that on this project. Minecraft.java's decompiled source compiles cleanly but
loses Minecraft$2 -- an anonymous class the real Minecraft.class references. Patching that
file would have shipped a broken client with no compile error to warn anyone.

This script recompiles every UNPATCHED decompiled class and asserts the resulting class-file
set matches the original jar's. Any class that fails is unsafe to patch through source, and
the check fails the build if patches/ contains one.

Usage:  roundtrip_check.py <base.jar> <decompiled-dir> <patches-dir> [extra-cp ...]
Exit 0 = all patched classes round-trip. Exit 1 = at least one does not.
"""

import os
import shutil
import subprocess
import sys
import tempfile
import zipfile


def patched_classes(patches_dir):
    """Every class the patch set touches, as an internal name like net/minecraft/Foo."""
    out = set()
    for root, _, files in os.walk(patches_dir):
        for f in files:
            if f.endswith(".java.patch"):
                rel = os.path.relpath(os.path.join(root, f), patches_dir)
                out.add(rel[: -len(".java.patch")].replace(os.sep, "/"))
    return out


def expected_class_files(jar, internal_name):
    """The class files the original jar holds for this source file: Foo, Foo$1, Foo$Bar..."""
    with zipfile.ZipFile(jar) as z:
        names = z.namelist()
    prefix = internal_name + "$"
    return {
        n
        for n in names
        if n == internal_name + ".class" or (n.startswith(prefix) and n.endswith(".class"))
    }


def clean(stderr):
    """Drop launcher noise so the first real diagnostic is what gets reported."""
    lines = [
        l for l in stderr.strip().splitlines()
        if l.strip() and not l.startswith("Picked up ") and "JAVA_TOOL_OPTIONS" not in l
    ]
    return lines[0] if lines else "unknown error"


def compile_one(src, classpath, out_dir):
    # The decompiled tree is deliberately NOT on the classpath. If it were, javac would
    # resolve dependencies from source and recursively compile the whole tree, which fails
    # for unrelated reasons and buries the signal we actually want.
    return subprocess.run(
        ["javac", "-nowarn", "-encoding", "UTF-8", "--release", "8",
         "-cp", classpath, "-d", out_dir, src],
        capture_output=True, text=True,
    )


def main():
    if len(sys.argv) < 4:
        print(__doc__)
        return 2
    base_jar, decompiled_dir, patches_dir = sys.argv[1:4]
    extra_cp = sys.argv[4:]

    targets = sorted(patched_classes(patches_dir))
    if not targets:
        print("round-trip check: no patches to verify")
        return 0

    classpath = os.pathsep.join([base_jar] + extra_cp)
    failures, checked = [], 0

    for name in targets:
        src = os.path.join(decompiled_dir, name + ".java")
        if not os.path.isfile(src):
            failures.append((name, "no decompiled source -- patch targets a file that does not exist"))
            continue

        tmp = tempfile.mkdtemp(prefix="rt_")
        try:
            res = compile_one(src, classpath, tmp)
            if res.returncode != 0:
                failures.append((name, "unpatched source does not compile: " + clean(res.stderr)))
                continue

            produced = set()
            for root, _, files in os.walk(tmp):
                for f in files:
                    if f.endswith(".class"):
                        produced.add(os.path.relpath(os.path.join(root, f), tmp).replace(os.sep, "/"))

            expected = expected_class_files(base_jar, name)
            missing = expected - produced
            extra = produced - expected

            if missing or extra:
                detail = []
                if missing:
                    detail.append("dropped " + ", ".join(sorted(missing)))
                if extra:
                    detail.append("invented " + ", ".join(sorted(extra)))
                failures.append((name, "class-file set differs: " + "; ".join(detail)))
            else:
                checked += 1
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    print(f"round-trip check: {checked}/{len(targets)} patched classes verified")
    if failures:
        print()
        print("UNSAFE TO PATCH THROUGH SOURCE:")
        for name, why in failures:
            print(f"  {name}")
            print(f"      {why}")
        print()
        print("A patch on any of these can ship a broken build with no compile error.")
        print("Either drop the patch, or express that change as bytecode transformation instead.")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
