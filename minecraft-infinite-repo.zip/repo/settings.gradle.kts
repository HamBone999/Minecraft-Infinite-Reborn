rootProject.name = "minecraft-infinite"

dependencyResolutionManagement {
   repositories {
      mavenCentral()
      maven("https://libraries.minecraft.net")   // brigadier
   }
}
