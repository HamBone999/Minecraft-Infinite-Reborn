package com.example.greenstone.mixin;

import net.minecraft.game.block.Block;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public class BlockMixin {

   @Inject(method = "getHardness", at = @At("HEAD"), cancellable = true)
   private void greenstone$softerStone(CallbackInfoReturnable<Float> cir) {
      cir.setReturnValue(0.125F);
   }
}
