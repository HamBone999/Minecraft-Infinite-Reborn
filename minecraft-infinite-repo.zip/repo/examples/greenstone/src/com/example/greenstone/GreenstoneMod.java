package com.example.greenstone;

import infinite.api.Mod;
import infinite.api.ModContext;

@Mod("greenstone")
public class GreenstoneMod {

   public static Object greenstone;

   public GreenstoneMod(ModContext ctx) {
      System.out.println("[greenstone] constructed, version " + ctx.version());
      ctx.onSetup(GreenstoneMod::register);
   }

   private static void register() {
      try {
         Class<?> blockClass = Class.forName("net.minecraft.game.block.Block");
         Class<?> materialClass = Class.forName("net.minecraft.game.block.material.Material");
         Class<?> materials = Class.forName("net.minecraft.game.block.material.MaterialList");

         Object rock = null;
         for (java.lang.reflect.Field f : materials.getDeclaredFields()) {
            if (materialClass.isAssignableFrom(f.getType())) {
               f.setAccessible(true);
               rock = f.get(null);
               break;
            }
         }

         java.lang.reflect.Constructor<?> c =
            blockClass.getDeclaredConstructor(int.class, materialClass);
         c.setAccessible(true);
         greenstone = c.newInstance(1500, rock);
         System.out.println("[greenstone] registered a block at id 1500");
      } catch (Throwable t) {
         throw new RuntimeException("greenstone failed to register", t);
      }
   }
}
