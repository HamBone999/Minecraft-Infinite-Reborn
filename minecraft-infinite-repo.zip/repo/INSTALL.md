# Installing Minecraft Infinite

![Minecraft](https://img.shields.io/badge/Minecraft-Alpha%201.0.4-brightgreen)
![Java](https://img.shields.io/badge/Java-8%2B-orange)

You need **Java 8 or newer** and your own legit copy of Minecraft.

## Install

1. Unzip this folder anywhere. Keep the files together.
2. **Close your Minecraft launcher.** It rewrites its settings when it exits and will undo the
   install if it is open.
3. Double click **`InfiniteInstaller.jar`**.
4. Tick the launchers you want it added to. Hit OK.
5. Open your launcher again. **Minecraft Infinite** is in the version list.

That's it. Nothing you already have installed gets modified.

> [!WARNING]
> Step 2 is not optional. The official launcher keeps `launcher_profiles.json` in memory and
> writes it back over the top when it closes. If it was open, the profile vanishes and it
> looks like the installer did nothing. It didn't, your launcher ate it.

## What the installer actually does

It looks for launchers on your machine. Official Minecraft Launcher, Prism, MultiMC, including
portable copies sitting on your Desktop or a second drive. Then for each one you tick:

| Launcher | What it writes |
| --- | --- |
| Minecraft Launcher | A version that inherits from a1.0.4, plus an installation entry. Same as Forge or NeoForge. |
| Prism / MultiMC | An instance called `Minecraft Infinite <version>`. |

A launcher shows up greyed out if Alpha 1.0.4 isn't installed in it. The profile inherits from
a1.0.4 so it has to exist first:

> Installations → New → tick **historical versions** in the version filter → pick **a1.0.4** →
> create it and launch it once. Then run the installer again.

Prism and MultiMC download a1.0.4 themselves the first time you launch the instance, so
there's nothing to do there.

## Multiplayer

**Multiplayer → Add Server.** `host` and `host:port` both work, and a bare domain works if the
server owner set up an SRV record.

Sign in with a **real Microsoft account**. Servers check against Mojang's session servers, so
offline mode gets rejected.

## Updating

Download the new release, unzip it over the old folder, run `InfiniteInstaller.jar` again. It
registers the new version alongside the old one, so you can roll back by picking the older
profile.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| Profile doesn't show up in the Minecraft Launcher | Your launcher was open. Close it fully, run the installer again, then reopen it. |
| Launcher greyed out in the installer | Alpha 1.0.4 isn't installed there yet. See above. |
| Installer found no launchers | It looks for a `.minecraft`, or a folder holding both `instances/` and `libraries/`. If yours is somewhere weird, use `--register-prism` below. |
| Nothing happens when I double click the jar | Java isn't associated with `.jar` files. Open a terminal in the folder and run `java -jar InfiniteInstaller.jar`. |
| Out of memory | Change `-Xmx2G` in the installation's Java arguments in your launcher. |
| Crash on launch | Check you're actually on Java 8 or newer with `java -version`. |

<details>
<summary><b>Command line options</b></summary>

Register into one specific launcher and skip detection:

```sh
java -jar InfiniteInstaller.jar --register-mojang "C:\Users\you\AppData\Roaming\.minecraft"
java -jar InfiniteInstaller.jar --register-prism  "D:\PrismLauncher\instances\Infinite"
```

| Flag | What it does |
| --- | --- |
| `--headless` | No dialogs. Registers into every launcher that qualifies. |
| `--dir DIR` | Where `Infinite.jar` and `version.json` live. Defaults to the installer's own folder. |
| `--version V` | Override the version string. Normally read from `version.json`. |
| `--download` | Pull a release from the update channel instead of registering one already on disk. |

</details>

<details>
<summary><b>Playing without a launcher</b></summary>

`InfiniteLoader.jar` starts the game on its own, no launcher involved:

```sh
java -jar InfiniteLoader.jar
```

It needs two things out of an existing Minecraft install: 27 original textures from Alpha
1.0.4, and LWJGL. It borrows both from your own copy and never modifies it. First run it
searches for them and then remembers where they are. If it can't find them it opens a picker.

`--check` verifies the setup without starting the game. `--reset` forgets the remembered path
and searches again.

I keep this around because it's the launch path I've actually run end to end. Registration is
the normal way in.

</details>

## Files

```
InfiniteInstaller.jar   start here
Infinite.jar            the mod
InfiniteLoader.jar      standalone launcher, for playing without a launcher
version.json            release manifest, used for updates
NOTICE.md               third party licences
docs/                   how this thing was built
```

`infinite.properties`, `assets-cache/` and `natives/` appear if you use the standalone loader.
All three are safe to delete, they get rebuilt.

## Uninstalling

Remove the **Minecraft Infinite** installation in your launcher, then delete
`versions/infinite-*` and `libraries/gg/infinite/` from `.minecraft`. On Prism or MultiMC just
delete the instance.

---

Minecraft is a trademark of Mojang AB / Microsoft. This project is not affiliated with,
endorsed by, or associated with either of them.
