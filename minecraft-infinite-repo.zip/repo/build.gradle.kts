import java.security.MessageDigest

/*
 * Minecraft Infinite -- build-time assembly.
 *
 * Nothing Mojang-owned is committed to this repository. Each contributor supplies their own
 * copy of the official Alpha 1.0.4 client jar; the build decompiles it locally, applies the
 * diffs in patches/, compiles that together with src/, and assembles the jarmod.
 *
 *   ./gradlew setup      -- verify the base jar, decompile, apply patches
 *   ./gradlew build      -- compile and assemble
 *   ./gradlew regeneratePatches   -- re-diff the working tree back into patches/
 *   ./gradlew roundTripCheck      -- CI gate, see tools/roundtrip_check.py
 */

plugins {
   java
}

java {
   toolchain { languageVersion.set(JavaLanguageVersion.of(17)) }   // toolchain, not target
   sourceCompatibility = JavaVersion.VERSION_1_8
   targetCompatibility = JavaVersion.VERSION_1_8
}

repositories {
   mavenCentral()
   maven("https://libraries.minecraft.net")
}

dependencies {
   implementation(libs.fastutil)
   implementation(libs.brigadier)
   implementation(libs.jorbis)
   implementation(libs.jogg)
   // paulscode + starlight stay vendored -- see gradle/libs.versions.toml
   implementation(fileTree("libs") { include("*.jar") })
}

// ---------------------------------------------------------------------------------------
// Locating the user's own base jar. Read from local.properties or an env var. NEVER fetch
// this from anywhere we control -- that would turn this repo into a distribution channel.
// ---------------------------------------------------------------------------------------

val baseJar: File by lazy {
   val props = file("local.properties")
   val fromProps = if (props.exists())
      java.util.Properties().apply { props.inputStream().use { load(it) } }.getProperty("baseJar")
   else null
   val path = fromProps ?: System.getenv("MC_BASE_JAR")
   ?: throw GradleException(
      """
      Base jar not configured.

      This build needs your own copy of the official Minecraft Alpha 1.0.4 client jar. If you
      have ever launched the instance, your launcher already downloaded it -- look for
        <launcher>/libraries/com/mojang/minecraft/a1.0.4/minecraft-a1.0.4-client.jar

      Then either create local.properties with:
        baseJar=/absolute/path/to/minecraft-a1.0.4-client.jar
      or set the MC_BASE_JAR environment variable.

      We do not distribute this file and cannot obtain it for you.
      """.trimIndent()
   )
   File(path)
}

val decompiledDir = layout.buildDirectory.dir("decompiled").get().asFile
val patchedDir = layout.buildDirectory.dir("patched").get().asFile

fun sha1(f: File): String =
   MessageDigest.getInstance("SHA-1").digest(f.readBytes()).joinToString("") { "%02x".format(it) }

// ---------------------------------------------------------------------------------------

val verifyBaseJar by tasks.registering {
   group = "setup"
   description = "Check the supplied base jar is exactly the expected official build."
   doLast {
      if (!baseJar.isFile) throw GradleException("Base jar not found: ${baseJar.absolutePath}")
      val expected = file("base/base.jar.sha1").readText().trim().split(Regex("\\s+"))[0]
      val actual = sha1(baseJar)
      if (actual != expected) throw GradleException(
         """
         Base jar hash mismatch.
           expected $expected
           actual   $actual
           file     ${baseJar.absolutePath}

         Every patch in patches/ is a diff against the decompilation of the expected jar. A
         different jar means every patch misapplies, usually in ways that compile but
         misbehave. Fix the jar rather than the hash.
         """.trimIndent()
      )
      logger.lifecycle("base jar verified: $actual")
   }
}

val decompile by tasks.registering {
   group = "setup"
   description = "Decompile the base jar with the pinned decompiler."
   dependsOn(verifyBaseJar)
   outputs.dir(decompiledDir)
   doLast {
      val lock = file("base/decompiler.lock").readLines()
         .filter { it.isNotBlank() && !it.trimStart().startsWith("#") }
         .associate { it.substringBefore('=').trim() to it.substringAfter('=').trim() }

      decompiledDir.deleteRecursively(); decompiledDir.mkdirs()

      val decompilerJar = configurations.detachedConfiguration(
         dependencies.create(lock.getValue("decompiler"))
      ).singleFile

      // TODO(mappings): the official jar is OBFUSCATED (a.class, aa.class, ...) while this
      // project's sources use full names. A remap step belongs here, before decompilation,
      // applying community mappings from mappings/. See DISTRIBUTION.md.
      providers.exec {
         commandLine(
            "java", "-jar", decompilerJar.absolutePath,
            lock.getValue("flags"), baseJar.absolutePath, decompiledDir.absolutePath
         )
      }.result.get().assertNormalExitValue()

      logger.lifecycle("decompiled to $decompiledDir")
   }
}

val applyPatches by tasks.registering {
   group = "setup"
   description = "Copy decompiled sources to the working tree and apply patches/."
   dependsOn(decompile)
   doLast {
      patchedDir.deleteRecursively()
      decompiledDir.copyRecursively(patchedDir)

      var applied = 0
      fileTree("patches") { include("**/*.patch") }.forEach { patch ->
         val target = patch.relativeTo(file("patches")).path.removeSuffix(".patch")
         val result = providers.exec {
            workingDir = patchedDir
            commandLine("patch", "-p1", "--forward", "--batch", target)
            standardInput = patch.inputStream()
            isIgnoreExitValue = true
         }
         if (result.result.get().exitValue != 0) throw GradleException(
            "Patch failed: $target\n${result.standardError.asText.get()}\n\n" +
            "Usually this means your decompiler does not match base/decompiler.lock."
         )
         applied++
      }
      logger.lifecycle("applied $applied patches")
   }
}

val setup by tasks.registering {
   group = "setup"
   description = "One-time setup: verify, decompile, patch."
   dependsOn(applyPatches)
}

val regeneratePatches by tasks.registering {
   group = "setup"
   description = "Re-diff the working tree back into patches/ after editing patched sources."
   doLast {
      var written = 0
      fileTree(patchedDir) { include("**/*.java") }.forEach { modified ->
         val rel = modified.relativeTo(patchedDir).path
         val original = File(decompiledDir, rel)
         if (!original.exists() || original.readBytes().contentEquals(modified.readBytes())) return@forEach
         val out = file("patches/$rel.patch")
         out.parentFile.mkdirs()
         val res = providers.exec {
            commandLine("diff", "-u", "--label", "a/$rel", "--label", "b/$rel",
                        original.absolutePath, modified.absolutePath)
            isIgnoreExitValue = true
         }
         out.writeText(res.standardOutput.asText.get())
         written++
      }
      logger.lifecycle("regenerated $written patches")
   }
}

sourceSets {
   main {
      java.srcDirs("src/main/java", patchedDir)
      resources.srcDirs("src/main/resources")
   }
}

tasks.named("compileJava") { dependsOn(setup) }

// ---------------------------------------------------------------------------------------

val roundTripCheck by tasks.registering {
   group = "verification"
   description = "Refuse patches for classes that do not survive decompile -> recompile."
   dependsOn(decompile)
   doLast {
      val res = providers.exec {
         // Compile dependencies come from the jar and the declared libraries, never from the
         // decompiled tree -- see the note in roundtrip_check.py.
         val extraCp = configurations.compileClasspath.get().files.map { it.absolutePath }
         commandLine(listOf("python3", file("tools/roundtrip_check.py").absolutePath,
                     baseJar.absolutePath, decompiledDir.absolutePath,
                     file("patches").absolutePath) + extraCp)
         isIgnoreExitValue = true
      }
      logger.lifecycle(res.standardOutput.asText.get())
      if (res.result.get().exitValue != 0)
         throw GradleException("Round-trip check failed -- see above.")
   }
}

tasks.named("check") { dependsOn(roundTripCheck) }

// ---------------------------------------------------------------------------------------

val assembleJarmod by tasks.registering(Jar::class) {
   group = "distribution"
   description = "Build the jarmod overlay."
   archiveBaseName.set("InfdevPlus-Client")
   from(sourceSets.main.get().output)
   from("src/main/resources")
   doFirst {
      // Assets identical to Mojang's must never be produced from this repo -- they are taken
      // from the user's own base jar at install time instead.
      val forbidden = file("base/mojang-assets.txt").readLines()
         .map { it.substringBefore('#').trim() }.filter { it.isNotEmpty() }.toSet()
      val leaked = fileTree("src/main/resources").files
         .map { it.relativeTo(file("src/main/resources")).path.replace('\\', '/') }
         .filter { it in forbidden }
      if (leaked.isNotEmpty()) throw GradleException(
         "These assets are byte-identical to Mojang's and must not be shipped:\n" +
         leaked.joinToString("\n") { "  $it" }
      )
   }
}
